 Steps:
          1. Launch mql session 
              $ : mql
              MQL<1>tcl;   
          
          2. go to mql folder location
		  
                eg. cd <CurrentDIR>/
                
          3. exit tcl prompt
                eg. % exit;
          
          4. run mql script file 
                eg. run <CurrentDIR>/Add_Page.tcl
				
NOTE : ON EACH CHANGE IN PROPERTY FILE DELETE EXISTING PAGE AND AND RUN TCL . 				