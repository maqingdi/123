import com.matrixone.apps.domain.DomainConstants;
import com.matrixone.apps.domain.DomainObject;
import com.matrixone.apps.domain.util.MapList;
import com.matrixone.apps.framework.ui.UIUtil;
import matrix.db.*;
import matrix.util.StringList;
import org.w3c.dom.Document;
import org.w3c.dom.NodeList;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import java.io.*;
import org.w3c.dom.Element;
import java.io.File;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.nio.file.attribute.BasicFileAttributes;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.logging.*;
import java.util.logging.Formatter;
import java.util.stream.Collectors;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;
/**
 * Author - DSGS
 */
public class NK_AprisoIn_mxJPO {
    private static Logger logger = Logger.getLogger(NK_AprisoIn_mxJPO.class.getName());
    private static FileHandler handler = null;
    private static String fileName = null;
    private static String complete = "complete.txt";
    private static String finish = "finish";
    private static String APRISO_DIR = "APRISO_DIR";
    private static String XML = "XML";
    private static String LOG_DIR = "LOG_DIR";
    private static String error = "error";
    private static String Notfound = "Not found";
    private static  int outputNumber = 0;
    private static String ERROR = "Apriso output processing failed. Please check the error message.";
    public static void NK_ME_SwitchXML(Context context, String[] args) throws Exception {
        validateXml();
        Map<String,String> configValues = parseXmlFile("NK_ME_Switch_Process.xml");
        String aprisoInputDir = configValues.get(APRISO_DIR);
        System.out.println("aprisoInputDir : " + aprisoInputDir);
        String xml = configValues.get(XML);
        String logDir = configValues.get(LOG_DIR);
        String loggerLevel =  configValues.get("logger.level");
        String collaborationspaceJapan = configValues.get("COLLABORATIONSPACE_Japan");
        String collaborationspaceShanghai = configValues.get("COLLABORATIONSPACE_Shanghai");
        initiateLogger(logDir, loggerLevel);
        validateDirectory(aprisoInputDir);
        Path lockFilePath = Paths.get(aprisoInputDir, "process.lock");
        try {
            if (Files.exists(lockFilePath)) {
                log(Level.WARNING, " Program is already running.(ME_E01001)");
                log(Level.INFO, ERROR);
                System.exit(1);
            }
            createLockFile(lockFilePath);
            log(Level.INFO, " Processing has started.(ME_I01001)");
            argumentError(args,lockFilePath);
            if (args.length == 1) {
                validateFileArgument(args[0], lockFilePath, aprisoInputDir, collaborationspaceJapan, collaborationspaceShanghai , xml);
            } else if (args.length > 1) {
                handleTooManyArguments(lockFilePath);
            }
            checkAndProcessAprisoLinkageFolders(aprisoInputDir, lockFilePath , context , collaborationspaceJapan , collaborationspaceShanghai);
        }catch (Exception e){
            e.printStackTrace();
        }
        finally {
            try {
                cleanUp(lockFilePath);
            } catch (IOException e) {
                System.err.println("Failed to delete lock file.");
            }
        }
    }

    /**
     * Validating XML file directory
     */
    private static void validateXml() {
        File file = new File("NK_ME_Switch_Process.xml");
        if (!file.exists()) {
            log(Level.INFO, "Could not read NK_ME_Switch_Process.xml. (ME_E01003)");
            System.exit(0);
        }
    }

    /**
     * @param dir holds the output directory path
     */
    private static void validateDirectory(String dir) {
        File file = new File(dir);
        if (file.exists() && file.isDirectory()) {
            log(Level.INFO, "aprisoInputDir " + dir);
        } else {
            log(Level.WARNING, "Not found the destination folder path.(ME_E01004)");
            System.exit(0);
        }
    }

    /**
     * This method checks and processes Apriso linkage folders. It ensures
     * that they are not error, finish, or work folders. The method then processes
     * the Apriso folders in order of their creation date.
     *
     * @param aprisoInputDir The input directory containing Apriso transfer folders.
     * @param lockFilePath The path to the lock file, used for logging and exit.
     * @param context The context in which the method is executed.
     * @param collaborationspaceJapan The collaboration space specific to Japan for folder linkage.
     * @param collaborationspaceShanghai The collaboration space specific to Shanghai for folder linkage.
     * @throws IOException If an I/O error occurs while accessing files or directories.
     */
    public static void checkAndProcessAprisoLinkageFolders(String aprisoInputDir, Path lockFilePath, Context context , String collaborationspaceJapan , String collaborationspaceShanghai) throws IOException {
        if (UIUtil.isNotNullAndNotEmpty(aprisoInputDir)) {
            File fileDir = new File(aprisoInputDir);
            System.out.println("");
            if (!isValidDirectory(fileDir)) {
                log(Level.SEVERE, "Invalid output source directory: " + aprisoInputDir);
                return;
            }
            File[] aprisoFolders = fileDir.listFiles((file) -> {
                String name = file.getName().toLowerCase();
                return file.isDirectory() && !name.equalsIgnoreCase(error) &&
                        !name.equalsIgnoreCase(finish) && !name.equalsIgnoreCase("work");
            });
            if (aprisoFolders == null || aprisoFolders.length == 0) {
                logAndExit("Not found the Apriso transfer folder", lockFilePath);
                return;
            }
            Arrays.sort(aprisoFolders, Comparator.comparing(file -> Long.valueOf(getCreationDate(file))));
            checkAndCreateFolders(fileDir);
            processAprisoFolders(aprisoFolders, fileDir, lockFilePath, context, collaborationspaceJapan, collaborationspaceShanghai , aprisoInputDir);
        }
    }

    /**
     * Processes the provided Apriso folders, verifying the existence of a "complete.txt" file
     * in each folder.
     *
     * @param aprisoFolders Array of folders to be processed.
     * @param fileDir The directory containing the Apriso folders.
     * @param lockFilePath Path to the lock file, used for logging and potential cleanup operations.
     * @param context The execution context for processing.
     * @param collaborationspaceJapan The collaboration space specific to Japan for folder linkage.
     * @param collaborationspaceShanghai The collaboration space specific to Shanghai for folder linkage.
     * @param aprisoInputDir The input directory where the Apriso folders are located.
     * @throws IOException If an I/O error occurs during file operations.
     */
    private static void processAprisoFolders(File[] aprisoFolders, File fileDir, Path lockFilePath, Context context, String collaborationspaceJapan,
                                             String collaborationspaceShanghai , String aprisoInputDir) throws IOException {
        boolean movetoWork = false;
        System.out.println("Number of aprisoFolders: " + (aprisoFolders != null ? aprisoFolders.length : 0));
        for (File folder : aprisoFolders) {
            System.out.println("folder considered:" + folder);
            String folderName = folder.getName().toLowerCase();  // Convert folder name to lowercase to handle case sensitivity
            // Skip folders with the names "work", "finish", or "error"
            if (folderName.equals("work") || folderName.equals("finish") || folderName.equals("error")) {
                continue;  // Skip these folders
            }
            if (!checkCompleteFile(folder)) {
                log(Level.SEVERE, String.format("Not found complete.txt. Error: " + folder + " (ME_E01007)"));
                log(Level.INFO,ERROR);
                zipAndMoveFolderToErrorDirectory(folder, aprisoInputDir);
                cleanUp(lockFilePath);
                confirmContinuationOfProcessing(aprisoInputDir, lockFilePath, context, collaborationspaceJapan, collaborationspaceShanghai, fileDir, folder);
                continue;
            }
            boolean success =  moveAprisoFolderToWork(folder, aprisoInputDir, lockFilePath, context, collaborationspaceJapan, collaborationspaceShanghai , folder , movetoWork);
            if(success){
                outputNumber++;
            }
        }
        logOutputDetails(outputNumber);
    }

    /**
     * Zips a specified folder and moves it to an error directory.
     *
     * @param folder the folder to be zipped and moved to the error directory
     * @param aprisoInputDir the base directory where the "error" subdirectory is located (or will be created)
     * @throws IOException if an I/O error occurs during zipping or moving the folder
     */
    private static void zipAndMoveFolderToErrorDirectory(File folder, String aprisoInputDir) throws IOException {
        File errorDirectory = new File(aprisoInputDir + "/error");
        if (!errorDirectory.exists()) {
            errorDirectory.mkdirs();  // Create the directory and any necessary parent directories
        }
        String zipFileName = folder.getName() + ".zip";
        File zipFile = new File(errorDirectory, zipFileName);
        zipFolder(folder, zipFile);
        deleteFolder(folder);
    }

    /**
     * Zips the contents of a specified folder and writes it to a zip file.
     *
     *  @param folderToZip the folder whose contents are to be zipped
     * @param zipFile the destination file for the zip archive
     * @throws IOException if an I/O error occurs during file reading or writing
     */
    private static void zipFolder(File folderToZip, File zipFile) throws IOException {
        try (FileOutputStream fos = new FileOutputStream(zipFile);
             ZipOutputStream zos = new ZipOutputStream(fos)) {
            Path sourcePath = folderToZip.toPath();
            Files.walk(sourcePath).forEach(path -> {
                try {
                    ZipEntry zipEntry = new ZipEntry(sourcePath.relativize(path).toString());
                    zos.putNextEntry(zipEntry);
                    if (Files.isRegularFile(path)) {
                        Files.copy(path, zos);
                    }
                    zos.closeEntry();
                } catch (IOException e) {
                    throw new UncheckedIOException(e);
                }
            });
        }
    }

    /**
     * Checks whether the "complete.txt" file exists in the given folder.
     *
     * @param folder The folder to check for the presence of the "complete.txt" file.
     * @return {@code true} if the "complete.txt" file exists, {@code false} otherwise.
     */
    private static boolean checkCompleteFile(File folder) {
        File completeFile = new File(folder, complete);
        return completeFile.exists();
    }

    /**
     * Checks if the specified file is a valid directory.
     *
     * @param directory The file to check.
     * @return {@code true} if the file exists and is a directory, {@code false} otherwise.
     */
    private static boolean isValidDirectory(File directory) {
        return directory.exists() && directory.isDirectory();
    }

    /**
     * checkAndCreateFolders
     * @param aprisoInputDir
     */
    public static void checkAndCreateFolders(File aprisoInputDir) {
        File workFolder = new File(aprisoInputDir, "work");
        File finishFolder = new File(aprisoInputDir, finish);
        File errorFolder = new File(aprisoInputDir, error);
        createFolderIfNotExists(workFolder);
        createFolderIfNotExists(finishFolder);
        createFolderIfNotExists(errorFolder);
    }

    /**
     *
     * @param folder
     */
    private static void createFolderIfNotExists(File folder) {
        if (!folder.exists()) {
            if (folder.mkdir()) {
            }
        }
    }

    /**
     * Moves the specified Apriso folder to the "work" directory within the given Apriso input directory.
     *
     * @param aprisoFolder The Apriso folder to be moved.
     * @param aprisoInputDir The directory containing the Apriso folders and the "work" folder.
     * @param lockFilePath Path to the lock file, used for logging and cleanup.
     * @param context The execution context for processing.
     * @param collaborationspaceJapan The collaboration space specific to Japan for folder linkage.
     * @param collaborationspaceShanghai The collaboration space specific to Shanghai for folder linkage.
     * @return {@code true} if the folder is successfully moved to the "work" directory, {@code false} otherwise.
     * @throws IOException If an error occurs during file operations.
     */
    public static boolean moveAprisoFolderToWork(File aprisoFolder, String aprisoInputDir, Path lockFilePath, Context context , String collaborationspaceJapan ,
                                                 String collaborationspaceShanghai , File folder , boolean movetoWork) throws IOException {
        File fileDir = new File(aprisoInputDir);
        File workFolder = new File(aprisoInputDir, "work");

        if (!workFolder.exists()) {
            workFolder.mkdirs();
        }
        File destinationFolder = new File(workFolder, aprisoFolder.getName());
        try {
            Files.move(aprisoFolder.toPath(), destinationFolder.toPath(), StandardCopyOption.REPLACE_EXISTING);
            movetoWork = true;
            readAprisoLinkageFile(destinationFolder, lockFilePath, context , fileDir , aprisoFolder , collaborationspaceJapan , collaborationspaceShanghai , movetoWork);
        } catch (IOException e) {
            log(Level.SEVERE, String.format("Failed to process AprisoTransfer folder. Error: " + aprisoFolder + " (ME_E01013)"));
            zipAndMoveFolderToErrorDirectory(aprisoFolder, aprisoInputDir);
            System.out.println("movedToErrorFolder");
            cleanUp(lockFilePath);
            log(Level.INFO, ERROR);
            confirmContinuationOfProcessing(aprisoInputDir, lockFilePath , context , collaborationspaceJapan , collaborationspaceShanghai , fileDir , folder);
        }
        return movetoWork;
    }

    /**
     * Reads and processes XML files from the specified destination folder.
     *
     * @param destinationFolder The folder where the XML files are located.
     * @param lockFilePath The path to the lock file, used for logging and tracking.
     * @param context The execution context for processing.
     * @param fileDir The original directory of the Apriso folders.
     * @param aprisoFolder The current Apriso folder being processed.
     * @param collaborationspaceJapan The collaboration space specific to Japan for folder linkage.
     * @param collaborationspaceShanghai The collaboration space specific to Shanghai for folder linkage.
     * @param movetoWork A flag indicating whether the folder was successfully moved to the "work" directory.
     * @throws IOException If an I/O error occurs during file operations.
     */
    public static void readAprisoLinkageFile(File destinationFolder, Path lockFilePath, Context context, File fileDir,
                                             File aprisoFolder , String collaborationspaceJapan , String collaborationspaceShanghai ,boolean movetoWork) throws IOException {
        File[] xmlFiles = destinationFolder.listFiles((dir, name) -> name.toLowerCase().endsWith(".xml"));
        if (xmlFiles == null || xmlFiles.length == 0) {
            log(Level.SEVERE, "Not found the XML file. Error: " +   destinationFolder + "(ME_E01008)");
            confirmProcessingSuccessOrFailure(fileDir , aprisoFolder,  movetoWork , destinationFolder );
            return;
        }
        for (File xmlFile : xmlFiles) {
            try {
                parseAndProcessXml(xmlFile , destinationFolder ,lockFilePath, context , fileDir , aprisoFolder ,
                        collaborationspaceJapan , collaborationspaceShanghai, movetoWork);
            } catch (Exception e) {
                log(Level.SEVERE, "Failed to read the XML file: " + xmlFile.getName() + ". Error: " + e.getMessage());
                confirmProcessingSuccessOrFailure(fileDir , aprisoFolder,  movetoWork , destinationFolder );
                return;
            }
        }
    }

    /**
     * Parses and processes the specified XML file.
     *
     * @param xmlFile The XML file to be parsed and processed.
     * @param destinationFolder The folder where the processed files will be stored.
     * @param lockFilePath The path to the lock file, used for logging and tracking.
     * @param context The execution context for processing.
     * @param aprisoInputDir The directory containing the Apriso input files.
     * @param aprisoFolder The current Apriso folder being processed.
     * @param collaborationspaceJapan The collaboration space specific to Japan for folder linkage.
     * @param collaborationspaceShanghai The  collaboration space specific to Shanghai for folder linkage.
     * @param movetoWork A flag indicating whether the folder was successfully moved to the "work" directory.
     * @throws Exception If an error occurs while parsing the XML file or during the processing of its content.
     */
    private static void parseAndProcessXml(File xmlFile, File destinationFolder, Path lockFilePath, Context context, File aprisoInputDir ,
                                           File aprisoFolder , String collaborationspaceJapan , String collaborationspaceShanghai , boolean movetoWork) throws Exception {
        DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
        DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
        Document doc = dBuilder.parse(xmlFile);
        doc.getDocumentElement().normalize();
        String sourceObjectRef = parseSourceObjectRef(doc, xmlFile, aprisoInputDir , aprisoFolder);
        if (sourceObjectRef == null) {
            return; // Log and error already handled in parseSourceObjectRef method
        }
        processWorkPlan(doc, sourceObjectRef, destinationFolder, lockFilePath, context , aprisoInputDir , aprisoFolder ,
                collaborationspaceJapan , collaborationspaceShanghai , movetoWork);
    }

    /**
     * Parses the given XML document to extract the value of the "SourceObjectRef" attribute from
     * the "Info" elements. If the "SourceObjectRef" attribute is not found, the method returns {@code null}.
     *
     * @param doc The XML document being parsed.
     * @param xmlFile The XML file being processed.
     * @param aprisoInputDir The directory containing the Apriso input files.
     * @param aprisoFolder The current Apriso folder being processed.
     * @return The value of the "SourceObjectRef" attribute, or {@code null} if not found.
     * @throws IOException If an error occurs during file operations.
     */
    private static String parseSourceObjectRef(Document doc, File xmlFile, File aprisoInputDir , File aprisoFolder) throws IOException {
        NodeList infoList = doc.getElementsByTagName("Info");
        for (int i = 0; i < infoList.getLength(); i++) {
            Element infoElement = (Element) infoList.item(i);
            if ("SourceObjectRef".equals(infoElement.getAttribute("name"))) {
                return infoElement.getAttribute("value");
            }
        }
        return null;
    }

    /**
     * Processes the work plan from the given XML document by searching for a matching work plan ID
     * that corresponds to the provided source object reference.
     *
     * @param doc The XML document containing the work plan details.
     * @param sourceObjectRef The source object reference to match against the work plan ID.
     * @param destinationFolder The folder where the processed files will be stored.
     * @param lockFilePath The path to the lock file, used for logging and tracking.
     * @param context The execution context for processing.
     * @param aprisoInputDir The directory containing the Apriso input files.
     * @param aprisoFolder The current Apriso folder being processed.
     * @param collaborationspaceJapan The collaboration space specific to Japan for folder linkage.
     * @param collaborationspaceShanghai The collaboration space specific to Shanghai for folder linkage.
     * @param movetoWork A flag indicating whether the folder was successfully moved to the "work" directory.
     * @throws Exception If an error occurs while processing the work plan or during file operations.
     */
    private static void processWorkPlan(Document doc, String sourceObjectRef, File destinationFolder, Path lockFilePath, Context context ,
                                        File aprisoInputDir, File aprisoFolder , String collaborationspaceJapan , String collaborationspaceShanghai , boolean movetoWork) throws Exception {
        boolean workPlanFound = false;
        NodeList processPlanningList = doc.getElementsByTagName("ProcessPlanningStructure");
        for (int i = 0; i < processPlanningList.getLength(); i++) {
            Element processElement = (Element) processPlanningList.item(i);
            NodeList workPlanList = processElement.getElementsByTagName("WorkPlan");
            for (int j = 0; j < workPlanList.getLength(); j++) {
                Element workPlanElement = (Element) workPlanList.item(j);
                String workPlanId = workPlanElement.getAttribute("id");
                if (sourceObjectRef.equals(workPlanId)) {
                    workPlanFound = true;
                    fetchAndLogWorkPlanDetails(processElement, context , lockFilePath , destinationFolder ,  aprisoInputDir , aprisoFolder ,
                            collaborationspaceJapan ,collaborationspaceShanghai , movetoWork);
                    break;
                }
            }
            if (!workPlanFound) {
                String errorMessage = "Not get the value in the XML file. Value: " + sourceObjectRef + ". Error: " + destinationFolder + " (ME_E01009)";
                log(Level.SEVERE, errorMessage);
                confirmProcessingSuccessOrFailure(aprisoInputDir , aprisoFolder,  movetoWork , destinationFolder );
                return;
            }
        }
    }

    /**
     * Fetches and logs the details of a work plan from the provided process element. It retrieves
     * attributes such as ID, maturity, revision index, and organization. Finally, it copies
     * the Apriso linkage folder to the destination.
     *
     * @param processElement The XML element containing the work plan details.
     * @param context The execution context for processing.
     * @param lockFilePath The path to the lock file, used for logging and tracking.
     * @param destinationFolder The folder where the processed files will be stored.
     * @param aprisoInputDir The directory containing the Apriso input files.
     * @param aprisoFolder The current Apriso folder being processed.
     * @param collaborationspaceJapan The collaboration space specific to Japan for folder linkage.
     * @param collaborationspaceShanghai The collaboration space specific to Shanghai for folder linkage.
     * @param movetoWork A flag indicating whether the folder was successfully moved to the "work" directory.
     * @throws Exception If an error occurs while fetching details or during file operations.
     */
    private static void fetchAndLogWorkPlanDetails(Element processElement, Context context, Path lockFilePath , File destinationFolder ,
                                                   File aprisoInputDir , File aprisoFolder ,String collaborationspaceJapan , String collaborationspaceShanghai
            , boolean movetoWork) throws Exception {
        NodeList idList = processElement.getElementsByTagName("ID");
        String idValue = (idList.getLength() > 0) ? idList.item(0).getTextContent() : Notfound;
        NodeList maturityList = processElement.getElementsByTagName("Maturity");
        String maturity = (maturityList.getLength() > 0) ? maturityList.item(0).getTextContent() : Notfound;
        NodeList revisionIndexList = processElement.getElementsByTagName("RevisionIndex");
        String revisionIndex = (revisionIndexList.getLength() > 0) ? revisionIndexList.item(0).getTextContent() : Notfound;
        NodeList organizationList = processElement.getElementsByTagName("Organization");
        String organization = (organizationList.getLength() > 0) ? organizationList.item(0).getTextContent() : Notfound;
        StringList objectSelects = new StringList();
        objectSelects.add(DomainConstants.SELECT_ID);
        String sName = idValue;
        String sWhere = getWhereClause(organization , maturity);
        MapList mlList = DomainObject.findObjects(context, DomainConstants.QUERY_WILDCARD, sName, revisionIndex,
                DomainConstants.QUERY_WILDCARD, DomainConstants.QUERY_WILDCARD, sWhere, true, objectSelects);
        handleNullIterator(mlList, lockFilePath, destinationFolder , aprisoInputDir , aprisoFolder , movetoWork , aprisoInputDir);
        copyAprisoLinkageFolder(destinationFolder ,aprisoFolder, collaborationspaceJapan , collaborationspaceShanghai ,  aprisoInputDir ,  movetoWork );
    }

    /**
     * Copies the specified Apriso linkage folder to the designated collaboration spaces for both Japan and Shanghai.
     * If an error occurs during the copy operation, it logs the error and confirms the outcome of the processing.
     *
     * @param destinationFolder The folder where the linkage is being copied.
     * @param aprisoFolder The source Apriso folder to be copied.
     * @param collaborationspaceJapan The collaboration space for Japan to which the folder will be copied.
     * @param collaborationspaceShanghai The collaboration space for Shanghai to which the folder will be copied.
     * @param aprisoInputDir The directory containing the Apriso input files.
     * @param movetoWork A flag indicating whether the folder was successfully moved to the "work" directory.
     * @throws Exception If an error occurs while copying the folder or during file operations.
     */
    private static void copyAprisoLinkageFolder(File destinationFolder, File aprisoFolder, String collaborationspaceJapan,
                                                String collaborationspaceShanghai , File aprisoInputDir , boolean movetoWork ) throws Exception {
        try {
            copyToCollaborationSpace(destinationFolder, aprisoFolder,  collaborationspaceJapan ,  aprisoInputDir ,  movetoWork);
            copyToCollaborationSpace(destinationFolder, aprisoFolder,  collaborationspaceShanghai ,  aprisoInputDir ,  movetoWork);
        } catch (IOException e) {
            log(Level.SEVERE, "Failed to copy Apriso transfer folder. Error: " + destinationFolder.getName() + " . (ME_E01011) . ");
            confirmProcessingSuccessOrFailure(aprisoInputDir , destinationFolder , movetoWork ,destinationFolder);
        }
    }

    /**
     * Copies the contents of the specified Apriso folder to a designated collaboration space.
     *
     * @param destinationFolder The folder containing the files to be copied.
     * @param aprisoFolder The source Apriso folder to be copied.
     * @param collaborationSpace The path to the collaboration space where the folder will be copied.
     * @param aprisoInputDir The directory containing the Apriso input files.
     * @param movetoWork A flag indicating whether the folder was successfully moved to the "work" directory.
     * @throws IOException If an error occurs during file operations, such as copying or directory creation.
     */
    private static void copyToCollaborationSpace(File destinationFolder, File aprisoFolder,  String collaborationSpace , File aprisoInputDir , boolean movetoWork) throws IOException {
        File destinationAprisoFolder = new File(collaborationSpace, aprisoFolder.getName());
        createDirectory(destinationAprisoFolder);
        copyFilesExcludingComplete(destinationFolder, destinationAprisoFolder);
        copyCompleteFile(destinationFolder, destinationAprisoFolder , aprisoInputDir ,  movetoWork);
    }

    /**
     * Creates the specified directory and any necessary parent directories.
     *
     * @param dir The directory to be created.
     * @throws IOException If the directory cannot be created, indicating a failure
     *                     in creating the destination folder.
     */
    private static void createDirectory(File dir) throws IOException {
        if (!dir.exists()) {
            boolean created = dir.mkdirs();
            if (!created) {
                throw new IOException("Failed to create destination Apriso linkage folder: " + dir.getPath());
            }
        }
    }

    /**
     * Copies all files from the source folder to the destination folder,
     * excluding any file named "complete".
     *
     * @param sourceFolder The folder containing the files to be copied.
     * @param destinationFolder The folder where the files will be copied to.
     * @throws IOException If an error occurs during file operations, such as
     *                     copying files or accessing directories.
     */
    private static void copyFilesExcludingComplete(File sourceFolder, File destinationFolder) throws IOException {
        File[] files = sourceFolder.listFiles();
        if (files != null) {
            for (File file : files) {
                if (!file.getName().equalsIgnoreCase(complete)) {
                    File destFile = new File(destinationFolder, file.getName());
                    Files.copy(file.toPath(), destFile.toPath(), StandardCopyOption.REPLACE_EXISTING);
                }
            }
        }
    }

    /**
     * Copies the "complete" file from the source folder to the destination folder.
     *
     * @param sourceFolder The folder containing the "complete" file to be copied.
     * @param destinationFolder The folder where the "complete" file will be copied to.
     * @param aprisoInputDir The directory containing the Apriso input files, used for processing confirmation.
     * @param movetoWork A flag indicating whether the folder was successfully moved to the "work" directory.
     * @throws IOException If an error occurs during file operations, such as copying the file or accessing directories.
     */
    private static void copyCompleteFile(File sourceFolder, File destinationFolder , File aprisoInputDir , boolean movetoWork ) throws IOException {
        File completeFile = new File(sourceFolder, complete);
        if (completeFile.exists()) {
            File destCompleteFile = new File(destinationFolder, completeFile.getName());
            Files.copy(completeFile.toPath(), destCompleteFile.toPath(), StandardCopyOption.REPLACE_EXISTING);
            confirmProcessingSuccessOrFailure( aprisoInputDir , destinationFolder , movetoWork , sourceFolder);
        }
    }

    /**
     * Constructs a "where" clause for querying based on the specified organization and maturity values.
     *
     * @param organization The name of the organization to be included in the "where" clause.
     * @param maturity The maturity status to be included in the "where" clause.
     * @return A string representing the constructed "where" clause in the format
     *         "'organization'=='<organization>' && 'current'=='<maturity>'".
     */
    private static String getWhereClause(String organization, String maturity) {
        StringBuilder whereClauseFlag = new StringBuilder();
        whereClauseFlag.append("'organization'=='" + organization + "'");
        whereClauseFlag.append(" && ");
        whereClauseFlag.append("'current'=='" + maturity +"'");
        return whereClauseFlag.toString();
    }

    /**
     * Checks if the provided MapList contains any elements by examining its iterator.
     *
     * @param mlList The MapList to be checked for elements.
     * @param lockFilePath The path to the lock file used for resource management.
     * @param destinationFolder The folder where the processed files are located.
     * @param aprisoInputDir The directory containing the Apriso input files.
     * @param aprisoFolder The Apriso folder being processed.
     * @param movetoWork A flag indicating whether the folder was successfully moved to the "work" directory.
     * @param sourceFolder The original source folder from which the files were processed.
     * @throws IOException If an error occurs during the cleanup process.
     */
    private static void handleNullIterator(MapList mlList, Path lockFilePath , File destinationFolder , File aprisoInputDir , File aprisoFolder ,
                                           boolean movetoWork , File sourceFolder) throws IOException {
        if (!mlList.iterator().hasNext()){
            log(Level.WARNING, "Process doesn't exist in XML file. Error: " + destinationFolder + " . (ME_E01010) . " );
            cleanUp(lockFilePath);
            confirmProcessingSuccessOrFailure(aprisoInputDir , destinationFolder , movetoWork ,sourceFolder);
            System.exit(0);
        }
    }

    /**
     * Confirms the success or failure of the processing operation based on the
     * provided flag.
     *
     * @param aprisoInputDir The directory containing the Apriso input files, used for
     *                       locating the finish and error folders.
     * @param destinationFolder The folder that was processed and needs to be moved
     *                         based on the success of the operation.
     * @param movetoWork A flag indicating whether the processing was successful
     *                   (true) or not (false).
     * @param sourceFolder The original source folder from which the files were processed.
     * @throws IOException If an error occurs during the file move operations.
     */
    public static void confirmProcessingSuccessOrFailure(File aprisoInputDir , File destinationFolder , boolean movetoWork , File sourceFolder ) throws IOException {
        boolean processSuccess = movetoWork;
        File errorFolder = new File(aprisoInputDir, error);
        File finishFolder = new File(aprisoInputDir, finish);
        if (processSuccess) {
            moveToFinishFolder(destinationFolder, finishFolder , sourceFolder);
        } else {
            moveToErrorFolder(destinationFolder, errorFolder , sourceFolder );
        }
    }

    /**
     * Moves the processed destination folder to a designated finish folder after
     * compressing it into a zip file.
     *
     * @param destinationFolder The folder that has been processed and is to be
     *                         compressed and moved.
     * @param finishFolder The folder where successfully processed files are stored
     *                     after completion.
     * @param sourceFolder The original source folder from which the files were processed.
     * @throws IOException If an error occurs during folder compression or moving
     *                     operations.
     */
    private static void moveToFinishFolder(File destinationFolder, File finishFolder , File sourceFolder) throws IOException {
        File monthFolder = createMonthFolder(finishFolder); // This will create the month folder if it doesn't exist
        String zipFilePath = new File(monthFolder, destinationFolder.getName() + ".zip").getAbsolutePath(); // Corrected path for the zip file
        compressFolder(sourceFolder, zipFilePath); // Update the method to not return anything
        File compressedFolder = new File(zipFilePath); // Get the compressed folder based on the zipFilePath
        File destination = new File(monthFolder, compressedFolder.getName()); // Move it to the month folder
        try {
            Files.move(compressedFolder.toPath(), destination.toPath(), StandardCopyOption.REPLACE_EXISTING);
            log(Level.INFO, "Apriso output processing succeeded. Filename: " + compressedFolder + " . (ME_I01004)");
            deleteFolder(sourceFolder);
        } catch (IOException e) {
            log(Level.SEVERE, "Failed to move AprisoTransfer folder to finish folder. Error: " + compressedFolder + " . (ME_I01004)");
            log(Level.INFO, ERROR);
        }
    }

    /**
     * Recursively deletes the specified folder and all its contents. If the
     * folder is a directory, the method first deletes all files and subdirectories
     * within it before deleting the folder itself.
     *
     * @param folder The folder to be deleted, along with its contents.
     * @throws IOException If an error occurs during the deletion of files or
     *                     the folder itself.
     */
    private static void deleteFolder(File folder) throws IOException {
        if (folder.isDirectory()) {
            File[] files = folder.listFiles();
            if (files != null) {
                for (File file : files) {
                    deleteFolder(file);
                }
            }
        }
        Files.delete(folder.toPath()); // Delete the folder itself
    }

    /**
     * Compresses the specified destination folder into a zip file and moves it
     * to a designated error folder.
     *
     * @param destinationFolder The folder that has been processed and needs to
     *                         be moved due to processing failure.
     * @param errorFolder The folder where files that failed processing are stored.
     * @throws IOException If an error occurs during the compression of the folder
     *                     or while moving the zip file to the error folder.
     */
    private static void moveToErrorFolder(File destinationFolder, File errorFolder , File sourceFolder) throws IOException {
        String zipFilePath = destinationFolder + ".zip";
        File compressedFolder = compressFolder(destinationFolder ,zipFilePath);
        File destination = new File(errorFolder, compressedFolder.getName());
        try {
            Files.move(compressedFolder.toPath(), destination.toPath(), StandardCopyOption.REPLACE_EXISTING);
            log(Level.INFO, "Apriso output processing failed. Filename: " + compressedFolder + " . (ME_W120001)");
            System.out.println("moved to error folder");
            log(Level.INFO, ERROR);
            deleteFolder(sourceFolder);
        } catch (IOException e) {
            System.out.println("Catch");
            log(Level.SEVERE, "Failed to move AprisoTransfer folder to error folder. Error: " + compressedFolder + " . (ME_E01015)");
        }
    }

    /**
     * Creates a new month folder under the specified finish folder, using the
     * current year and month as the folder name in the format "YYYYMM".
     *
     * @param finishFolder The parent directory where the month folder will be created.
     * @return A File object representing the created or existing month folder.
     */
    private static File createMonthFolder(File finishFolder) {
        Calendar calendar = Calendar.getInstance();
        String monthFolderName = String.format("%04d%02d", calendar.get(Calendar.YEAR), calendar.get(Calendar.MONTH) + 1);
        File monthFolder = new File(finishFolder, monthFolderName);

        if (!monthFolder.exists()) {
            monthFolder.mkdirs(); // Create the month folder
        }

        return monthFolder; // Return the File object representing the month folder
    }

    /**
     * Compresses the specified folder into a ZIP file at the given file path.
     *
     * @param folderToCompress The folder to be compressed into a ZIP file.
     * @param zipFilePath The path where the resulting ZIP file will be saved.
     * @return A File object representing the created ZIP file.
     * @throws IOException If an error occurs during the compression process or if
     *                     the specified folder does not exist or is not a directory.
     */
    public static File compressFolder(File folderToCompress, String zipFilePath) throws IOException {
        try (FileOutputStream fos = new FileOutputStream(zipFilePath);
             ZipOutputStream zos = new ZipOutputStream(fos)) {
            if (folderToCompress.exists() && folderToCompress.isDirectory()) {
                File[] files = folderToCompress.listFiles();
                if (files != null && files.length > 0) {
                    for (File file : files) {
                        if (file.isFile()) {
                            addToZipFile(file, zos, folderToCompress.getName());
                        }
                    }
                } else {
                    System.out.println("The folder is empty.");
                }
            } else {
                throw new IOException("The specified folder does not exist or is not a directory: " + folderToCompress.getAbsolutePath());
            }
        }
        return new File(zipFilePath); // Return the ZIP file
    }

    /**
     * Adds a specified file to a ZipOutputStream as a ZipEntry. The entry is
     * created with a path relative to the specified folder name.
     *
     * @param file The file to be added to the ZIP file.
     * @param zos The ZipOutputStream to which the file will be written.
     *                   file will be placed.
     * @throws IOException If an error occurs during file reading or writing
     *                     to the ZIP output stream.
     */
    public static void addToZipFile(File file, ZipOutputStream zos, String parentFolderName) throws IOException {
        try (FileInputStream fis = new FileInputStream(file)) {
            String zipEntryName = file.getAbsolutePath().replace(parentFolderName + "\\", "");
            ZipEntry zipEntry = new ZipEntry(zipEntryName);
            zos.putNextEntry(zipEntry);
            byte[] buffer = new byte[1024];
            int length;
            while ((length = fis.read(buffer)) > 0) {
                zos.write(buffer, 0, length);
            }
            zos.closeEntry();
        }
    }

    /**
     * Checks for any unprocessed folders in the specified Apriso input directory and
     * processes them if found.
     *
     * @param aprisoInputDir The directory where unprocessed folders are located.
     * @param lockFilePath The path to the lock file used for synchronization
     *                     during processing.
     * @param context The context in which the processing is taking place,
     *                typically related to the application or execution environment.
     * @param collaborationspaceJapan The collaboration space for the Japan region.
     * @param collaborationspaceShanghai The collaboration space for the Shanghai region.
     * @param fileDir The directory containing relevant files for processing.
     * @throws IOException If an error occurs while checking for unprocessed folders
     *                     or during processing.
     */
    private static void confirmContinuationOfProcessing(String aprisoInputDir, Path lockFilePath, Context context,
                                                        String collaborationspaceJapan, String collaborationspaceShanghai, File fileDir, File skippedFolder) throws IOException {
        File[] unprocessedFolders = checkForUnprocessedFolders(aprisoInputDir);
        if (unprocessedFolders != null && unprocessedFolders.length > 0) {
            List<File> foldersToProcess = Arrays.stream(unprocessedFolders)
                    .filter(folder -> !folder.equals(skippedFolder))  // Skip the folder already processed
                    .filter(folder -> {
                        String folderName = folder.getName().toLowerCase();
                        return !folderName.equals("work") && !folderName.equals("finish") && !folderName.equals("error");
                    })
                    .collect(Collectors.toList());

            if (!foldersToProcess.isEmpty()) {
                processAprisoFolders(foldersToProcess.toArray(new File[0]), fileDir, lockFilePath, context, collaborationspaceJapan, collaborationspaceShanghai, aprisoInputDir);
                System.out.println("Processed Apriso Folders");
            }
        }
    }

    /**
     * Checks the specified Apriso input directory for unprocessed folders.
     *
     * @param aprisoInputDir The directory to check for unprocessed folders.
     * @return An array of File objects representing unprocessed folders.
     *         Returns null if the directory does not exist or if an I/O error occurs.
     */
    private static File[] checkForUnprocessedFolders(String aprisoInputDir) {
        File inputDir = new File(aprisoInputDir);
        return inputDir.listFiles(file -> {
            if (file.isDirectory()) {
                File completeFile = new File(file, "complete.txt");
                return !completeFile.exists(); // Unprocessed folders don't have complete.txt
            }
            return false;
        });
    }

    /**
     * Logs the details of the completed Apriso output processing, including the
     * number of linked Apriso folders processed.
     *
     * @param outputNumber The number of linked Apriso folders that were processed.
     */
    private static void logOutputDetails(int outputNumber) {
        log(Level.INFO, " Apriso output processing completed.OutputNumber: " + outputNumber + " . (ME_I01002) {0}Number of linked Apriso linked folders");
    }

    /**
     * Retrieves the creation date of a specified file or directory.
     *
     * @param file The file or directory whose creation date is to be retrieved.
     * @return The creation date as a timestamp in milliseconds since the epoch.
     *         Returns Long.MAX_VALUE if an error occurs while retrieving the date,
     *         which can be used to sort this file to the end of a list.
     */
    private static long getCreationDate(File file) {
        try {
            BasicFileAttributes attr = Files.readAttributes(file.toPath(), BasicFileAttributes.class);
            return attr.creationTime().toMillis();
        } catch (IOException e) {
            log(Level.SEVERE, "Error getting creation date of folder: " +  file.getName());
            return Long.MAX_VALUE;  // Return max value to put the file at the end of the sorting list
        }
    }

    /**
     * Logs a message at the INFO level, performs cleanup, and then exits the program.
     *
     * @param message The message to be logged.
     * @param lockFilePath The path to the lock file that needs to be cleaned up before exiting.
     * @throws IOException If an error occurs during the cleanup process.
     */
    public static void logAndExit(String message , Path lockFilePath) throws IOException {
        logger.log(Level.INFO, message);
        cleanUp(lockFilePath);
        System.exit(0);
    }

    /**
     * Logs a message indicating that there are too many arguments, performs cleanup, and then exits the program.
     *
     * @param lockFilePath The path to the lock file that needs to be cleaned up before exiting.
     * @throws IOException If an error occurs during the cleanup process.
     */
    private static void handleTooManyArguments(Path lockFilePath) throws IOException {
        log(Level.INFO, "Too many arguments");
        cleanUp(lockFilePath);
        System.exit(0);
    }

    /**
     * Validates the provided file path and checks if it is a valid XML file.
     *
     * @param filePath               The path of the file to be validated.
     * @param lockFilePath           The path to the lock file used for cleanup operations.
     * @param aprisoInputDir         The directory containing Apriso input files to be loaded and validated.
     * @param collaborationspaceJapan The collaboration space path for Japan.
     * @param collaborationspaceShanghai The collaboration space path for Shanghai.
     * @throws IOException If an error occurs during file validation, loading, or directory checks.
     */
    private static void validateFileArgument(String filePath, Path lockFilePath, String aprisoInputDir,
                                             String collaborationspaceJapan, String collaborationspaceShanghai , String xml) throws IOException {
        if (isValidFilePath(filePath)) {
            fileName = filePath;
            if (fileName.endsWith(".xml")) {
                loadAndValidateAprisoDir(aprisoInputDir , xml);
                checkOutputDirectory(collaborationspaceJapan, lockFilePath);
                checkOutputDirectory(collaborationspaceShanghai, lockFilePath);
            } else {
                handleInvalidConfigFile(lockFilePath);
            }
        } else {
            logInvalidXMLFile();
        }
    }

    /**
     * Logs a message indicating that the provided XML file is invalid and terminates the program.
     * This method should be called when an invalid XML file is detected during processing.
     *
     * <p>
     * The method logs an informational message to the logger and exits the application with a status code of 0.
     * </p>
     */
    private static void logInvalidXMLFile() {
        log(Level.INFO, "Invalid xml file");
        System.exit(0);
    }

    /**
     * Handles the situation where the configuration file (NK_ExportItem.conf) cannot be read.
     *
     * @param lockFilePath the path to the lock file that may need to be deleted
     * @throws IOException if an I/O error occurs while attempting to delete the lock file
     */
    private static void handleInvalidConfigFile(Path lockFilePath) throws IOException {
        log(Level.INFO, "Could not read NK_ExportItem.conf (ME_E01003)");
        Files.deleteIfExists(lockFilePath);
        System.exit(0);
    }

    /**
     * Loads and validates the specified Apriso input directory.
     *
     * @param aprisoInputDir the path to the Apriso input directory to be validated
     */
    private static void loadAndValidateAprisoDir(String aprisoInputDir, String xml)  {
        if (UIUtil.isNotNullAndNotEmpty(aprisoInputDir)) {
            File fileDir = new File(aprisoInputDir);
            if (!fileDir.exists() && !fileDir.isDirectory()) {
                log(Level.INFO, " Not found the destination folder path.(ME_E01004)");
                System.exit(0);
            }
        }
        if (UIUtil.isNotNullAndNotEmpty(xml)) {
            File xmlFile = new File(xml);
            if (!xmlFile.exists()) {
                log(Level.INFO, "Could not read NK_ME_Switch_Process.xml.(ME_E01003)");
                System.exit(0);
            }
        }
    }

    /**
     * Checks the validity of the specified output directory.
     *
     * @param dirPath the path to the output directory to be validated
     * @param lockFilePath the path to the lock file that will be cleaned up if the directory is invalid
     * @throws IOException if an I/O error occurs during cleanup of the lock file
     */
    public static void checkOutputDirectory(String dirPath, Path lockFilePath) throws IOException {
        if (UIUtil.isNotNullAndNotEmpty(dirPath)) {
            File fileDir = new File(dirPath);
            if (!fileDir.exists() || !fileDir.isDirectory()) {
                log(Level.INFO, " Not found the output source folder path. (ME_E01005)");
                cleanUp(lockFilePath);
                System.exit(0);
            }
        }
    }

    /**
     * Checks if the provided file path is valid.
     *
     * @param filePath the file path to be validated
     * @return true if the file path is valid (not null and not empty), false otherwise
     */
    private static boolean isValidFilePath(String filePath) {
        return filePath != null && !filePath.isEmpty();
    }

    /**
     * Checks the number of command-line arguments and handles errors accordingly.
     *
     * @param args       the array of command-line arguments
     * @param lockFilePath the path to the lock file used for cleanup
     * @throws IOException if an I/O error occurs during cleanup
     */
    private static void argumentError(String[] args,Path lockFilePath) throws IOException {
        if (args.length == 0) {
            log(Level.INFO, "Not enough arguments(ME_E01002)");
            cleanUp(lockFilePath);
            System.exit(0);
        }
    }

    /**
     * Cleans up resources by deleting the specified lock file and closing the associated handler.
     *
     * @param lockFilePath the path to the lock file to be deleted
     * @throws IOException if an I/O error occurs during the deletion of the lock file or while closing the handler
     */
    private static void cleanUp(Path lockFilePath) throws IOException {
        Files.deleteIfExists(lockFilePath);
        if (handler != null) {
            handler.close();
        }
    }

    /**
     * Creates a lock file at the specified path to prevent concurrent processing.
     *
     * @param lockFilePath the path where the lock file should be created
     */
    private static void createLockFile(Path lockFilePath) {
        try {
            Files.createFile(lockFilePath);
        } catch (IOException e) {
            log(Level.INFO, "Failed to create lock file. Exiting...");
            System.exit(1);
        }
    }

    /**
     * Logs a message at the specified logging level.
     *
     * @param level the logging level at which the message should be logged (e.g., INFO, WARNING, SEVERE)
     * @param args the message components to be formatted into the log entry
     */
    private static void log(Level level, String... args) {
        logger.log(level, getLogString(args));
    }

    /**
     * Constructs a formatted log message by appending the current date and time
     * to the provided message components.
     *
     * @param args the message components to be concatenated into the log entry
     * @return a formatted log message string that includes the current date and all message components
     */
    private static String getLogString(String... args) {
        StringBuilder sbMessage = new StringBuilder();
        sbMessage.append(new Date());
        sbMessage.append(",");
        for (String msg : args) {
            sbMessage.append(msg);
        }
        return sbMessage.toString();
    }

    /**
     * Returns the current date and time formatted as a string.
     *
     * @return a string representing the current date and time in the format "yyyMMddHHmmss"
     */
    private static String formattedDate() {
        LocalDateTime now = LocalDateTime.now();
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyMMddHHmmss");
        String formattedDate = now.format(formatter);
        return formattedDate;
    }

    /**
     * Initializes the logger for the application, setting up a file handler to log messages to a specified directory.
     *
     * @param LOG_DIR the directory where the log files will be stored
     * @param LoggerLevel the desired logging level (e.g., "INFO", "SEVERE"); if null or empty, defaults to "INFO"
     * @throws IOException if an I/O error occurs during logger initialization or file handling
     */
    private static void initiateLogger(String LOG_DIR, String LoggerLevel) throws IOException {
        String path = LOG_DIR + "/Logs";
        handler = new FileHandler(path +  formattedDate() + ".log");
        handler.setFormatter(new NK_AprisoIn_mxJPO.HD_LoggingFormatter());
        handler.setEncoding("UTF-8");
        logger.addHandler(handler);
        String level = LoggerLevel;
        if (level == null || level.isEmpty())
            level = "INFO";
        logger.setLevel(Level.parse(level));
    }

    /**
     * Custom log formatter that formats log records for output.
     */
    static class HD_LoggingFormatter extends Formatter {
        @Override
        public String format(LogRecord record) {
            StringBuilder sb = new StringBuilder();
            sb.append(record.getLevel()).append(',');
            sb.append(record.getMessage()).append('\n');
            return sb.toString();
        }
    }

    /**
     * Parses an XML file to extract specific configuration values.
     * <ul>
     * <li>APRISO_DIR: The directory path for the Apriso configuration.</li>
     * <li>COLLABORATIONSPACE: Each collaboration space's name and its corresponding path.</li>
     * <li>LOG_DIR: The directory for logs.</li>
     * <li>logger.level: The logging level.</li>
     * </ul>
     *
     * @param filePath the path to the XML file to be parsed
     * @return a map containing the extracted values, where the key is the configuration
     *         parameter name and the value is the corresponding value from the XML file
     */
    public static Map<String, String> parseXmlFile(String filePath) {
        Map<String, String> xmlValues = new HashMap<>();
        try {
            File xmlFile = new File(filePath);
            DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
            DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
            Document doc = dBuilder.parse(xmlFile);
            doc.getDocumentElement().normalize();
            NodeList inputList = doc.getElementsByTagName(APRISO_DIR);
            if (inputList.getLength() > 0) {
                String aprisoDir = inputList.item(0).getTextContent();
                xmlValues.put(APRISO_DIR, aprisoDir);
            }
            NodeList xmlList = doc.getElementsByTagName(XML);
            if (xmlList.getLength() > 0) {
                String xml = xmlList.item(0).getTextContent();
                xmlValues.put(XML, xml);
            }
            NodeList collaborationSpaceList = doc.getElementsByTagName("COLLABORATIONSPACE");
            for (int i = 0; i < collaborationSpaceList.getLength(); i++) {
                Element element = (Element) collaborationSpaceList.item(i);
                String name = element.getAttribute("name");
                String path = element.getTextContent();
                xmlValues.put("COLLABORATIONSPACE_" + name, path);
            }
            NodeList logDirList = doc.getElementsByTagName(LOG_DIR);
            if (logDirList.getLength() > 0) {
                String logDir = logDirList.item(0).getTextContent();
                xmlValues.put(LOG_DIR, logDir);
            }
            NodeList loggerLevelList = doc.getElementsByTagName("level");
            if (loggerLevelList.getLength() > 0) {
                String loggerLevel = loggerLevelList.item(0).getTextContent();
                xmlValues.put("logger.level", loggerLevel);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return xmlValues;
    }

}
