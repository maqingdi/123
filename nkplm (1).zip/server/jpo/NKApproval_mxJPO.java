import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.text.SimpleDateFormat;
import java.util.*;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.matrixone.apps.domain.DomainConstants;
import com.matrixone.apps.domain.DomainObject;

import matrix.db.BusinessObject;
import matrix.db.Context;
import matrix.db.Page;
import matrix.util.MatrixException;
import matrix.util.StringList;

import com.matrixone.apps.domain.util.ContextUtil;
import com.matrixone.apps.domain.util.EnoviaResourceBundle;
import com.matrixone.apps.domain.util.MapList;
import com.matrixone.apps.domain.util.MqlUtil;
import com.matrixone.apps.domain.util.StringUtil;
import com.dassault_systemes.enovia.changeaction.impl.ChangeAction;
import com.dassault_systemes.enovia.changeaction.impl.ProposedChanges;
import com.dassault_systemes.enovia.changeaction.interfaces.IProposedChanges;


/**
 * @author SCC5
 *
 */
public class NKApproval_mxJPO {

	/**
	 * This method is used to checkBOSSAttributes on (Manufacuring
	 * Assmebly/Provide Parts) in IN_WORK check
	 * 
	 * @param context
	 *            the ENOVIA <code>Context</code> object.
	 * @param args
	 *            [0] holds the document objectId. [1] holds the action
	 * @throws Exception
	 *             if operation fails.
	 * @exclude
	 */
	private static final Logger logger = LoggerFactory.getLogger("ApprovalProcess");

	public int checkBOSSAttributes(Context context, String args[]) throws NKException_mxJPO {
		logger.debug("Started checkBOSSAttributes method");
		try {
			String strObjectId = args[0];
			boolean isPresent = false;
			String targetCheck = readPageObject(context, NKConstants_mxJPO.PAGE_FILE, NKConstants_mxJPO.PROP_TARGET);

			// get BOSS Item Type from MBOM Object
			DomainObject dobj = DomainObject.newInstance(context, strObjectId);
			String bossType = dobj.getInfo(context, NKConstants_mxJPO.ATTR_BOSS_TYPE);

			// get all attributes from MBOM
			Map<?, ?> mbomattributeMap = dobj.getAttributeMap(context);

			// Split the targetCheck string into an array
			String[] targetArray = targetCheck.split(",");

			// Check if bosstype is in the array
			if (bossType != null && !bossType.isEmpty())
			{
				for (String type : targetArray) {
					if (type.equals(bossType)) {
						isPresent = true;
						break;
					}
				}
			}
			if (isPresent) {
				String checkAttributevalue = null;
				StringBuilder sbMessage = new StringBuilder();
				String strMessageSingle = EnoviaResourceBundle.getProperty(context, NKConstants_mxJPO.PROP_FILE,
						context.getLocale(), "nkapproval_single_attribute");
				String strMessageMulti = EnoviaResourceBundle.getProperty(context, NKConstants_mxJPO.PROP_FILE,
						context.getLocale(), "nkapproval_multi_attribute");
				// Cases to check the attributes for BOSS ITEM Type
				switch (bossType) {

				// To check MBOM_FROZEN_CHECK_1

				case "1":
					logger.debug("in MBOM_FROZEN_CHECK_1 Case");
					String check1 = readPageObject(context, NKConstants_mxJPO.PAGE_FILE, NKConstants_mxJPO.CHECK1);
					if (check1.contains(",")) {
						sbMessage.append(strMessageMulti);
						String[] check1Array = check1.split(",");
						for (String attribute : check1Array) {
							checkAttributevalue = (String) mbomattributeMap.get(attribute);
							if (checkAttributevalue.isEmpty()) {
								sbMessage.append("\n");
								sbMessage.append(attribute);
							}

						}
					} else {
						checkAttributevalue = (String) mbomattributeMap.get(check1);
						if (checkAttributevalue.isEmpty()) {
							sbMessage.append(strMessageSingle);
							sbMessage.append("\n");
							sbMessage.append(check1);
							emxContextUtilBase_mxJPO.mqlError(context, sbMessage.toString());
							return 1;
						}
					}
					if (sbMessage.length() > 0) {
						emxContextUtilBase_mxJPO.mqlError(context, sbMessage.toString());
						return 1;
					}
					break;

				// To check MBOM_FROZEN_CHECK_2
				case "2":
					logger.debug("in MBOM_FROZEN_CHECK_2 Case");
					String check2 = readPageObject(context, NKConstants_mxJPO.PAGE_FILE, NKConstants_mxJPO.CHECK2);
					if (check2.contains(",")) {
						sbMessage.append(strMessageMulti);
						String[] check1Array = check2.split(",");
						for (String attribute : check1Array) {
							checkAttributevalue = (String) mbomattributeMap.get(attribute);
							if (checkAttributevalue.isEmpty()) {
								sbMessage.append("\n");
								sbMessage.append(attribute);
							}

						}
					} else {
						checkAttributevalue = (String) mbomattributeMap.get(check2);
						if (checkAttributevalue.isEmpty()) {
							sbMessage.append(strMessageSingle);
							sbMessage.append("\n");
							sbMessage.append(check2);
							emxContextUtilBase_mxJPO.mqlError(context, sbMessage.toString());
							return 1;
						}
					}
					if (sbMessage.length() > 0) {
						emxContextUtilBase_mxJPO.mqlError(context, sbMessage.toString());
						return 1;
					}
					break;

				// To check MBOM_FROZEN_CHECK_4
				case "4":
					logger.debug("in MBOM_FROZEN_CHECK_4 Case");
					String check4 = readPageObject(context, NKConstants_mxJPO.PAGE_FILE, NKConstants_mxJPO.CHECK4);
					if (check4.contains(",")) {
						sbMessage.append(strMessageMulti);
						String[] check1Array = check4.split(",");
						for (String attribute : check1Array) {
							checkAttributevalue = (String) mbomattributeMap.get(attribute);
							if (checkAttributevalue.isEmpty()) {
								sbMessage.append("\n");
								sbMessage.append(attribute);
							}

						}
					} else {
						checkAttributevalue = (String) mbomattributeMap.get(check4);
						if (checkAttributevalue.isEmpty()) {
							sbMessage.append(strMessageSingle);
							sbMessage.append("\n");
							sbMessage.append(check4);
							emxContextUtilBase_mxJPO.mqlError(context, sbMessage.toString());
							return 1;
						}
					}
					if (sbMessage.length() > 0) {
						emxContextUtilBase_mxJPO.mqlError(context, sbMessage.toString());
						return 1;
					}
					break;

				// To check MBOM_FROZEN_CHECK_5
				case "5":
					logger.debug("in MBOM_FROZEN_CHECK_5 Case");
					String check5 = readPageObject(context, NKConstants_mxJPO.PAGE_FILE, NKConstants_mxJPO.CHECK5);
					if (check5.contains(",")) {
						sbMessage.append(strMessageMulti);
						String[] check1Array = check5.split(",");
						for (String attribute : check1Array) {
							checkAttributevalue = (String) mbomattributeMap.get(attribute);
							if (checkAttributevalue.isEmpty()) {
								sbMessage.append("\n");
								sbMessage.append(attribute);
							}

						}
					} else {
						checkAttributevalue = (String) mbomattributeMap.get(check5);
						if (checkAttributevalue.isEmpty()) {
							sbMessage.append(strMessageSingle);
							sbMessage.append("\n");
							sbMessage.append(check5);
							emxContextUtilBase_mxJPO.mqlError(context, sbMessage.toString());
							return 1;
						}
					}
					if (sbMessage.length() > 0) {
						emxContextUtilBase_mxJPO.mqlError(context, sbMessage.toString());
						return 1;
					}
					break;

				// To check MBOM_FROZEN_CHECK_6
				case "6":
					logger.debug("in MBOM_FROZEN_CHECK_6 Case");
					String check6 = readPageObject(context, NKConstants_mxJPO.PAGE_FILE, NKConstants_mxJPO.CHECK6);
					if (check6.contains(",")) {
						sbMessage.append(strMessageMulti);
						String[] check1Array = check6.split(",");
						for (String attribute : check1Array) {
							checkAttributevalue = (String) mbomattributeMap.get(attribute);
							if (checkAttributevalue.isEmpty()) {
								sbMessage.append("\n");
								sbMessage.append(attribute);
							}

						}
					} else {
						checkAttributevalue = (String) mbomattributeMap.get(check6);
						if (checkAttributevalue.isEmpty()) {
							sbMessage.append(strMessageSingle);
							sbMessage.append("\n");
							sbMessage.append(check6);
							emxContextUtilBase_mxJPO.mqlError(context, sbMessage.toString());
							return 1;
						}
					}
					if (sbMessage.length() > 0) {
						emxContextUtilBase_mxJPO.mqlError(context, sbMessage.toString());
						return 1;
					}
					break;

				// To check MBOM_FROZEN_CHECK_7
				case "7":
					logger.debug("in MBOM_FROZEN_CHECK_7 Case");
					String check7 = readPageObject(context, NKConstants_mxJPO.PAGE_FILE, NKConstants_mxJPO.CHECK7);
					if (check7.contains(",")) {
						sbMessage.append(strMessageMulti);
						String[] check1Array = check7.split(",");
						for (String attribute : check1Array) {
							checkAttributevalue = (String) mbomattributeMap.get(attribute);
							if (checkAttributevalue.isEmpty()) {
								sbMessage.append("\n");
								sbMessage.append(attribute);
							}

						}
					} else {
						checkAttributevalue = (String) mbomattributeMap.get(check7);
						if (checkAttributevalue.isEmpty()) {
							sbMessage.append(strMessageSingle);
							sbMessage.append("\n");
							sbMessage.append(check7);
							emxContextUtilBase_mxJPO.mqlError(context, sbMessage.toString());
							return 1;
						}
					}
					if (sbMessage.length() > 0) {
						emxContextUtilBase_mxJPO.mqlError(context, sbMessage.toString());
						return 1;
					}
					break;

				default:
					break;
				}

			}
		} catch (Exception e) {
			logger.error("Error in checkBOSSAttributes:", e);
			throw new NKException_mxJPO("Exception in NKApproval_mxJPO:checkBOSSAttributes");
		}
		logger.debug("Finished checkBOSSAttributes method");
		return 0;
	}

	/**
	 * Read Property File Values.
	 *
	 * @param context
	 * @param strPageName
	 * @param strKeyName
	 * @throws Exception
	 */
	public static String readPageObject(Context context, String strPageName, String strKeyName)
			throws NKException_mxJPO {
		logger.debug("Started readPageObject method");
		Properties propNotification = new Properties();
		String strProperty = DomainConstants.EMPTY_STRING;
		try {
			ContextUtil.pushContext(context, "User Agent", null, null);
			Page pageAttributePopulation = new Page(strPageName);
			pageAttributePopulation.open(context);
			String strProperties = pageAttributePopulation.getContents(context);
			pageAttributePopulation.close(context);
			InputStream input = new ByteArrayInputStream(strProperties.getBytes("UTF8"));
			propNotification.load(input);
			strProperty = propNotification.getProperty(strKeyName);
			ContextUtil.popContext(context);
		} catch (Exception e) {
			logger.error("Error in readPageObject:", e);
			throw new NKException_mxJPO("Exception in NKApproval_mxJPO:readPageObject");
		}
		logger.debug("Finished readPageObject method");
		return strProperty;
	}

	/**
	 * @param context
	 * @param args
	 * @return
	 * @throws NKException_mxJPO
	 */
	@SuppressWarnings("null")
	public int checkBOSSApprovalProcess(Context context, String args[]) throws NKException_mxJPO {
		logger.debug("Started checkBOSSApprovalProcess method");
		try {
			String strObjectId = args[0];
			DomainObject chanDomObj = DomainObject.newInstance(context, strObjectId);
			ChangeAction chanAct = new ChangeAction(context, strObjectId);
			String statusCheck = readPageObject(context, NKConstants_mxJPO.PAGE_FILE, "ObsoleteStatus");
			String statusLevelCheck = readPageObject(context, NKConstants_mxJPO.PAGE_FILE, "CheckErrorLevel_ObsoleteStatus");
			String prodClasCheck = readPageObject(context, NKConstants_mxJPO.PAGE_FILE, "UnavailableProductClassification");
			String prodLevelCheck = readPageObject(context, NKConstants_mxJPO.PAGE_FILE, "CheckErrorLevel_UnavailableProductClassification");
			String ratClasCheck = readPageObject(context, NKConstants_mxJPO.PAGE_FILE, "UnavailableRatingClassification");
			String ratLevelCheck = readPageObject(context, NKConstants_mxJPO.PAGE_FILE, "CheckErrorLevel_UnavailableRatingClassification");
			String rohsClassCheck = readPageObject(context, NKConstants_mxJPO.PAGE_FILE, "RoHSNonCompliantParts");
			String rohsLevelCheck = readPageObject(context, NKConstants_mxJPO.PAGE_FILE, "CheckErrorLevel_RoHSNonCompliantParts");
			String unitCheck= readPageObject(context, NKConstants_mxJPO.PAGE_FILE, "Unit");
			String unitLevelCheck = readPageObject(context, NKConstants_mxJPO.PAGE_FILE, "CheckErrorLevel_Unit");
			String basicNoCheck= readPageObject(context, NKConstants_mxJPO.PAGE_FILE, "Basic_Number");
			String basicNoLevelCheck = readPageObject(context, NKConstants_mxJPO.PAGE_FILE, "CheckErrorLevel_MBOMBasicNumber");
			String bossLinkFlag = readPageObject(context, NKConstants_mxJPO.PAGE_FILE, "BOSS_LINK_FLAG");
			String gatherClasscheck = readPageObject(context, NKConstants_mxJPO.PAGE_FILE, "Gather_Class");
			String gatherLevelCheck = readPageObject(context, NKConstants_mxJPO.PAGE_FILE, "CheckErrorLevel_ZUNWGatheringMaterialClassification");
			String maintainClassCheck = readPageObject(context, NKConstants_mxJPO.PAGE_FILE, "Maintain_Class");
			String maintainLevelCheck = readPageObject(context, NKConstants_mxJPO.PAGE_FILE, "CheckErrorLevel_NotMaintenanceGatheringMaterialClassification");
			String servicePartCheck = readPageObject(context, NKConstants_mxJPO.PAGE_FILE, "Service_Part");
			String serviceLevelCheck = readPageObject(context, NKConstants_mxJPO.PAGE_FILE, "CheckErrorLevel_ServicePartsQuantity");
			String unapproveLevelCheck = readPageObject(context,NKConstants_mxJPO.PAGE_FILE,"CheckErrorLevel_UnapprovedItem");
			String effectiveLevelCheck = readPageObject(context,NKConstants_mxJPO.PAGE_FILE,"CheckErrorLevel_EffectiveStartDate");
			StringBuilder sbMessage = new StringBuilder();
			String basicNumber = null;
			String strItemType = null;
			String gatherClass = null;
			String childMBOMStatus = null;
			String childPhysicalID = null;
			Map<String, String> relattributeMap =null;
			boolean bossFlag = checkBOSSFlag(bossLinkFlag);

			List<IProposedChanges> list = chanAct.getProposed(context); 
			StringList slprop = new StringList();

			for (IProposedChanges item : list) {
				// Your logic for each item
				ProposedChanges paramProposedChanges = new ProposedChanges(item.getPhysicalId(), chanAct);
				slprop.add(paramProposedChanges.getWhereObject(context).getPhysicalId(context));
			}
			if (!slprop.isEmpty()) 
			{
				for (String physicalid : slprop)
				{
					DomainObject dombomObj = DomainObject.newInstance(context, physicalid);
			        StringList objectSelects = new StringList();
			        objectSelects.add(DomainConstants.SELECT_ID);
			        objectSelects.add(DomainConstants.SELECT_NAME);
			        objectSelects.add(DomainConstants.SELECT_TYPE);        
					objectSelects.add(DomainConstants.SELECT_CURRENT);
					objectSelects.add(DomainConstants.SELECT_PHYSICAL_ID);
					
					//get all the attributes from MBOM object
					Map<?, ?> mbomattributeMap = dombomObj.getAttributeMap(context);
					Map <?,?> objInfoMap = dombomObj.getInfo(context, objectSelects);
					Map <?,?> childAttributeMap = null ;
					
					//Get BOSS Item Type from MBOM
					String bossItemType = checkBossItemType(mbomattributeMap);
					String kitAssymbly = getKitAssymbly(mbomattributeMap);
					
					//get 1 level MBOM and Attributes
					 String relPattern = "DELFmiFunctionIdentifiedInstance";
					 String typePattern = "CreateAssembly" + "," + "Provide";
			         StringList objSelects = new StringList(3);
			         objSelects.add(DomainConstants.SELECT_NAME);
			         objSelects.add(DomainConstants.SELECT_TYPE);
			         objSelects.add(DomainConstants.SELECT_ID);  
			         objSelects.add(DomainConstants.SELECT_CURRENT);
			         objSelects.add(DomainConstants.SELECT_OWNER);
			         objSelects.add(DomainConstants.SELECT_PHYSICAL_ID);
			         
			         StringList relSelects = new StringList();
			         relSelects.add(DomainConstants.SELECT_RELATIONSHIP_ID);
			         relSelects.add(NKConstants_mxJPO.BASIC_NUMBER);
			         relSelects.add(NKConstants_mxJPO.GATHERING_CLASS);

			         MapList mbomRelatedObject = dombomObj.getRelatedObjects(context, relPattern, 						                          // relationship pattern
			        		 														   typePattern,                                                   // object pattern
			        		 														   objSelects,                                                    // object selects
			        		 														   relSelects, 		                                              // relationship selects
			                                                                           true,                                                          // to direction
			                                                                           false,                                                          // from direction
			                                                                           (short) 0,                                                     // recursion level
			                                                                           "",                           								  // object where clause
			                                                                           "",
			                                                                           (short)0);
         
		
					for (Object mbomMap : mbomRelatedObject) 
					{
						Map<?, ?> mbomInfo = (Map<?, ?>) mbomMap;
						String childMBOMid = (String) mbomInfo.get(DomainConstants.SELECT_ID);
						childPhysicalID = (String) mbomInfo.get(DomainConstants.SELECT_PHYSICAL_ID);
						DomainObject childObj = DomainObject.newInstance(context, childMBOMid);
						childAttributeMap = childObj.getAttributeMap(context);
						Map<?,?> componentMap = getComponentParts(context, childObj);
						basicNumber = (String) mbomInfo.get(NKConstants_mxJPO.BASIC_NUMBER);
						gatherClass = (String) mbomInfo.get(NKConstants_mxJPO.GATHERING_CLASS);
						childMBOMStatus = (String) mbomInfo.get(DomainConstants.SELECT_CURRENT);
						if(basicNumber!=null || gatherClass!=null)
						{
							relattributeMap.put(NKConstants_mxJPO.BASIC_NUMBER, basicNumber);
							relattributeMap.put(NKConstants_mxJPO.GATHERING_CLASS, gatherClass);
						}
					}
					
					
					if(!mbomattributeMap.isEmpty())
					{
						//Check Part Type
						strItemType = checkItemType(mbomattributeMap);
					}
					//check the Object Type for validation
					String objType = (String)objInfoMap.get(DomainConstants.SELECT_TYPE);
					String objName = (String)objInfoMap.get(DomainConstants.SELECT_NAME);
					sbMessage.append(objType);
					sbMessage.append("/n");
					sbMessage.append(objName);
					if (checkConfig(NKConstants_mxJPO.MBOM_TYPES,objType)) 
					{				
						
						
						// Check Obsolete condition
						String status = (String)objInfoMap.get(DomainConstants.SELECT_CURRENT);
						if (status != null && status.equalsIgnoreCase(statusCheck) && childMBOMStatus!=null && childMBOMStatus.equalsIgnoreCase(statusCheck)) 
						{									
							if(statusLevelCheck.equalsIgnoreCase("E")){		
								sbMessage.append("/n");
								sbMessage.append("Object is OBSOLETE State");
								emxContextUtilBase_mxJPO.mqlError(context, sbMessage.toString());
								return 1;
							}else{
								sbMessage.append("/n");
								sbMessage.append("Object is OBSOLETE State");
								emxContextUtilBase_mxJPO.mqlWarning(context, sbMessage.toString());
							}
						}
						
						//Product Classification check
						if(strItemType!=null && strItemType.equalsIgnoreCase(NKConstants_mxJPO.PRODUCT_NAME))
						{
							String strProClassification = (String) mbomattributeMap.get(NKConstants_mxJPO.PRODUCT_CALSIFICATION);					
							if(checkConfig(prodClasCheck,strProClassification))
							{							
								if(prodLevelCheck.equalsIgnoreCase("E")){	
									sbMessage.append("/n");
									sbMessage.append("Unavailable Product Classification");
									emxContextUtilBase_mxJPO.mqlError(context, sbMessage.toString());
									return 1;
								}else{
									sbMessage.append("/n");
									sbMessage.append("Unavailable Product Classification");
									emxContextUtilBase_mxJPO.mqlWarning(context, sbMessage.toString());
								}
							}
						}
						
						//Rating Classification Check
						if(strItemType!=null && (strItemType.equalsIgnoreCase(NKConstants_mxJPO.SPECIFIC_PART)||strItemType.equalsIgnoreCase(NKConstants_mxJPO.MARKET_PART)||strItemType.equalsIgnoreCase(NKConstants_mxJPO.DOCUMENT)))
						{
							String strRatClassification = (String) mbomattributeMap.get(NKConstants_mxJPO.RATING_CLASSIFICATION);
							if(checkConfig(ratClasCheck,strRatClassification))
							{					
								if(ratLevelCheck.equalsIgnoreCase("E")){
									sbMessage.append("/n");
									sbMessage.append("Unavailable Rating Classification");
									emxContextUtilBase_mxJPO.mqlError(context, sbMessage.toString());
									return 1;
								}else{
									sbMessage.append("/n");
									sbMessage.append("Unavailable Rating Classification");
									emxContextUtilBase_mxJPO.mqlWarning(context, sbMessage.toString());
								}
							}
						}
						
						//ROHS non compliant parts
						if(rohsClassCheck!=null && !rohsClassCheck.isEmpty() && rohsLevelCheck !=null && !rohsLevelCheck.isEmpty())
						{
							String rohsMaterialClass = (String) mbomattributeMap.get(NKConstants_mxJPO.ROHS);
							if(checkConfig(rohsClassCheck,rohsMaterialClass))
							{							
								if(rohsLevelCheck.equalsIgnoreCase("E")){	
									sbMessage.append("/n");
									sbMessage.append("RoHS non complaint parts");
									emxContextUtilBase_mxJPO.mqlError(context, sbMessage.toString());
									return 1;
								}else{
									sbMessage.append("/n");
									sbMessage.append("RoHS non complaint parts");
									emxContextUtilBase_mxJPO.mqlWarning(context, sbMessage.toString());
								}
							}
						}
						
						
						//Unit Validation
						if(unitCheck!=null && !unitCheck.isEmpty() && unitLevelCheck !=null && !unitLevelCheck.isEmpty())
						{
							String unit = (String) mbomattributeMap.get(NKConstants_mxJPO.UNIT);
							if(checkConfig(unitCheck,unit))
							{					
								if(unitLevelCheck.equalsIgnoreCase("E")){	
									sbMessage.append("/n");
									sbMessage.append("Unit not valid");
									emxContextUtilBase_mxJPO.mqlError(context, sbMessage.toString());
									return 1;
								}else{
									sbMessage.append("/n");
									sbMessage.append("Unit not valid");
									emxContextUtilBase_mxJPO.mqlWarning(context, sbMessage.toString());
								}
							}
						}
						
						//Unapproved Items and check present in current CA
						if(!childMBOMStatus.equalsIgnoreCase("RELEASED") && childMBOMStatus!=null && childPhysicalID!=null && slprop.contains(childPhysicalID))
						{						
									
								if(unapproveLevelCheck.equalsIgnoreCase("E")){	
									sbMessage.append("/n");
									sbMessage.append("Unapproved Item");
									emxContextUtilBase_mxJPO.mqlError(context, sbMessage.toString());
									return 1;
								}else{
									sbMessage.append("/n");
									sbMessage.append("Unapproved Item");
									emxContextUtilBase_mxJPO.mqlWarning(context, sbMessage.toString());
								}
						}
						
						//basic Number check with BOSS exclusion flag
						if(checkConfig(basicNoCheck,basicNumber)&& bossFlag && basicNoCheck!=null && !basicNoCheck.isEmpty() && basicNoLevelCheck !=null && !basicNoLevelCheck.isEmpty() && basicNumber!=null && !basicNumber.isEmpty())
						{										
								if(basicNoLevelCheck.equalsIgnoreCase("E")){	
									sbMessage.append("/n");
									sbMessage.append("Basic Number not valid");
									emxContextUtilBase_mxJPO.mqlError(context, sbMessage.toString());
									return 1;
								}else{
									sbMessage.append("/n");
									sbMessage.append("Basic Number not valid");
									emxContextUtilBase_mxJPO.mqlWarning(context, sbMessage.toString());
								}
							
						}
						
						//ZUNW Gathering material classification check
						if(checkConfig(gatherClasscheck,gatherClass) && bossFlag && bossItemType.equalsIgnoreCase("6") && gatherClass!=null && !gatherClass.isEmpty() && !gatherClass.equalsIgnoreCase("0"))
						{										
								if(gatherLevelCheck.equalsIgnoreCase("E")){	
									sbMessage.append("/n");
									sbMessage.append("ZUNW GatheringMaterial Classification");
									emxContextUtilBase_mxJPO.mqlError(context, sbMessage.toString());
									return 1;
								}else{
									sbMessage.append("/n");
									sbMessage.append("ZUNW GatheringMaterial Classification");
									emxContextUtilBase_mxJPO.mqlWarning(context, sbMessage.toString());
								}
							
						}
						
						//Gathering material classification check that does not require maintenance
						if(checkConfig(maintainClassCheck,gatherClass) && bossFlag && bossItemType.equalsIgnoreCase("98") && gatherClass!=null && !gatherClass.isEmpty() && !gatherClass.equalsIgnoreCase("3"))
						{										
								if(maintainLevelCheck.equalsIgnoreCase("E")){	
									sbMessage.append("/n");
									sbMessage.append("does not require maintenance");
									emxContextUtilBase_mxJPO.mqlError(context, sbMessage.toString());
									return 1;
								}else{
									sbMessage.append("/n");
									sbMessage.append("does not require maintenance");
									emxContextUtilBase_mxJPO.mqlWarning(context, sbMessage.toString());
								}
							
						}				
						
						//Maintenance parts Revision quantity check
						if(strItemType.equalsIgnoreCase(NKConstants_mxJPO.SERVICE_PART) && !kitAssymbly.equalsIgnoreCase("9") && checkConfig(servicePartCheck,kitAssymbly) )
						{										
								if(serviceLevelCheck.equalsIgnoreCase("E")){	
									sbMessage.append("/n");
									sbMessage.append("Maintenance parts Revision quantity");
									emxContextUtilBase_mxJPO.mqlError(context, sbMessage.toString());
									return 1;
								}else{
									sbMessage.append("/n");
									sbMessage.append("Maintenance parts Revision quantity");
									emxContextUtilBase_mxJPO.mqlWarning(context, sbMessage.toString());
								}
							
						}
						
						//Service Parts Configuration Rule
						if(strItemType.equalsIgnoreCase(NKConstants_mxJPO.SERVICE_PART) && !kitAssymbly.equalsIgnoreCase("9") && checkConfig(servicePartCheck,kitAssymbly) )
						{										
								if(serviceLevelCheck.equalsIgnoreCase("E")){	
									sbMessage.append("/n");
									sbMessage.append("Service Parts Configuration Rule");
									emxContextUtilBase_mxJPO.mqlError(context, sbMessage.toString());
									return 1;
								}else{
									sbMessage.append("/n");
									sbMessage.append("Service Parts Configuration Rule");
									emxContextUtilBase_mxJPO.mqlWarning(context, sbMessage.toString());
								}
							
						}
						
						boolean bcheckBoss = checkBossItems(mbomattributeMap,childAttributeMap,relattributeMap);
						boolean bcheckEffectDate = checkEffectiveDate(context,dombomObj,chanDomObj);
						
						//BOSS Items Check
						if(bcheckBoss)
						{
							sbMessage.append("/n");
							sbMessage.append("BOSS Items Check");
							emxContextUtilBase_mxJPO.mqlWarning(context, sbMessage.toString());
							return 1;
							
						}
						
						//Effective Start Date Check
						if(bcheckEffectDate)
						{
							if(effectiveLevelCheck.equalsIgnoreCase("E")){	
								sbMessage.append("/n");
								sbMessage.append("Effective state Date Check");
								emxContextUtilBase_mxJPO.mqlError(context, sbMessage.toString());
								return 1;
							}else{
								sbMessage.append("/n");
								sbMessage.append("Effective state Date Check");
								emxContextUtilBase_mxJPO.mqlWarning(context, sbMessage.toString());
							}
								
						}
					}
				}
			}
		
		} catch (Exception e) {
			logger.error("Error in checkBOSSApprovalProcess:", e);
			throw new NKException_mxJPO("Exception in NKApproval_mxJPO:readPageObject");
		}
		logger.debug("Finished checkBOSSApprovalProcess method");
		return 0;
	}

	/**
	 * check the scope link exists or not
	 * 
	 * @param context
	 * @param sPhysicalID
	 * @return
	 * @throws NKException_mxJPO
	 * @throws Exception
	 */
	public static StringList hasScopeLink(Context context, String sPhysicalID) throws NKException_mxJPO {

		logger.debug("Started hasScopeLink method");
		StringList slReturn = null;
		try {

			String sQuery = "query path type SemanticRelation where \"element[0].physicalid=='" + sPhysicalID
					+ "'\" select element[0].pathid dump |";
			String sResult = MqlUtil.mqlCommand(context, sQuery);
			slReturn = StringUtil.split(sResult, "\n");

		} catch (MatrixException e) {
			logger.debug("Error in hasScopeLink method:", e);
			throw new NKException_mxJPO("Exception in NKApproval:hasScopeLink");
		}
		logger.debug("Finished hasScopeLink method");
		return slReturn;
	}
	
	/**
	 * check the item Type of MBOM
	 * 
	 * @param context
	 * @param sPhysicalID
	 * @return
	 * @throws NKException_mxJPO
	 * @throws Exception
	 */
	public static String checkItemType(Map<?,?> mbomattributeMap) throws NKException_mxJPO
	{
		logger.debug("Started checkItemType method");
		String strReturn = null;
		try 
		{
			String partsType = (String)mbomattributeMap.get(NKConstants_mxJPO.ITEM_TYPE);
			switch(partsType)
			{
			case "50":
				strReturn = "Service parts";
				break;
			case "51":
				strReturn = "Function classification";
				break;
			case "52":
				strReturn = "Product name";
				break;
			case "61":
				strReturn = "Document";
				break;
			case "62":
				strReturn = "Specific parts";
				break;
			case "63":
				strReturn = "Market parts";
				break;
			case "71":
				strReturn = "Technology management document";
				break;
			case "81":
				strReturn = "Folder";
				break;
				
				default:
				break;
				
			}

		} catch (Exception e) {
			logger.debug("Error in checkItemType method:", e);
			throw new NKException_mxJPO("Exception in NKApproval:checkItemType");
		}
		
		logger.debug("Finished checkItemType method");
		return strReturn;
	
	}
	
	/**
	 * check the valid config from NK_Approval properties
	 * 
	 * @param context
	 * @param sPhysicalID
	 * @return
	 * @throws NKException_mxJPO
	 * @throws Exception
	 */

	public static boolean checkConfig(String propConfig, String objectInfo) throws NKException_mxJPO
	{
		logger.debug("Started checkConfig Method");
		boolean bValid = false;
	
	try{
		if (propConfig != null && !objectInfo.isEmpty())
		{
			String[] propArray = propConfig.split(",");
			for (String value : propArray) {
				if (value.equals(objectInfo)) {
					bValid = true;
					break;
				}
			}
		}
		
		logger.debug("Finished checkConfig Method");
	}catch(Exception e){
		logger.debug("Error in checkConfig method:", e);
		throw new NKException_mxJPO("Exception in NKApproval:checkConfig");
	}
	return bValid;
	}
	
	
	/**
	 * check the BOSS item Type of MBOM
	 * 
	 * @param context
	 * @param sPhysicalID
	 * @return
	 * @throws NKException_mxJPO
	 * @throws Exception
	 */
	public static String checkBossItemType(Map<?,?> mbomattributeMap) throws NKException_mxJPO
	{
		logger.debug("Started checkBossItemType method");
		String strReturn = null;
		try 
		{
			String bossType = (String)mbomattributeMap.get(NKConstants_mxJPO.BOSS_ITEM_TYPE);
			switch(bossType)
			{
			case "1":
				strReturn = "1";
				break;
			case "2":
				strReturn = "2";
				break;
			case "4":
				strReturn = "4";
				break;
			case "5":
				strReturn = "5";
				break;
			case "6":
				strReturn = "6";
				break;
			case "7":
				strReturn = "7";
				break;
			case "98":
				strReturn = "98";
				break;
				
				default:
				break;
				
			}

		} catch (Exception e) {
			logger.debug("Error in checkBossItemType method:", e);
			throw new NKException_mxJPO("Exception in NKApproval:checkBossItemType");
		}
		
		logger.debug("Finished checkBossItemType method");
		return strReturn;
	
	}
	
	
	/**
	 * check the valid BOSS Linkgage FLAG
	 * 
	 * @param context
	 * @param sPhysicalID
	 * @return
	 * @throws NKException_mxJPO
	 * @throws Exception
	 */

	public static boolean checkBOSSFlag(String bossLinkFlag) throws NKException_mxJPO {
		logger.debug("Started checkBOSSFlag Method");
		boolean bValid = true;

		try {
			if (bossLinkFlag != null && !bossLinkFlag.isEmpty() && bossLinkFlag.equals("1")) {
				
						bValid = false;

			}

			logger.debug("Finished checkBOSSFlag Method");
		} catch (Exception e) {
			logger.debug("Error in checkBOSSFlag method:", e);
			throw new NKException_mxJPO("Exception in NKApproval:checkBOSSFlag");
		}
		return bValid;
	}
	
	
	/**
	 * check the BOSS item Type of MBOM
	 * 
	 * @param context
	 * @param sPhysicalID
	 * @return
	 * @throws NKException_mxJPO
	 * @throws Exception
	 */
	public static String getKitAssymbly(Map<?,?> mbomattributeMap) throws NKException_mxJPO
	{
		logger.debug("Started getKitAssymbly method");
		String strReturn = null;
		try 
		{
			strReturn = (String)mbomattributeMap.get(NKConstants_mxJPO.KIT_ASSY);

		} catch (Exception e) {
			logger.debug("Error in getKitAssymbly method:", e);
			throw new NKException_mxJPO("Exception in NKApproval:getKitAssymbly");
		}
		
		logger.debug("Finished getKitAssymbly method");
		return strReturn;
	
	}
	
	
	/**
	 * check the BOSS items 
	 * @param context
	 * @param sPhysicalID
	 * @return
	 * @throws NKException_mxJPO
	 * @throws Exception
	 */

	public static boolean checkBossItems(Map<?, ?> mbomattributeMap, Map<?, ?> childAttributeMap,Map<String,String>relattributeMap) throws NKException_mxJPO 
	{
		logger.debug("Started checkBossItems Method");
		boolean bValid = false;

		try 
		{
			String parentMbomLifecycle = (String) mbomattributeMap.get(NKConstants_mxJPO.BOM_LIFECYCLE);
			String childMbomLifecycle = (String) childAttributeMap.get(NKConstants_mxJPO.BOM_LIFECYCLE);
			boolean bossTran = checkBossTansItems(mbomattributeMap,childAttributeMap,relattributeMap);
			
			if(parentMbomLifecycle.equalsIgnoreCase("2") && (childMbomLifecycle.equalsIgnoreCase("1") || childMbomLifecycle.isEmpty()) && bossTran)
			{
				bValid = true;
			}
			if(parentMbomLifecycle.equalsIgnoreCase("1") && (childMbomLifecycle.equalsIgnoreCase("2") || childMbomLifecycle.isEmpty()) && bossTran )
			{
				bValid = true;
			}
			

			logger.debug("Finished checkBossItems Method");
		} catch (Exception e) {
			logger.debug("Error in checkBossItems method:", e);
			throw new NKException_mxJPO("Exception in NKApproval:checkBossItems");
		}
		return bValid;
	}
	
	/**
	 * check the BOSS Transmission items 
	 * @param context
	 * @param sPhysicalID
	 * @return
	 * @throws NKException_mxJPO
	 * @throws Exception
	 */

	public static boolean checkBossTansItems(Map<?, ?> mbomattributeMap, Map<?, ?> childAttributeMap,Map<String,String>relattributeMap) throws NKException_mxJPO 
	{
		logger.debug("Started checkBossTansItems Method");
		boolean bValid = false;
		boolean check1= false;
		boolean check2= false;

		try 
		{
			String parBossItemType = (String) mbomattributeMap.get(NKConstants_mxJPO.BOSS_ITEM_TYPE);
			String childBossItemType = (String) childAttributeMap.get(NKConstants_mxJPO.BOSS_ITEM_TYPE);
			String parItemType = (String)mbomattributeMap.get(NKConstants_mxJPO.ITEM_TYPE);
			String childItemType = (String)childAttributeMap.get(NKConstants_mxJPO.ITEM_TYPE);
			String gatherClass = relattributeMap.get(NKConstants_mxJPO.GATHERING_CLASS);
			
			if(parBossItemType!=null && !parBossItemType.isEmpty() && childBossItemType!=null && !childBossItemType.isEmpty() && !childBossItemType.equalsIgnoreCase("99") && !parBossItemType.equalsIgnoreCase("99") && gatherClass!=null && !gatherClass.isEmpty() && !gatherClass.equalsIgnoreCase("2"))
			{
				check1 = true;
				
			} 

			if(parItemType!=null && !parItemType.isEmpty() && childItemType!=null && !childItemType.isEmpty() && !childItemType.equalsIgnoreCase("81") && !parItemType.equalsIgnoreCase("81"))
			{
				check2 = true;
			}
			
			if(check1 && check2)
			{
				bValid=true;
			}
			
			logger.debug("Finished checkBossTansItems Method");
		} catch (Exception e) {
			logger.debug("Error in checkBossTansItems method:", e);
			throw new NKException_mxJPO("Exception in NKApproval:checkBossTansItems");
		}
		return bValid;
	}
	
	/**
	 * check the Effective Start Date
	 * @param context
	 * @param sPhysicalID
	 * @return
	 * @throws NKException_mxJPO
	 * @throws Exception
	 */

	public static boolean checkEffectiveDate(Context context,DomainObject dombomObj,DomainObject chanDomObj) throws NKException_mxJPO 
	{
		logger.debug("Started checkEffectiveDate Method");
		boolean bValid = true;
		String oldEffectiveDate = null;
		// Define the format of start date
        SimpleDateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy hh:mm:ss a");

		try 
		{
	        String curCAEffectiveDate = chanDomObj.getInfo(context, "attribute[Actual Start Date]");
			BusinessObject busPrev = dombomObj.getPreviousRevision(context);
			if(busPrev !=null)
			{	
					BusinessObject domPrev = (BusinessObject) busPrev;
					String objId = domPrev.getObjectId(context);
					DomainObject oldDomObj = DomainObject.newInstance(context,objId);
					String physicalID = oldDomObj.getPhysicalId(context);
					String preRevCAId = getChangeAction(context,physicalID);
					
					if(preRevCAId!=null && !preRevCAId.isEmpty())
					{
						DomainObject preCADomObj = DomainObject.newInstance(context,preRevCAId);
						oldEffectiveDate = preCADomObj.getInfo(context, "attribute[Actual Start Date]");
					}
			}
			
			 	Date date1 = dateFormat.parse(curCAEffectiveDate);
	            Date date2 = dateFormat.parse(oldEffectiveDate);

	            // Compare the two dates
	           if (date1.before(date2))
	           {
	        	   bValid=false;
	           } 
			
			logger.debug("Finished checkEffectiveDate Method");
		} catch (Exception e) {
			logger.debug("Error in checkEffectiveDate method:", e);
			throw new NKException_mxJPO("Exception in NKApproval:checkEffectiveDate");
		}
		return bValid;
	}
	
	/**
	 * check the Effective Start Date
	 * @param context
	 * @param sPhysicalID
	 * @return
	 * @throws NKException_mxJPO
	 * @throws Exception
	 */

	public static Map<String, String> getComponentParts(Context context,DomainObject childObj) throws NKException_mxJPO 
	{
		logger.debug("Started getComponentParts Method");
		Map<String,String> returnMap = new HashMap<>();
		try 
		{
			//get 1 level MBOM and Attributes
			 String relPattern = "DELFmiFunctionIdentifiedInstance";
			 String typePattern = "CreateAssembly" + "," + "Provide";
	         StringList objSelects = new StringList(3);
	         objSelects.add(DomainConstants.SELECT_NAME);
	         objSelects.add(DomainConstants.SELECT_TYPE);
	         objSelects.add(DomainConstants.SELECT_ID);  
	         objSelects.add(DomainConstants.SELECT_CURRENT);
	         objSelects.add(DomainConstants.SELECT_OWNER);
	         objSelects.add(DomainConstants.SELECT_PHYSICAL_ID);
	         
	         StringList relSelects = new StringList();
	         relSelects.add(DomainConstants.SELECT_RELATIONSHIP_ID);
	         relSelects.add(NKConstants_mxJPO.BASIC_NUMBER);
	         relSelects.add(NKConstants_mxJPO.GATHERING_CLASS);

	         MapList mbomRelatedObject = childObj.getRelatedObjects(context, relPattern, 						                          // relationship pattern
	        		 														   typePattern,                                                   // object pattern
	        		 														   objSelects,                                                    // object selects
	        		 														   relSelects, 		                                              // relationship selects
	                                                                           true,                                                          // to direction
	                                                                           false,                                                          // from direction
	                                                                           (short) 0,                                                     // recursion level
	                                                                           "",                           								  // object where clause
	                                                                           "",
	                                                                           (short)0);


			for (Object mbomMap : mbomRelatedObject) 
			{
				Map<?, ?> mbomInfo = (Map<?, ?>) mbomMap;
	
			}
			
			logger.debug("Finished getComponentParts Method");
		} catch (Exception e) {
			logger.debug("Error in getComponentParts method:", e);
			throw new NKException_mxJPO("Exception in NKApproval:getComponentParts");
		}
		return returnMap;
	}
	
	
	/**
	 * check the scope link exists or not
	 * 
	 * @param context
	 * @param sPhysicalID
	 * @return
	 * @throws NKException_mxJPO
	 * @throws Exception
	 */
	public static String getChangeAction(Context context, String sPhysicalID) throws NKException_mxJPO {

		logger.debug("Started getChangeAction method");
		String strReturn = null;
		try {

			String sQuery = "query path type \"Proposed Activity.Where\" where \"element[0].physicalid=='" + sPhysicalID
					+ "'\" select element[0].pathid dump |";
			String sResult = MqlUtil.mqlCommand(context, sQuery);
			String[] resultArray = sResult.split("|");

			if(resultArray.length>0)
			{
				String pathId = resultArray[1];
				String caID = MqlUtil.mqlCommand(context,	"print path $1 select $2 dump $3",pathId, "owner.composer","|");
				if (caID!=null)
				{
					strReturn=caID;
				}
			}
		} catch (MatrixException e) {
			logger.debug("Error in getChangeAction method:", e);
			throw new NKException_mxJPO("Exception in NKApproval:getChangeAction");
		}
		logger.debug("Finished getChangeAction method");
		return strReturn;
	}
}
