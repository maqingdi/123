import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Properties;
import java.util.logging.FileHandler;
import java.util.logging.Formatter;
import java.util.logging.Level;
import java.util.logging.LogRecord;
import java.util.logging.Logger;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import com.matrixone.apps.domain.DomainConstants;
import com.matrixone.apps.domain.DomainObject;
import com.matrixone.apps.domain.util.FrameworkException;
import com.matrixone.apps.domain.util.MapList;
import com.matrixone.apps.domain.util.PropertyUtil;
import com.matrixone.apps.framework.ui.UIUtil;
import matrix.db.Context;
import matrix.db.Page;
import matrix.util.StringList;

public class NK_ProchemistIn_mxJPO{
	// Logger setup with proper exception handling
	private static final Logger logger = Logger.getLogger(NK_ProchemistIn_mxJPO.class.getName());
	private static FileHandler handler = null;
	// Constant values (configuration keys, schema properties, attribute selections)
	public static final String CONFIG_NK_PR_IMPORT_ITEM = "NK_PR_ImportItem";
	public static final String ERROR_OUTPUT_PROCESSING_FAILED = "Output processing failed. Please check the error message.";
	// Schema Properties
	public static final String TYPE_CREATE_ASSEMBLY = PropertyUtil.getSchemaProperty("type_CreateAssembly");
	public static final String TYPE_PROVIDED = PropertyUtil.getSchemaProperty("type_Provided");
	// Attribute Selections
	public static final String SELECT_MATERIAL_CLASSIFICATION = "NK_EXT_MBOM_BASE.NK_CONTAINED_MATERIAL_CLASSIFICATION_10";
	public static final String SELECT_NK_VERSION_ID = "attribute[NK_EXT_MBOM_BASE.NK_VERSION]";
	public static final String SELECT_V_PARTNUMBER = "attribute[EnterpriseExtension.V_PartNumber]";
	private static final String STATUS_REGISTERED = "registered";
	String successDir = null;
	String errorDir = null;

	/** 
	 * This method reads all the keys from the config file and initiate the logger and check multiple execution 
	 * @param  context the 3dx<code>Context</code>object.
	 * @param args contains property file  files
	 * @throws Exception
	 */
	public static void NK_RoHSTo3DEXP(Context context, String[] args) throws Exception {
		// Read configuration values
		String inputDir = readPageObject(context, CONFIG_NK_PR_IMPORT_ITEM, "INPUT_DIR");
		String logDir = readPageObject(context, CONFIG_NK_PR_IMPORT_ITEM, "LOG_DIR");
		String loggerLevel = readPageObject(context, CONFIG_NK_PR_IMPORT_ITEM, "Logger.Level");
		String successDir = readPageObject(context, CONFIG_NK_PR_IMPORT_ITEM, "SUCCESS_DIR");
		String errorDir = readPageObject(context, CONFIG_NK_PR_IMPORT_ITEM, "ERROR_DIR");
		// Initialize logger and validate directories
		initiateLogger(logDir, loggerLevel);
		validateDirectories(inputDir, successDir, errorDir);

		Path lockFilePath = Paths.get(inputDir, "process.lock");
		try {
			checkIfAlreadyRunning(lockFilePath);
			createLockFile(lockFilePath);	
			logger.log(Level.INFO, "Processing has started.(PR_I01001)");

			if (args.length != 1) {
				handleArgumentError(lockFilePath);
			}
			if (args[0] == null || args[0].isEmpty() || !args[0].endsWith(".properties")) {
				handlePropertyFileError(lockFilePath);
			}
            Path propertyFilePath = Paths.get(args[0]);
			if (!Files.exists(propertyFilePath)) {
				System.out.println("NK_ExportItem.properties does not exist in the specified path");
				logger.log(Level.INFO, "NK_ExportItem.properties does not exist in the specified path");
				cleanUp(lockFilePath);
				System.exit(0);
			}			
			updateAttribute(context,inputDir,lockFilePath,successDir,errorDir);
			System.out.println("Input processing completed.File (PR_I01002)");
			logger.log(Level.INFO, "Input processing completed.File (PR_I01002)");
		} catch (IOException e) {			
			e.printStackTrace();
			System.out.println("input processing failed. Please check the error message.(PR_I01003)");
			logger.log(Level.INFO, "input processing failed. Please check the error message.(PR_I01003)");
		} finally {
			cleanUpResources(lockFilePath);
		}
	}
	/**
	 * Cleans up resources, including the lock file and logger.
	 *
	 * @param lockFilePath The path of the lock file to delete.
	 */
	private static void cleanUpResources(Path lockFilePath) {
		try {
			cleanUp(lockFilePath);
		} catch (IOException e) {
			System.out.println("Failed to delete lock file.");
		} finally {
			cleanUpLogger();
		}
	}
	/**
	 * Checks if a process lock file exists and exits the program if it does.
	 *
	 * @param lockFilePath The path of the lock file to check.
	 * @throws IOException If an error occurs while checking the lock file.
	 */
	private static void checkIfAlreadyRunning(Path lockFilePath) throws IOException {
		if (Files.exists(lockFilePath)) {
			logger.log(Level.WARNING, "Program is already running.(PR_E01001)");
			logger.log(Level.WARNING, ERROR_OUTPUT_PROCESSING_FAILED);
			System.exit(1);
		}
	}
	/**
	 * Validates that the specified directories exist.
	 *
	 * @param dirs The directories to validate.
	 * @throws IOException If an error occurs during validation.
	 */
	private static void validateDirectories(String... dirs) throws IOException {
		for (String dir : dirs) {
			validateDirectory(dir);
		}
	}
	/**
	 * Updates item attributes by processing TSV files in the specified input directory.
	 * Successfully processed files are moved to the success directory, while files that 
	 * encounter errors are moved to the error directory.
	 *
	 * @param context        The context from which the method is called.
	 * @param inputDir      The directory containing input TSV files.
	 * @param lockFilePath  The path of the lock file to prevent concurrent processing.
	 * @param successDir    The directory where successfully processed files will be moved.
	 * @param errorDir      The directory where files that failed processing will be moved.
	 * @throws Exception If an error occurs during processing.
	 */
	private static void updateAttribute(Context context, String inputDir, Path lockFilePath, String successDir, String errorDir) throws Exception {
		Path inputDirectory = Paths.get(inputDir);
		try (Stream<Path> tsvFilesStream = Files.list(inputDirectory)
				.filter(file -> file.toString().endsWith(".tsv"))) {	        
			List<Path> tsvFiles = tsvFilesStream.collect(Collectors.toList());       
			for (Path tsvFilePath : tsvFiles) {       
				System.out.println("Processing file: " + tsvFilePath.getFileName());
				logger.log(Level.FINE, "Processing file: " + tsvFilePath.getFileName());
				boolean isSuccess = true;
				try {                
					isSuccess = processTsvFile(context, tsvFilePath, lockFilePath, errorDir);
				} catch (Exception e) {    
					isSuccess = false;
					logger.log(Level.SEVERE, "Error processing file: " + tsvFilePath.getFileName() + " - " + e.getMessage(), e);
				}	            
				if (isSuccess) {
					moveFileToDirectory(tsvFilePath, Paths.get(successDir));
					System.out.println("File successfully moved to Success directory: " + successDir);
					logger.log(Level.FINE, "The file: " + tsvFilePath + " moved to " + successDir + " successfully.");
				} else {	                
					try {
						moveFileToDirectory(tsvFilePath, Paths.get(errorDir));
						System.out.println("File moved to Error directory: " + errorDir);
						logger.log(Level.SEVERE, "The file: " + tsvFilePath + " moved to " + errorDir + " successfully.");
					} catch(Exception e) {
						System.out.println("Failed to move file to Error directory: " + errorDir);
						logger.log(Level.WARNING, "Failed to move file. (PR_E01007)");
					}
				}
			}
		} catch (IOException e) {
			logger.log(Level.SEVERE, "Error reading files in the directory: " + e.getMessage(), e);
		}
	}

	/**
	 * Processes a TSV file to update attributes in the system based on the provided data.
	 *
	 * @param context       The context used for domain operations.
	 * @param tsvFilePath  The path to the TSV file to be processed.
	 * @param lockFilePath The path to the lock file, which prevents concurrent processing.
	 * @param errorDir     The directory where error files will be moved if processing fails.
	 * @return true if processing is successful; false otherwise.
	 * @throws FrameworkException If an error occurs while processing the file.
	 */
	private static boolean processTsvFile(Context context, Path tsvFilePath, Path lockFilePath, String errorDir) throws FrameworkException {
		try {
			List<String> lines = Files.readAllLines(tsvFilePath);
			String[] headerColumns = lines.get(0).split("\t");
			int[] columnIndices = getColumnIndices(headerColumns);
			if (columnIndices == null) {
				logger.log(Level.SEVERE, "Missing 'ItemNo', 'Version', or other required columns in the header");
				return false;
			}
			Map<String, String> versionToLineMap = new HashMap<>();
			StringList versionIds = new StringList();
			StringBuilder whereConditionBuilder = new StringBuilder();

			for (int i = 1; i < lines.size(); i++) {
				String line = lines.get(i);
				if (!processLine(line, columnIndices, versionIds, versionToLineMap, whereConditionBuilder, i + 1)) {
					continue;
				}
			}
			if (whereConditionBuilder.length() == 0) {
				logger.log(Level.WARNING, "No valid ItemNo and Version pairs found.");
				return false;
			}
			MapList results = queryDomainObjects(context, whereConditionBuilder);
			if (!validateResults(results, lockFilePath, errorDir, tsvFilePath)) {
				return false;
			}
			return updateAttributesForObjects(context, results, versionToLineMap, lines, columnIndices ,tsvFilePath);
		} catch (IOException e) {
			logger.log(Level.SEVERE, "Error reading the TSV file: " + tsvFilePath.getFileName() + " - " + e.getMessage(), e);
		}
		return true;
	}

	/**
	 * Gets the indices of the required columns from the header.
	 *
	 * @param headerColumns The array of header columns.
	 * @return An array of column indices, or null if required columns are missing.
	 */
	private static int[] getColumnIndices(String[] headerColumns) {
		int itemNoIndex = -1, versionIndex = -1, partNameIndex = -1;
		int surveyStatusIndex = -1, contentOverallJudgmentIndex = -1, usageThresholdJudgmentIndex = -1;

		for (int i = 0; i < headerColumns.length; i++) {
			switch (headerColumns[i].trim()) {
			case "ItemNo": itemNoIndex = i; break;
			case "Version": versionIndex = i; break;
			case "PartName": partNameIndex = i; break;
			case "Survey Status": surveyStatusIndex = i; break;
			case "Content Overall Judgment": contentOverallJudgmentIndex = i; break;
			case "Usage Threshold Judgment": usageThresholdJudgmentIndex = i; break;
			default:
				logger.log(Level.WARNING, "Unrecognized header: " + headerColumns[i]);
				break;
			}
		}

		if (itemNoIndex == -1 || versionIndex == -1 || partNameIndex == -1 || 
				surveyStatusIndex == -1 || contentOverallJudgmentIndex == -1 || 
				usageThresholdJudgmentIndex == -1) {
			return null;
		}

		return new int[]{itemNoIndex, versionIndex, partNameIndex, surveyStatusIndex, contentOverallJudgmentIndex, usageThresholdJudgmentIndex};
	}

	/**
	 * Processes a single line of the TSV file to extract values and build the where condition.
	 *
	 * @param line               The line to process.
	 * @param columnIndices      The indices of the relevant columns.
	 * @param versionIds         A list to store version IDs.
	 * @param versionToLineMap   A map to associate versions with their lines.
	 * @param whereConditionBuilder The StringBuilder to construct the WHERE condition.
	 * @param lineNumber         The line number for logging.
	 * @return true if the line was processed successfully; false otherwise.
	 */
	private static boolean processLine(String line, int[] columnIndices, StringList versionIds, 
			Map<String, String> versionToLineMap, StringBuilder whereConditionBuilder, 
			int lineNumber) {
		String[] values = line.split("\t");
		if (values.length < columnIndices.length) {
			logger.log(Level.WARNING, "Line " + lineNumber + " does not contain enough columns: " + line);
			return false;
		}
		String itemNo = values[columnIndices[0]].trim();  
		String version = values[columnIndices[1]].trim(); 
		versionIds.add(version);
		versionToLineMap.put(version, line);

		if (UIUtil.isNullOrEmpty(itemNo) || UIUtil.isNullOrEmpty(version)) {
			logger.log(Level.SEVERE, "Error: 'ItemNo' or 'Version' is missing or empty in line " + lineNumber + ": " + line);
			return true;
		}

		if (whereConditionBuilder.length() > 0) {
			whereConditionBuilder.append("||");
		}
		whereConditionBuilder.append(buildWhereCondition(itemNo, version));
		return true;
	}

	/**
	 * Queries the domain objects based on the specified where condition.
	 *
	 * @param context              The context used for domain operations.
	 * @param whereConditionBuilder The StringBuilder containing the WHERE condition.
	 * @return The results of the query as a MapList.
	 * @throws FrameworkException 
	 */
	private static MapList queryDomainObjects(Context context, StringBuilder whereConditionBuilder) throws FrameworkException {
		StringList objectSelects = new StringList();
		objectSelects.add(DomainConstants.SELECT_ID);
		objectSelects.add(SELECT_V_PARTNUMBER);
		objectSelects.add(SELECT_NK_VERSION_ID);

		return DomainObject.findObjects(context, "CreateAssembly,Provided", null, 
				whereConditionBuilder.toString(), objectSelects, (short) 0, null);
	}

	/**
	 * Updates attributes for the domain objects based on the processed TSV data.
	 *
	 * @param context           The context used for domain operations.
	 * @param results           The results of the domain object query.
	 * @param versionToLineMap  A map to associate versions with their lines.
	 * @param lines             The original lines of the TSV file.
	 * @param columnIndices     The indices of the relevant columns.
	 * @param tsvFilePath 
	 * @return true if all attributes were updated successfully; false otherwise.
	 */
	private static boolean updateAttributesForObjects(Context context, MapList results, 
			Map<String, String> versionToLineMap, 
			List<String> lines, int[] columnIndices, Path tsvFilePath ) {
		for (Object obj : results) {
			Map<?, ?> objectMap = (Map<?, ?>) obj;
			String versionId = (String) objectMap.get(SELECT_NK_VERSION_ID);
			String line = versionToLineMap.get(versionId);

			if (line != null) {
				String[] values = line.split("\t");
				String surveyStatus = values[columnIndices[3]].trim();  
				String contentOverallJudgment = values[columnIndices[4]].trim();  
				String usageThresholdJudgment = values[columnIndices[5]].trim();  
				String partName = values[columnIndices[2]].trim(); 

				String attributeValue = determineAttributeValue(surveyStatus, contentOverallJudgment, usageThresholdJudgment);
				if (attributeValue != null) {
					if (!updateAttribute(context, objectMap, attributeValue, versionToLineMap, lines, line, versionId, partName, tsvFilePath)) {
						return false;
					}
				}
			} else {
				logger.log(Level.WARNING, "No matching line found for version ID: " + versionId);
			}
		}
		return true;
	}

	/**
	 * Updates the attribute value of a domain object.
	 *
	 * @param context             The context used for domain operations.
	 * @param objectMap          The object map containing the domain object data.
	 * @param attributeValue      The value to set for the attribute.
	 * @param versionToLineMap    A map to associate versions with their lines.
	 * @param lines               The original lines of the TSV file.
	 * @param line                The line corresponding to the version ID.
	 * @param versionId           The version ID of the object.
	 * @param partName            The part name associated with the line.
	 * @param tsvFilePath 
	 * @return true if the attribute was updated successfully; false otherwise.
	 */
	private static boolean updateAttribute(Context context, Map<?, ?> objectMap, String attributeValue, 
			Map<String, String> versionToLineMap, List<String> lines, 
			String line, String versionId, String partName, Path tsvFilePath) {
		try {
			String objectId = (String) objectMap.get("id");
			DomainObject domainObject = DomainObject.newInstance(context, objectId);
			Map<?, ?> attributeMap = domainObject.getAttributeMap(context);

			if (attributeMap.containsKey(SELECT_MATERIAL_CLASSIFICATION)) {
				domainObject.setAttributeValue(context, SELECT_MATERIAL_CLASSIFICATION, attributeValue);
				return true;
			} else {
				logAttributeError(tsvFilePath, versionToLineMap, versionId, partName, lines, line);
				return false;
			}
		} catch (Exception e) {
			logAttributeError(tsvFilePath, versionToLineMap, versionId, partName, lines, line);
			return false;
		}
	}

	/**
	 * Determines the attribute value based on the survey status and judgment fields.
	 * 
	 * @param surveyStatus               The survey status of the item.
	 * @param contentOverallJudgment     The content overall judgment value.
	 * @param usageThresholdJudgment     The usage threshold judgment value.
	 * @return The determined attribute value or null if no valid attribute value is found.
	 */
	private static String determineAttributeValue(String surveyStatus, String contentOverallJudgment, String usageThresholdJudgment) {
		if (surveyStatus.equalsIgnoreCase("unexamined") 
				&& UIUtil.isNullOrEmpty(contentOverallJudgment) 
				&& UIUtil.isNullOrEmpty(usageThresholdJudgment)) {
			return "1";
		} else if (surveyStatus.equalsIgnoreCase("pending") 
				&& UIUtil.isNullOrEmpty(contentOverallJudgment) 
				&& UIUtil.isNullOrEmpty(usageThresholdJudgment)) {
			return "2";
		} else if (surveyStatus.equalsIgnoreCase("under investigation") 
				&& UIUtil.isNullOrEmpty(contentOverallJudgment) 
				&& UIUtil.isNullOrEmpty(usageThresholdJudgment)) {
			return "3";
		} else if (surveyStatus.equalsIgnoreCase(STATUS_REGISTERED) 
				&& contentOverallJudgment.equalsIgnoreCase("Y") 
				&& usageThresholdJudgment.equalsIgnoreCase("Y")) {
			return "4";
		} else if (surveyStatus.equalsIgnoreCase(STATUS_REGISTERED) 
				&& contentOverallJudgment.equalsIgnoreCase("Y") 
				&& usageThresholdJudgment.equalsIgnoreCase("N")) {
			return "5";
		} else if (surveyStatus.equalsIgnoreCase(STATUS_REGISTERED) 
				&& contentOverallJudgment.equalsIgnoreCase("N") 
				&& UIUtil.isNullOrEmpty(usageThresholdJudgment)) {
			return "6";
		}
		return null;
	}

	/**
	 * Logs an error when updating the item attribute value fails.
	 *
	 * @param tsvFilePath      The path of the TSV file being processed.
	 * @param versionToLineMap A map that associates version IDs with their respective line in the file.
	 * @param sVersionId       The version ID associated with the item being processed.
	 * @param partName         The name of the part associated with the item.
	 * @param lines            A list of lines read from the TSV file.
	 * @param line             The specific line from which the error occurred.
	 */
	private static void logAttributeError(Path tsvFilePath, Map<String, String> versionToLineMap, String sVersionId, String partName, List<String> lines, String line) {
		System.err.println(String.format("Failed to update the item attribute value. Attribute: %s\n"
				+ "File Name: %s\nLine Number: %d\nPartName: %s\nVersion: %s",
				SELECT_MATERIAL_CLASSIFICATION,
				tsvFilePath.getFileName(), (versionToLineMap.get(sVersionId) != null ? lines.indexOf(line) + 1 : -1),
				partName, sVersionId)+" (PR_E01006)");
		logger.log(Level.SEVERE, "Failed to update the item attribute value. Attribute: NK_EXT_MBOM_BASE.NK_CONTAINED_MATERIAL_CLASSIFICATION_10 \n File Name: " 
				+ tsvFilePath.getFileName() + " Line Number: " + (versionToLineMap.get(sVersionId) != null ? lines.indexOf(line) + 1 : -1) 
				+ " \n PartName: " + partName + "\n Version: " + sVersionId+" (PR_E01006)");
	}


	/**
	 * to validate the results 
	 * @param mlResults - holds all the objects which passed where condition 
	 * @param errorDir 
	 * @param tsvFilePath 
	 * @param tempFilePath - Holds the data in this temporary file .
	 * @throws IOException
	 */
	private static boolean  validateResults(MapList mlResults, Path lockFilePath, String errorDir, Path tsvFilePath  ) throws IOException {
		if (!mlResults.iterator().hasNext()) { 
			logger.log(Level.WARNING, "Not found the target item.(PR_E01005)"); 
			logger.log(Level.WARNING, ERROR_OUTPUT_PROCESSING_FAILED);			
			return false;
		}
		return true;
	}

	/**
	 * This method builds the where condition for each pair of itemNo and version.
	 *
	 * @param itemNo the Item Number to search for
	 * @param version the Version Number to search for
	 * @return the where condition as a string
	 */
	private static String buildWhereCondition(String itemNo, String version) {
		return "(" 
				+ "attribute[EnterpriseExtension.V_PartNumber].value=='"+itemNo+"'"
				+ "&&"
				+ "attribute[NK_EXT_MBOM_BASE.NK_VERSION].value=='"+version+"'"
				+ ")";
	}

	/**
	 * Moves a file to a specified directory.
	 *
	 * @param filePath   The path of the file to move.
	 * @param targetDir  The target directory where the file will be moved.
	 * @throws IOException If an error occurs during file move operation.
	 */
	private static void moveFileToDirectory(Path filePath, Path targetDir) throws IOException {
		if (!Files.exists(targetDir)) {
			Files.createDirectories(targetDir);
		}
		Path targetPath = targetDir.resolve(filePath.getFileName());
		Files.move(filePath, targetPath, StandardCopyOption.REPLACE_EXISTING);
	}

	/**
	 * @param lockFilePath to check multiple instance running and delete 
	 * @throws IOException
	 */
	private static void createLockFile(Path lockFilePath) throws IOException {
		try {
			Files.createFile(lockFilePath);
		} catch (IOException e) {
			System.out.println("Failed to create lock file. Exiting...");
			System.exit(1);
		}
	}	
	/**
	 * check the Property File Error
	 * @param lockFilePath to check multiple instance running and delete 
	 * @throws IOException
	 */
	private static void handlePropertyFileError(Path lockFilePath) throws IOException {
		logger.log(Level.WARNING, "Could not read NK_ExportItem.properties.(PR_E01003)");
		cleanUp(lockFilePath);
		System.exit(0);
	}
	/**
	 * prints the Argument Error 
	 * @param lockFilePathto check multiple instance running and delete 
	 * @throws IOException
	 */
	private static void handleArgumentError(Path lockFilePath) throws IOException {
		logger.log(Level.WARNING, "Not enough arguments. (PR_E01002)");
		cleanUp(lockFilePath);
		System.exit(0);
	}

	/**
	 * @param lockFilePath to check multiple instance running and delete 
	 * @throws IOException
	 */
	private static void cleanUp(Path lockFilePath) throws IOException {
		Files.deleteIfExists(lockFilePath);
		if (handler != null) {
			handler.close();
		}
	}
	/**
	 * Read Page object from the DB 
	 *
	 * @param context
	 * @param strPageName - Name of the page file 
	 * @param strKeyName - key name present in the page file 
	 * @throws Exception
	 */
	public static String readPageObject(Context context, String strPageName, String strKeyName) throws Exception {
		Properties propNotification = new Properties();
		String strProperty = DomainConstants.EMPTY_STRING;
		try {
			Page pageAttributePopulation = new Page(strPageName);
			pageAttributePopulation.open(context);
			String strProperties = pageAttributePopulation.getContents(context);
			pageAttributePopulation.close(context);
			InputStream input = new ByteArrayInputStream(strProperties.getBytes("UTF8"));
			propNotification.load(input);
			if(propNotification.containsKey(strKeyName)) {
				strProperty = propNotification.getProperty(strKeyName);
			}else {
				logger.log( Level.INFO, strKeyName +"IS NOT PRESENT");			
				System.exit(0);			
			}
		} catch (Exception e) {
			System.out.println("Check page file name");
			e.printStackTrace();
		}
		return strProperty;
	}
	/**
	 * @param dir holds the output directory path 
	 */
	private static void validateDirectory(String dir) {
	    File file = new File(dir);
	    if (!file.exists() || !file.isDirectory()) { 
	        logger.log(Level.WARNING, "Not found the destination folder path. (PR_E01004) Check InputDir, Success Dir, Error Dir paths.");
	        System.exit(0);
	    }
	}
	/**
	 * 
	 * @param logDir - path specified to print the logs 
	 * @param loggerLevel
	 * @throws IOException
	 */
	private static void initiateLogger(String logDir , String loggerLevel ) throws IOException {
		if (handler != null) {
			handler.close(); 
		}
		LocalDateTime now = LocalDateTime.now();
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyyMMddHHmmss");
		String formattedDate = now.format(formatter);	
		String path = logDir + "/Logs";
		handler = new FileHandler(path + formattedDate + ".log", true);
		handler.setFormatter(new HD_LoggingFormatter());
		handler.setEncoding("UTF-8");
		logger.addHandler(handler);
		String level = loggerLevel != null && !loggerLevel.isEmpty() ? loggerLevel : "INFO";
		logger.setLevel(Level.parse(level));

	}
	private static void cleanUpLogger() {
		if (handler != null) {
			handler.close();
			logger.removeHandler(handler);
			handler = null;
		}
	}
	/**
	 * 
	 * @author DSGS
	 *
	 */
	private static class HD_LoggingFormatter extends Formatter {
		@Override
		public String format(LogRecord record) {
			StringBuilder sb = new StringBuilder();
			sb.append(record.getLevel()).append(',');
			sb.append(record.getMessage()).append('\n');
			return sb.toString();
		}
	}
}
