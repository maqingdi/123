import java.util.*;
import com.matrixone.apps.domain.DomainConstants;
import com.matrixone.apps.domain.DomainObject;
import com.matrixone.apps.domain.util.MapList;
import com.matrixone.apps.domain.util.MqlUtil;
import com.matrixone.apps.domain.util.StringUtil;
import matrix.db.Context;
import matrix.util.MatrixException;
import matrix.util.StringList;
import com.matrixone.apps.domain.util.ContextUtil;

public class NKProcessRevision_mxJPO {

	/**
	 * This method is used to copyMBOMattributes to Workplan in FROZEN action
	 * state
	 * 
	 * @param context
	 *            the ENOVIA <code>Context</code> object.
	 * @param args
	 *            [0] holds the document objectId. [1] holds the action
	 * @throws Exception
	 *             if operation fails.
	 * @exclude
	 */
	private final static String TYPEWORKPLAN="DELLmiWorkPlanSystemReference";
	private final static String BRANCH_NUMBER="NK_EXT_PROCESS.NK_BRANCH_NUMBER";
	
	public void copyMBOMattributes(Context context, String args[])throws NKException_mxJPO 
	{
		try {
			String strObjectId = args[0];
			String physicalId = "physicalid";
			StringList scopeLinks = null;
			Map<String, String> updateAttributeMap = new HashMap<String, String>();

			//Copyinh MBOM attributes to Workplan
			DomainObject dobj = DomainObject.newInstance(context, strObjectId);
			String wpPhysicalID = dobj.getInfo(context, physicalId);
			String sPhysicalID = dobj.getInfo(context,"from[VPLMrel/PLMConnection/V_Owner].to.physicalid");
			scopeLinks = hasScopeLink(context, wpPhysicalID);
			if (sPhysicalID != null && !sPhysicalID.isEmpty() && !scopeLinks.isEmpty()) 
			{
				String strpaths = MqlUtil.mqlCommand(context,"print bus $1 select $2 dump $3", sPhysicalID,"paths.*", "|");
				List<String> slPaths = StringUtil.split(strpaths, "|");

				if (slPaths != null && !slPaths.isEmpty()) 
				{
					String strAssembly = slPaths.get(1);
					if (strAssembly != null && !strAssembly.isEmpty()) 
					{
						List<String> slAssmb = StringUtil.split(strAssembly,",");
						String strAssmPhysicalID = slAssmb.get(2);
						String strObject = MqlUtil.mqlCommand(context,	"print bus $1 select $2 dump",strAssmPhysicalID, "id");
						DomainObject doAssmbly = DomainObject.newInstance(context, strObject);
						Map<?, ?> attributeMap = doAssmbly.getAttributeMap(context);

						if (attributeMap.size() != 0 && !attributeMap.isEmpty()) 
						{						
							updateAttributeMap.put("NK_EXT_PROCESS.NK_PARTS_CODE", (String) attributeMap.get("EnterpriseExtension.V_PartNumber"));
							updateAttributeMap.put("NK_EXT_PROCESS.NK_PLANT", (String) attributeMap.get("NK_EXT_MBOM_REVISION_SYSTEM.NK_PLANT"));
							updateAttributeMap.put("NK_EXT_PROCESS.NK_REVISION", (String) attributeMap.get("NK_EXT_MBOM_BASE.NK_REVISION"));
							updateAttributeMap.put("NK_EXT_PROCESS.NK_VERSION", attributeMap.get("NK_EXT_MBOM_BASE.NK_VERSION").toString().trim().replaceAll("[-]", ""));
							ContextUtil.pushContext(context, "User Agent", null, null);
							dobj.setAttributeValues(context, updateAttributeMap);
							
						}
					}
				}
			}
			
			Map<?, ?> wrkattributeMap = dobj.getAttributeMap(context);
			selectBranchAttribute(context,wrkattributeMap,strObjectId);
			ContextUtil.popContext(context);
		}
		catch (Exception e) {
			throw new NKException_mxJPO("Exception in NK_Process_Revision:copyMBOMattributes");
		}

	}
	
	/**
	 * select the criteria for Branch Attributes.
	 *
	 * @param context
	 * @param strPageName
	 * @param strKeyName
	 * @throws Exception
	 */
			
	public void selectBranchAttribute(Context context, Map<?,?> wrkattributeMap,String strObjectId)throws NKException_mxJPO 
	{
		try
		{
							String itemCode = (String) wrkattributeMap.get("NK_EXT_PROCESS.NK_PARTS_CODE");
							String bopType =  (String) wrkattributeMap.get("NK_EXT_PROCESS.NK_BOP_TYPE");
							String plant = (String) wrkattributeMap.get("NK_EXT_PROCESS.NK_PLANT");
							String revision = (String) wrkattributeMap.get("NK_EXT_PROCESS.NK_REVISION");
							String version = (String) wrkattributeMap.get("NK_EXT_PROCESS.NK_VERSION");
							String altBOM =  (String) wrkattributeMap.get("NK_EXT_PROCESS.NK_ALT_BOM");
							String finalBranchNumber = (String) wrkattributeMap.get(BRANCH_NUMBER);	

			if(wrkattributeMap.size() != 0 && !wrkattributeMap.isEmpty()&&finalBranchNumber.equals("0")&&bopType !=null && !bopType.isEmpty() && altBOM!=null && !altBOM.isEmpty() && itemCode!=null && !itemCode.isEmpty() && plant!=null && !plant.isEmpty())
			{
			
									String checkCriteria = itemCode+bopType+plant+revision+version+altBOM;	
									StringList slSelects = new StringList();
									slSelects.add(DomainConstants.SELECT_ID);
									slSelects.add("attribute[NK_EXT_PROCESS.NK_PARTS_CODE]");
									slSelects.add("attribute[NK_EXT_PROCESS.NK_BOP_TYPE]");
									slSelects.add("attribute[NK_EXT_PROCESS.NK_PLANT]");
									slSelects.add("attribute[NK_EXT_PROCESS.NK_REVISION]");
									slSelects.add("attribute[NK_EXT_PROCESS.NK_VERSION]");
									slSelects.add("attribute[NK_EXT_PROCESS.NK_ALT_BOM]");
									slSelects.add("attribute[NK_EXT_PROCESS.NK_BRANCH_NUMBER]");
									MapList mlworkPlan = DomainObject.findObjects(context, TYPEWORKPLAN, "*", "*", DomainConstants.QUERY_WILDCARD,
											null, "", false, slSelects);
						
									mlworkPlan = removeCurrentWorkPlan(strObjectId,mlworkPlan);							
									MapList matchWorkplan = new MapList();
									
									for(Object obj : mlworkPlan)
									{
										Map<?, ?> mpworkPlan = (Map<?, ?>)obj;
										String sitemCode = (String) mpworkPlan.get("attribute[NK_EXT_PROCESS.NK_PARTS_CODE]");
										String sbopType =  (String) mpworkPlan.get("attribute[NK_EXT_PROCESS.NK_BOP_TYPE]");
										String splant = (String) mpworkPlan.get("attribute[NK_EXT_PROCESS.NK_PLANT]");
										String srevision = (String) mpworkPlan.get("attribute[NK_EXT_PROCESS.NK_REVISION]");
										String sversion = (String) mpworkPlan.get("attribute[NK_EXT_PROCESS.NK_VERSION]");
										String saltBOM =  (String) mpworkPlan.get("attribute[NK_EXT_PROCESS.NK_ALT_BOM]");
											
										if(sbopType !=null && !sbopType.isEmpty() && saltBOM!=null && !saltBOM.isEmpty() && sitemCode!=null && !sitemCode.isEmpty() && splant!=null && !splant.isEmpty() && srevision!=null && !srevision.isEmpty() && sversion!=null && !sversion.isEmpty() )
										{
											String validateCriteria = sitemCode+sbopType+splant+srevision+sversion+saltBOM;
												if(validateCriteria!=null && checkCriteria.equals(validateCriteria))
												{													
													matchWorkplan.add(mpworkPlan);
													
												}

										}
										
									}
									updateBranchAttribute(context,matchWorkplan,strObjectId);
									
					}						
	
		}
		catch (Exception e) {
			throw new NKException_mxJPO("Exception in NK_Process_Revision:selectBranchAttribute");
		}
	}
	
	/**
	 * update the Branch Attributes.
	 *
	 * @param context
	 * @param strPageName
	 * @param strKeyName
	 * @throws Exception
	 */
	public void updateBranchAttribute(Context context, MapList matchWorkplan,String strObjectId)throws NKException_mxJPO 
	{
		try
		{
			if(!matchWorkplan.isEmpty())
			{
				StringList slworkPlan = new StringList();
				for(Object obj : matchWorkplan)
				{
					Map<?, ?> matworkPlan = (Map<?, ?>)obj;
					String sBranchNo =  (String) matworkPlan.get("attribute[NK_EXT_PROCESS.NK_BRANCH_NUMBER]");
					sBranchNo=removeLeadingZeroes(sBranchNo);
					slworkPlan.add(sBranchNo);
				}
				int sBrnNo=gethighestBranchNo(slworkPlan);
				sBrnNo++;
				String sbranchNumber = String.valueOf(sBrnNo);
				MqlUtil.mqlCommand(context,	"mod bus $1 $2 $3",strObjectId, BRANCH_NUMBER,sbranchNumber);
			}
			else
			{
				MqlUtil.mqlCommand(context,	"mod bus $1 $2 $3",strObjectId, BRANCH_NUMBER,"1");
			}

		}catch (Exception e) {
			throw new NKException_mxJPO("Exception in NK_Process_Revision:updateBranchAttribute");
		}

		
	}
	

	/**
	 * check the scope link exists or not
	 * 
	 * @param context
	 * @param sPhysicalID
	 * @return
	 * @throws NKException_mxJPO 
	 * @throws Exception
	 */
	public static StringList hasScopeLink(Context context, String sPhysicalID) throws NKException_mxJPO
	{
	
		StringList slReturn = null;
		try {

			String sQuery = "query path type SemanticRelation where \"element[0].physicalid=='"
					+ sPhysicalID + "'\" select element[0].pathid dump |";
			String sResult = MqlUtil.mqlCommand(context, sQuery);
			slReturn = StringUtil.split(sResult, "\n");

		} catch (MatrixException e) {
			throw new NKException_mxJPO("Exception in NK_Process_Revision:hasScopeLink");
		}
		return slReturn;
	}

	/**
	 * get Highest Branch Number from the list
	 *
	 * @param context
	 * @param strPageName
	 * @param strKeyName
	 * @throws Exception
	 */
	public static int gethighestBranchNo(StringList slworkPlan) throws NKException_mxJPO 
	{
		int rBrNo = 0;
		try {
			if(!slworkPlan.isEmpty())
			{
				slworkPlan.sort();
				for(String temp: slworkPlan)
				{
					String str = slworkPlan.lastElement();
					rBrNo=Integer.parseInt(str);
				}
			}
		} catch (Exception e) {

			throw new NKException_mxJPO("Exception in NK_Process_Revision:gethighestBranchNo");
		}
		return rBrNo;
	}
	
	/**
	 * Remove current workplan from All workplan.
	 *
	 * @param context
	 * @param strPageName
	 * @param strKeyName
	 * @throws Exception
	 */
	public static MapList removeCurrentWorkPlan(String strObjectId,MapList mlreturnPlan) throws NKException_mxJPO 
	{

		StringList slreturnPlan = new StringList();
		try 
		{		
			for (Iterator<?> iterator = mlreturnPlan.iterator(); iterator.hasNext();) 
			{
				Map<?, ?> mpworkPlan = (Map<?, ?>) iterator.next();
				String strID = (String) mpworkPlan.get(DomainConstants.SELECT_ID);
				slreturnPlan.add(strID);
				if(slreturnPlan.contains(strObjectId))
				{
					iterator.remove();
				}
			}

		} catch (Exception e) {

			throw new NKException_mxJPO("Exception in NK_Process_Revision:removeCurrentWorkPlan");
		}
		return mlreturnPlan;
	}
	
	/**
	 * Remove 0's from Branch Number .
	 *
	 * @param number
	 *
	 */
	
	 public static String removeLeadingZeroes(String str) 
	 {
		 try
		 {
		      String strPattern = "^0+(?!$)";
		      str = str.replaceAll(strPattern, "");
	      } catch (Exception e)
		 {
	    	  e.printStackTrace();
	     }
	      return str;
	 }


}