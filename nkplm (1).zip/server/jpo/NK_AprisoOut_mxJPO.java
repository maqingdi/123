import com.matrixone.apps.domain.DomainConstants;
import com.matrixone.apps.domain.DomainObject;
import com.matrixone.apps.domain.util.EnoviaResourceBundle;
import com.matrixone.apps.domain.util.FrameworkException;
import com.matrixone.apps.domain.util.FrameworkUtil;
import com.matrixone.apps.domain.util.MapList;
import com.matrixone.apps.framework.ui.UIUtil;
import matrix.db.*;
import matrix.util.StringList;
import java.io.File;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.Set;
import java.util.logging.Formatter;
import java.util.logging.*;
/**
 * Author - DSGS
 */
public class NK_AprisoOut_mxJPO {
    private static Logger logger = Logger.getLogger(NK_AprisoOut_mxJPO.class.getName());
    private static FileHandler handler = null;
    private static String fileName = null;
    private static String NK_ME_EXPORT = "NK_ME_Export";
    private static String ME_PARTS = "ME_Parts";
    private static String ME_BASE = "ME_BASE";
    private static String ME_TOOLS = "ME_Tools";
    private static String NK_REVISION = "NK_EXT_MBOM_BASE.NK_REVISION";
    private static String OOTBREVISION = "revision=='last'";
    private static String ERRORMESSAGE = "Output processing failed. Please check the error message.";
    private static String OUTPUTNUMBER = " , OutputNumber: ";
    private static int outputPartsNo = 0;
    private static int outputBaseNo = 0;
    private static int outputToolsNo =  0 ;
    public static void NK_MESLinkageExportTSV(Context context, String[] args) throws Exception {
        String outputDir = readPageObject(context, NK_ME_EXPORT, "OUTPUT_DIR");
        String outputPartsFile = readPageObject(context, NK_ME_EXPORT, "OUTPUT_PARTS_FILE");
        String outputBasePartsFile = readPageObject(context, NK_ME_EXPORT, "OUTPUT_BASE_PARTS_FILE");
        String outputToolGroupFile = readPageObject(context, NK_ME_EXPORT, "OUTPUT_TOOL_GROUP_FILE");
        String logDir = readPageObject(context, NK_ME_EXPORT, "LOG_DIR");
        String loggerLevel = readPageObject(context, NK_ME_EXPORT, "Logger.Level");
        initiateLogger(logDir, loggerLevel);
        validateDirectory(outputDir);
        Path lockFilePath = Paths.get(outputDir, "process.lock");
        try {
            if (Files.exists(lockFilePath)) {
                log(Level.WARNING, " Program is already running.(ME_E00001)");
                log(Level.WARNING, ERRORMESSAGE);
                System.exit(1);
            }
            createLockFile(lockFilePath);
            log(Level.INFO, " Processing has started.(ME_I00001)");
            argumentError(args,lockFilePath);
            if (args.length == 4) {
                validateFileArgument(args[0], lockFilePath, outputDir, outputBasePartsFile, outputPartsFile ,outputToolGroupFile);
            } else if (args.length > 4) {
                handleTooManyArguments(lockFilePath);
            }
            appendToTSV(args, context, outputDir, outputPartsFile, outputBasePartsFile, outputToolGroupFile, lockFilePath);
            logOutputDetails(outputPartsFile, outputPartsNo, outputBasePartsFile, outputBaseNo, outputToolGroupFile, outputToolsNo );
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            try {
                cleanUp(lockFilePath);
            } catch (IOException e) {
                System.out.println("Failed to delete lock file.");
            }
        }
    }

    /**
     * @param dir holds the output directory path
     *            Validating the output directory
     */
    private static void validateDirectory(String dir) {
        File file = new File(dir);
        if (file.exists() && file.isDirectory()) {
            log(Level.INFO, "outputDir " + dir);
        } else {
            log(Level.WARNING, "Not found the destination folder path.(ME_E00004)");
            System.exit(0);
        }
    }

    /**
     * Processes multiple input files, collects attributes, appends them to a temporary file in TSV format,
     * and moves the resulting file to its final destination based on the file type (Parts, Base Parts, or Tools).
     * If an error occurs, performs cleanup and handles exceptions.
     *
     * @param args                 Array of input arguments. Each index contains the file path to be processed.
     * @param context              The context of the current session, used to interact with the 3DEXPERIENCE platform.
     * @param outputDir            Directory where the output files will be saved.
     * @param outputPartsFile      Output file name for the parts information.
     * @param outputBasePartsFile  Output file name for the base parts information.
     * @param outputToolGroupFile  Output file name for the tool group information.
     * @param lockFilePath         Path to the lock file used to control multiple executions of the process.
     * @throws IOException         If an I/O error occurs while reading or writing files.
     */
    private static void appendToTSV(String[] args, Context context, String outputDir, String outputPartsFile,
                                    String outputBasePartsFile, String outputToolGroupFile, Path lockFilePath) throws IOException {
        for (int i = 1; i <= 3; i++) {
            String filePath = args[i];
            String tempOutputFileName = generateTempFileName();
            Path tempFilePath = Paths.get(outputDir, tempOutputFileName);
            StringBuilder sb = new StringBuilder();
            int outputNumber = 0 ;
            try (BufferedWriter writer = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(tempFilePath.toFile()), StandardCharsets.UTF_8))) {
                Path outputPath = Paths.get(outputDir);
                Files.createDirectories(outputPath);
                StringList slAttributes = new StringList();
                try (BufferedReader br = new BufferedReader(new FileReader(filePath))) {
                    processFixLine(sb, br, slAttributes);
                    String stype = getStypeFromFilePath(filePath);
                    String sWhere = getWhereConditionFromFilePath(filePath);
                    StringList objectSelects = new StringList();
                    objectSelects.add(DomainConstants.SELECT_ID);
                    MapList mpList = DomainObject.findObjects(context, stype, null, sWhere, objectSelects);
                    Iterator<?> itr = mpList.iterator();
                    handleNullIterator(mpList, writer , tempFilePath , lockFilePath );
                    sb.append("\n");
                    boolean flag = false;
                    MapList revisionMapList = new MapList();
                    while (itr.hasNext()) {
                        Map<String, String> objectMap = (Map<String, String>) itr.next();
                        String strObjID = objectMap.get("id");
                        DomainObject doID = DomainObject.newInstance(context, strObjID);
                        Map<String, Object> attributeMap = getObjectAttributes(context, doID);
                        if (filePath.contains(ME_TOOLS)) {
                            flag =  appendAttributesToBuffer(sb, slAttributes, attributeMap, filePath, writer, tempFilePath, lockFilePath, outputNumber , flag , context);
                            outputNumber =   flagCount(flag  , sb, outputNumber , filePath);
                        }
                        collectNK_Revisions(attributeMap, strObjID, revisionMapList);
                    }
                    if (filePath.contains(ME_PARTS) || filePath.contains(ME_BASE)) {
                        flag = handleHighestRevision(sb, slAttributes, revisionMapList, filePath, context, writer, tempFilePath, lockFilePath , flag);
                        outputNumber =   flagCount(flag  , sb, outputNumber, filePath);
                    }
                } catch (IOException e) {
                    log(Level.INFO, "Could not read attributes definition file.");
                    log(Level.WARNING, ERRORMESSAGE);
                    cleanupAndExit(writer, tempFilePath, lockFilePath);
                }
                writer.append(sb.toString());
                writer.close();
                moveFileToFinalPath(filePath, outputPartsFile, outputBasePartsFile, outputToolGroupFile, tempFilePath, Path.of(outputDir), lockFilePath);
            } catch (Exception e) {
                e.printStackTrace();
                Files.delete(tempFilePath);
                cleanUp(lockFilePath);
                log(Level.WARNING, ERRORMESSAGE);
                System.exit(0);
            }
        }
    }

    /**
     * Moves a temporary file to its final destination based on the file path type (Parts, Base Parts, or Tools).
     * If an error occurs during the file move operation, logs a warning and performs error cleanup.
     *
     * @param filePath              The path of the input file to determine the output file type (Parts, Base Parts, or Tools).
     * @param outputPartsFile       The name of the output file for Parts.
     * @param outputBasePartsFile   The name of the output file for Base Parts.
     * @param outputToolGroupFile   The name of the output file for Tools.
     * @param tempFilePath          The temporary file path to be moved to the final destination.
     * @param outputDir             The directory where the final file should be moved.
     * @param lockFilePath          The lock file path used for error cleanup in case of failure.
     * @throws IOException          If an I/O error occurs during the file move operation.
     */
    private static void moveFileToFinalPath(String filePath, String outputPartsFile, String outputBasePartsFile, String outputToolGroupFile,
                                            Path tempFilePath, Path outputDir, Path lockFilePath) throws IOException {
        try {
            String outputFileName = determineOutputFileName(filePath, outputPartsFile, outputBasePartsFile, outputToolGroupFile);
            Path finalFilePath = Paths.get(outputDir.toString(), outputFileName);
            Files.move(tempFilePath, finalFilePath, StandardCopyOption.REPLACE_EXISTING);
        } catch (Exception e) {
            log(Level.WARNING, "Failed to output the item information. (ME_E00008)");
            cleanupAfterError(tempFilePath, lockFilePath);
            log(Level.WARNING, ERRORMESSAGE);
        }
    }

    /**
     * Retrieves the attributes of a given `DomainObject`, including both custom attributes and OOTB (Out-of-the-Box) attributes
     * such as modified and originated dates, and returns them in a map.
     *
     * @param context     The context of the current session, used to interact with the 3DEXPERIENCE platform.
     * @param doID        The `DomainObject` instance whose attributes are to be retrieved.
     * @return            A map containing both custom attributes and OOTB attributes (modified, originated) for the object.
     * @throws FrameworkException If there is an error while retrieving the object's attributes.
     */
    private static Map<String, Object> getObjectAttributes(Context context, DomainObject doID) throws FrameworkException {
        Map<String, Object> attributeMap = doID.getAttributeMap(context);
        StringList selectList = new StringList();
        selectList.add(DomainConstants.SELECT_MODIFIED);
        selectList.add(DomainConstants.SELECT_ORIGINATED);
        Map<String, Object> ootbObjectMap = doID.getInfo(context, selectList);
        attributeMap.putAll(ootbObjectMap);
        return attributeMap;
    }

    /**
     * Increments the appropriate output counter based on the given file path and appends a new line to the `StringBuilder`
     * The output number is updated based on the file type (Parts, Base, or Tools).
     *
     * @param flag          A boolean indicating whether a new line should be appended to the `StringBuilder`.
     * @param sb            The `StringBuilder` to which a new line will be appended if the flag is true.
     * @param outputNumber  The default output number that is returned if the file path does not match specific conditions.
     * @param filePath      The file path used to determine which output counter (Parts, Base, or Tools) should be incremented.
     * @return              The incremented output counter (outputPartsNo, outputBaseNo, outputToolsNo), or the default outputNumber.
     */
    private static int flagCount(boolean flag, StringBuilder sb, int outputNumber, String filePath) {
        if (flag) {
            sb.append("\n");
        }
        if (filePath.contains(ME_PARTS)) {
            return outputPartsNo++;
        } else if (filePath.contains(ME_BASE)) {
            return outputBaseNo++;
        } else if (filePath.contains(ME_TOOLS)) {
            return outputToolsNo++;
        }
        return outputNumber;
    }

    /**
     * Checks if the iterator is null or empty, leanup by
     * closing the writer and deleting the temporary and lock files. This prevents further processing if no target items are found.
     *
     * @param mpList
     * @param itr          The iterator to be checked for null or empty values.
     * @param writer       The `BufferedWriter` to be closed in case of an empty iterator.
     * @param tempFilePath The path to the temporary file to be deleted if the iterator is empty.
     * @param lockFilePath The path to the lock file to be cleaned up if tand if so, logs an informational message and performs che iterator is empty.
     * @throws IOException If an I/O error occurs during cleanup.
     */
    private static void handleNullIterator(MapList mpList, BufferedWriter writer, Path tempFilePath, Path lockFilePath) throws IOException {
        if (!mpList.iterator().hasNext()){
            log(Level.WARNING, "Not found the target item.(ME_E00006)");
            log(Level.WARNING, ERRORMESSAGE);
            writer.close();
            Files.delete(tempFilePath);
            cleanUp(lockFilePath);
            System.exit(0);
        }
    }

    /**
     * Iterates over the list of attributes, checks if each attribute exists in the provided map,
     * and appends its value to the `StringBuilder`. A flag is set to true if any attribute is successfully appended.
     *
     * @param sb              The `StringBuilder` to which the attributes will be appended.
     * @param slAttributes    The list of attributes to check and append from the attribute map.
     * @param attributeMap    The map containing attribute keys and their corresponding values.
     * @param filePath        The file path used for logging in case of an error.
     * @param writer          The `BufferedWriter` to be closed in case of an error.
     * @param tempFilePath    The path to the temporary file to be cleaned up in case of an error.
     * @param lockFilePath    The path to the lock file to be cleaned up in case of an error.
     * @param outputNumber    The current output number, used for logging or iteration purposes.
     * @param flag            A boolean flag indicating whether any attribute was successfully appended.
     * @return                `true` if at least one attribute was appended to the buffer, otherwise returns the existing flag state.
     * @throws IOException    If an I/O error occurs during cleanup or while writing to the buffer.
     */
    private static boolean appendAttributesToBuffer(StringBuilder sb, StringList slAttributes, Map attributeMap, String filePath, BufferedWriter writer,
                                                    Path tempFilePath, Path lockFilePath, int outputNumber , boolean flag , Context context) throws IOException, FrameworkException {
        for (String sAttributes : slAttributes) {
            if (attributeMap.containsKey(sAttributes)) {
                flag = true;
                String sValue = replaceSpecialCharacters((String) attributeMap.get(sAttributes));
                //TODO: Property file loading
                checkAttributeAndAppend(sb, sAttributes, sValue , context);
            } else {
                log(Level.INFO, "Not found the value described in " + filePath + ". Attribute name that cannot be read: " + sAttributes + " (ME_E00007)");
                cleanupAndExit(writer, tempFilePath, lockFilePath);
            }
        }
        return  flag;
    }

    /**
     * Handles the retrieval and appending of the highest revision's attributes to the provided `StringBuilder`.
     * It fetches the highest revision from the given `revisionMapList`, retrieves its attributes, and appends them to the buffer.
     *
     * @param sb                The `StringBuilder` to which the highest revision's attributes will be appended.
     * @param slAttributes      The list of attributes to retrieve and append from the highest revision's attribute map.
     * @param revisionMapList   The list of revisions from which the highest revision will be determined.
     * @param filePath          The file path used for logging purposes in case no revision is found.
     * @param context           The context of the current session, used to interact with the 3DEXPERIENCE platform.
     * @param writer            The `BufferedWriter` to be closed in case of an error or when writing is completed.
     * @param tempFilePath      The path to the temporary file to be cleaned up if an error occurs.
     * @param lockFilePath      The path to the lock file to be cleaned up in case of an error.
     * @param flag              A boolean flag indicating whether attributes were successfully appended.
     * @return                  `true` if the highest revision's attributes were appended, otherwise returns the existing flag state.
     * @throws IOException      If an I/O error occurs during the appending process or cleanup.
     * @throws FrameworkException If an error occurs while retrieving the object's information from the 3DEXPERIENCE platform.
     */
    private static boolean handleHighestRevision(StringBuilder sb, StringList slAttributes, MapList revisionMapList, String filePath, Context context,
                                                 BufferedWriter writer, Path tempFilePath, Path lockFilePath , boolean flag) throws IOException, FrameworkException {
        Map<String, String> highestRevisionMap = getHighestRevision(revisionMapList);
        if (!highestRevisionMap.isEmpty()) {
            String highestRevisionObjID = highestRevisionMap.get("id");
            DomainObject highestRevDoID = DomainObject.newInstance(context, highestRevisionObjID);
            Map highestRevAttributeMap = highestRevDoID.getAttributeMap(context);
            StringList highestRevSelectList = new StringList();
            highestRevSelectList.add(DomainConstants.SELECT_MODIFIED);
            highestRevSelectList.add(DomainConstants.SELECT_ORIGINATED);
            Map highestRevOotbObjectMap = highestRevDoID.getInfo(context, highestRevSelectList);
            highestRevAttributeMap.putAll(highestRevOotbObjectMap);
            flag = appendAttributesToBuffer(sb, slAttributes, highestRevAttributeMap, filePath, writer, tempFilePath, lockFilePath, 0 , false , context);
            sb.append("\n");
        } else {
            log(Level.WARNING, "No highest revision found for object.");
        }
        return  flag;
    }

    /**
     * Closes the provided `BufferedWriter`, deletes the temporary file, cleans up the lock file,
     * and then exits the application. This method is intended to be called in case of an error
     * or when a cleanup is necessary to prevent further processing.
     *
     * @param writer         The `BufferedWriter` to be closed to release resources.
     * @param tempFilePath   The path to the temporary file to be deleted.
     * @param lockFilePath   The path to the lock file to be cleaned up before exiting.
     * @throws IOException   If an I/O error occurs during closing the writer or deleting the temporary file.
     */
    private static void cleanupAndExit(BufferedWriter writer, Path tempFilePath, Path lockFilePath) throws IOException {
        writer.close();
        Files.delete(tempFilePath);
        cleanUp(lockFilePath);
        System.exit(0);
    }

    /**
     * Deletes the specified temporary file and exits the application.
     * This method is intended to be called when an error occurs to clean up
     * resources and ensure that no temporary files are left behind.
     *
     * @param tempFilePath   The path to the temporary file to be deleted.
     * @param lockFilePath   The path to the lock file, if applicable, that may also need to be handled.
     * @throws IOException   If an I/O error occurs during the deletion of the temporary file.
     */
    private static void cleanupAfterError(Path tempFilePath, Path lockFilePath) throws IOException {
        cleanUp(lockFilePath);
        Files.delete(tempFilePath);
        System.exit(0);
    }

    /**
     * Logs the details of the output processing.
     *
     * @param outputPartsFile     The name of the output parts file.
     * @param outputPartsNo       The number of output parts processed.
     * @param outputBasePartsFile  The name of the output base item file.
     * @param outputBaseNo        The number of base items processed.
     * @param outputToolGroupFile  The name of the equipment group file.
     * @param outputToolsNo       The number of tools processed.
     */
    private static void logOutputDetails(String outputPartsFile, int outputPartsNo, String outputBasePartsFile, int outputBaseNo, String outputToolGroupFile, int outputToolsNo) {
        log(Level.INFO, "Output processing completed. File name: " + outputPartsFile + OUTPUTNUMBER + outputPartsNo + " , Base Item File name: "  +  outputBasePartsFile
                + OUTPUTNUMBER + outputBaseNo + " , Equipment Group File name : " + outputToolGroupFile + OUTPUTNUMBER + outputToolsNo  + " (ME_I00002) ");
    }

    /**
     * Determines the output file name based on the provided file path and predefined output file names.
     * The method appends a formatted date and a ".tsv" extension to the appropriate base file name,
     * depending on whether the file path indicates parts, base items, or tools.
     *
     * @param filePath             The path of the input file to determine the output file name.
     * @param outputPartsFile      The base name for the output parts file.
     * @param outputBasePartsFile  The base name for the output base parts file.
     * @param outputToolGroupFile  The base name for the output tool group file.
     * @return                     The constructed output file name with a formatted date and ".tsv" extension,
     *                             or null if the file path does not match any known types.
     */
    private static String determineOutputFileName(String filePath, String outputPartsFile, String outputBasePartsFile, String outputToolGroupFile) {
        if (filePath.contains(ME_PARTS)) {
            return  outputPartsFile + formattedDate() + ".tsv";
        } else if (filePath.contains(ME_BASE)) {
            return outputBasePartsFile+  formattedDate() + ".tsv";
        } else if (filePath.contains(ME_TOOLS)) {
            return outputToolGroupFile+  formattedDate() + ".tsv";
        }
        return null;
    }

    /**
     * Retrieves the object type string (stype) based on the provided file path.
     * The method returns a specific string value depending on whether the file path
     * indicates parts, base items, or tools.
     *
     * @param filePath   The path of the input file from which to determine the object type.
     * @return          A string representing the object type:
     *                  "CreateAssembly,Provided" for parts and base items,
     *                  "VPMReference" for tools, or null if the file path does not match any known types.
     */
    private static String getStypeFromFilePath(String filePath) {
        if (filePath.contains(ME_PARTS)) {
            return "CreateAssembly,Provided";
        } else if (filePath.contains(ME_BASE)) {
            return "CreateAssembly,Provided";
        } else if (filePath.contains(ME_TOOLS)) {
            return "VPMReference";
        }
        return null;
    }

    /**
     * Retrieves the appropriate where condition depending on whether the file path
     * indicates parts, base items, or tools.
     *
     * @param filePath   The path of the input file from which to determine the where condition.
     * @return          A string representing the where condition:
     *                  the result of `whereConditionForParts()` for parts,
     *                  the result of `whereConditionForBaseParts()` for base items,
     *                  the result of `whereConditionForToolsEquipment()` for tools,
     *                  or null if the file path does not match any known types.
     */
    private static String getWhereConditionFromFilePath(String filePath) {
        if (filePath.contains(ME_PARTS)) {
            return whereConditionForParts();
        } else if (filePath.contains(ME_BASE)) {
            return whereConditionForBaseParts();
        } else if (filePath.contains(ME_TOOLS)) {
            return whereConditionForToolsEquipment();
        }
        return null;
    }

    /**
     * Collects the revision information for a specified object and adds it to the provided revision map list.
     * This method creates a new map containing the object ID and its corresponding revision value,
     * and then adds this map to the revision map list.
     *
     * @param attributeMap     A map containing attributes of the object, including the revision information.
     * @param strObjID        The identifier of the object whose revision information is being collected.
     * @param revisionMapList  The list to which the revision map will be added, containing the object ID and revision.
     */
    private static void collectNK_Revisions(Map<String, Object> attributeMap, String strObjID, MapList revisionMapList) {
        Map<String, String> revisionMap = new HashMap<>();
        revisionMap.put("id", strObjID);
        revisionMap.put(NK_REVISION, (String) attributeMap.get(NK_IntegrationConstants_mxJPO.NK_REVISION));
        revisionMapList.add(revisionMap);
    }

    /**
     * Retrieves the highest revision from a list of revision maps by sorting the list
     * based on the revision values in descending order. If the list is empty or null,
     * an empty map is returned. The highest revision is considered to be the one with the
     * greatest string value.
     *
     * @param revisionMapList The list of revision maps to be sorted and evaluated.
     * @return A map representing the highest revision found in the list, or an empty map
     *         if the list is null or empty.
     */
    private static Map<String, String> getHighestRevision(MapList revisionMapList) {
        if (revisionMapList == null || revisionMapList.isEmpty()) {
            return new HashMap<>();
        }
        Collections.sort(revisionMapList, new Comparator<Map>() {
            @Override
            public int compare(Map map1, Map map2) {
                String rev1 = (String) map1.get(NK_REVISION);
                String rev2 = (String) map2.get(NK_REVISION);
                if (rev1 == null) rev1 = "";
                if (rev2 == null) rev2 = "";
                return rev2.compareTo(rev1);
            }
        });
        return (Map<String, String>) revisionMapList.get(0); // Highest revision at index 0
    }

    /**
     * Generates a formatted string representation of the current date and time.
     *
     * @return A string representing the current date and time in the format "yyyyMMddHHmmss".
     */
    private static String formattedDate() {
        LocalDateTime now = LocalDateTime.now();
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyMMddHHmmss");
        String formattedDate = now.format(formatter);
        return formattedDate;
    }

    /**
     * Constructs a WHERE condition string for filtering tool equipment objects.
     * The condition specifies that the attribute "PLMEntity.V_Name" must match
     * the pattern "Tool Equipment*", and includes the OOTB revision condition.
     *
     * @return A string representing the constructed WHERE condition for tool equipment
     *         filtering, formatted for use in database queries or searches.
     */
    private static String whereConditionForToolsEquipment() {
        StringBuilder sb = new StringBuilder();
        sb.append("attribute[PLMEntity.V_Name]~='Tool Equipment*'");
        sb.append(" && ");
        sb.append(OOTBREVISION);
        return sb.toString();
    }

    /**
     * Constructs a WHERE condition string for filtering base parts objects.
     * This method currently returns the OOTB revision condition without any additional filtering criteria.
     *
     * @return A string representing the constructed WHERE condition for base parts filtering,
     *         specifically focused on the OOTB revision.
     */
    private static String whereConditionForBaseParts( ) {
        StringBuilder whereClauseFlag = new StringBuilder();
        whereClauseFlag.append(OOTBREVISION);
        return whereClauseFlag.toString();
    }

    /**
     * Constructs a WHERE condition string for filtering part objects.
     * This method currently returns the OOTB revision condition without any additional filtering criteria.
     *
     * @return A string representing the constructed WHERE condition for parts filtering,
     *         specifically focused on the OOTB revision.
     */
    private static String whereConditionForParts() {
        StringBuilder whereClauseFlag = new StringBuilder();
        whereClauseFlag.append(OOTBREVISION);
        return whereClauseFlag.toString();
    }

    /**
     * Generates a temporary file name based on the current date and time.
     *
     * @return A string representing the generated temporary file name.
     */
    private static String generateTempFileName() {
        LocalDateTime now = LocalDateTime.now();
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyyMMddHHmmss");
        return "temp" + now.format(formatter) + ".csv";
    }

    /**
     * Replaces all occurrences of double quotes in the input string with a space.
     *
     * @param input the string in which double quotes will be replaced
     * @return a new string with all double quotes replaced by spaces. If the input is null,
     *         this method will return null.
     */
    public static String replaceSpecialCharacters(String input) {
        return input.replace("\"", " ");
    }

    /**
     * Processes lines from a BufferedReader to extract and append content from lines starting with "FIX[".
     * Lines not starting with "FIX[" are added to a StringList of attributes.
     *
     *
     * @param sb the StringBuilder to which the extracted FIX content will be appended
     * @param br the BufferedReader to read the input lines from
     * @param slAttributes the StringList to hold the attributes extracted from lines that do not start with "FIX["
     * @throws IOException if an I/O error occurs while reading from the BufferedReader
     */
    private static void processFixLine(StringBuilder sb,BufferedReader br ,StringList slAttributes ) throws IOException {
        String line;
        boolean isFirstLine = true;
        while ((line = br.readLine()) != null) {
            if (line.trim().startsWith("FIX[")) {
                String content = line.substring(line.indexOf('[') + 1, line.lastIndexOf(']'));
                if (!isFirstLine) {
                    sb.append("\n");
                }
                sb.append(content.trim());
                isFirstLine = false;
            } else {
                slAttributes.add(line);
            }
        }
    }

    /**
     * Checks if a given attribute is valid and appends its value to a StringBuilder.
     *
     * @param sb the StringBuilder to which the value will be appended
     * @param sAttributes the name of the attribute being checked
     * @param sValue the value of the attribute to be appended
     */
    private static void checkAttributeAndAppend(StringBuilder sb, String sAttributes, String sValue , Context context) throws FrameworkException {
        Set<String> validAttributes = new HashSet<>(Arrays.asList(
                NK_IntegrationConstants_mxJPO.Originated,
                NK_IntegrationConstants_mxJPO.Modified,
                NK_IntegrationConstants_mxJPO.NK_PLMENTITY_V_NAME,
                NK_IntegrationConstants_mxJPO.NK_MBOM_PARTS_NAME,
                NK_IntegrationConstants_mxJPO.NK_UNIT_BASIC_QUANTITY_SALES_ORDER,
                NK_IntegrationConstants_mxJPO.NK_LotNumberRequired,
                NK_IntegrationConstants_mxJPO.NK_SerialNumberRequired,
                NK_IntegrationConstants_mxJPO.NK_TYPE_PHARMARCY_REGISTRATION,
                NK_IntegrationConstants_mxJPO.NK_OPNO,
                NK_IntegrationConstants_mxJPO.NK_ELEC,
                NK_IntegrationConstants_mxJPO.NK_MONTH_EXPIRATION_DATE,
                NK_IntegrationConstants_mxJPO.NK_POISON_CLASSIFICATION,
                NK_IntegrationConstants_mxJPO.NK_DELETERIOUS,
                NK_IntegrationConstants_mxJPO.NK_HAZARDOUS_MATERIAL_CLASSIFICATION,
                NK_IntegrationConstants_mxJPO.NK_CLASS_DEADLINE,
                NK_IntegrationConstants_mxJPO.NK_MANUFACTURE_UNIT_NUMBER,
                NK_IntegrationConstants_mxJPO.NK_NUMBER_CHAMFERS,
                NK_IntegrationConstants_mxJPO.NK_TEMP_STORAGE_LOW,
                NK_IntegrationConstants_mxJPO.NK_TEMP_STORAGE_HIGH,
                NK_IntegrationConstants_mxJPO.NK_HUMIDITY_STORAGE_LOW,
                NK_IntegrationConstants_mxJPO.NK_HUMIDITY_STORAGE_HIGH,
                NK_IntegrationConstants_mxJPO.NK_CLASS_SPECIALLY_ITEM,
                NK_IntegrationConstants_mxJPO.NK_PLMEntity_description
        ));
        StringList attributeRanges = FrameworkUtil.getRanges(context, sAttributes);
        if (UIUtil.isNotNullAndNotEmpty(sValue)) {
            if(attributeRanges.size()>0) {
                String displayName = EnoviaResourceBundle.getProperty(context, "emxFrameworkStringResource",
                        context.getLocale(),"emxFramework.Attribute."+ sAttributes +".Range."+ sValue);
                sb.append(displayName+",");
                return;
            }
            if (validAttributes.contains(sAttributes)) {
                sb.append(sValue).append("\t");
            } else {
                sb.append("\t");
            }
        } else {
            sb.append("\t");
        }
    }

    /**
     * @param filePath the path to the properties file to be validated
     * @param lockFilePath the path to the lock file used during validation
     * @param outputDir the directory for output files
     * @param outputBasePartsFile the base parts output file name
     * @param outputPartsFile the parts output file name
     * @param outputToolGroupFile the tool group output file name
     * @throws IOException if an I/O error occurs while validating or loading the configuration file
     */
    private static void validateFileArgument(String filePath, Path lockFilePath, String outputDir, String outputBasePartsFile, String outputPartsFile , String outputToolGroupFile) throws IOException {
        if (isValidFilePath(filePath)) {
            fileName = filePath;
            if (fileName.endsWith(".properties")) {
                loadAndValidateConfigFile(outputDir,outputBasePartsFile , outputPartsFile , outputToolGroupFile);
            } else {
                handleInvalidConfigFile(lockFilePath);
            }
        } else {
            logInvalidPropertiesFile();
        }
    }

    /**
     * @param filePath the file path to be validated
     * @return {@code true} if the file path is valid; {@code false} otherwise
     */
    private static boolean isValidFilePath(String filePath) {
        return filePath != null && !filePath.isEmpty();
    }

    /**
     * Logs an informational message indicating that too many arguments were provided.
     *
     */
    private static void handleTooManyArguments(Path lockFilePath) throws IOException {
        log(Level.INFO, "Too many arguments");
        cleanUp(lockFilePath);
        System.exit(0);
    }

    /**
     * Logs an informational message indicating that the properties file provided is invalid.
     *
     */
    private static void logInvalidPropertiesFile() {
        log(Level.INFO, "Invalid properties file");
        System.exit(0);
    }

    /**
     * handleInvalidConfigFile
     * @param lockFilePath The path to the lock file that may be deleted.
     * @throws IOException If an I/O error occurs while attempting to delete the lock file.
     */
    private static void handleInvalidConfigFile(Path lockFilePath) throws IOException {
        log(Level.INFO, "Could not read NK_ExportItem.conf (ME_E00003)");
        Files.deleteIfExists(lockFilePath);
        System.exit(0);
    }

    /**
     * argumentError
     * @param args       The array of command-line arguments.
     * @param lockFilePath The path to the lock file that will be cleaned up if
     *                     there is an error.
     * @throws IOException If an I/O error occurs during the cleanup process.
     */
    private static void argumentError(String[] args,Path lockFilePath) throws IOException {
        if (args.length == 0 || args.length == 1 || args.length == 2 || args.length == 3) {
            log(Level.INFO, "Not enough arguments(ME_E00002)");
            cleanUp(lockFilePath);
            System.exit(0);
        }
    }

    /**
     * cleanUp
     * @param lockFilePath The path to the lock file to be deleted.
     * @throws IOException If an I/O error occurs while deleting the file or
     *                     closing the handler.
     */
    private static void cleanUp(Path lockFilePath) throws IOException {
        Files.deleteIfExists(lockFilePath);
        if (handler != null) {
            handler.close();
        }
    }

    /**
     * Creates a lock file at the specified path.
     * createLockFile
     * @param lockFilePath The path where the lock file should be created.
     */
    private static void createLockFile(Path lockFilePath) {
        try {
            Files.createFile(lockFilePath);
        } catch (IOException e) {
            log(Level.INFO, "Failed to create lock file. Exiting...");
            System.exit(1);
        }
    }

    /**
     * Loads and validates the configuration file parameters.
     *
     *
     * @param outputDir            The path to the output directory to be validated.
     * @param outputBasePartsFile  The name of the base parts output file to be validated.
     * @param outputPartsFile      The name of the parts output file to be validated.
     * @param outputToolGroupFile  The name of the tool group output file to be validated.
     */
    private static void loadAndValidateConfigFile(String outputDir, String outputBasePartsFile  ,String  outputPartsFile, String outputToolGroupFile)  {
            if (UIUtil.isNullOrEmpty(outputBasePartsFile)) {
                log(Level.INFO, "outputBasePartsFile value is not valid");
                System.exit(0);
            }
            if (UIUtil.isNullOrEmpty(outputPartsFile)){
                log(Level.INFO,"outputPartsFile value is not valid");
                System.exit(0);
            }
            if (UIUtil.isNullOrEmpty(outputToolGroupFile)){
                log(Level.INFO,"outputPartsFile value is not valid");
                System.exit(0);
            }
    }

    /**
     * Reads a property from a specified page object and retrieves its value based on a key.
     *
     * @param context      The context in which the page object is opened.
     * @param strPageName The name of the page object to be opened and read.
     * @param strKeyName  The key for which the property value needs to be retrieved.
     * @return            The property value associated with the specified key, or an empty string if not found.
     */
    public static String readPageObject(Context context, String strPageName, String strKeyName) {
        Properties propNotification = new Properties();
        String strProperty = DomainConstants.EMPTY_STRING;
        try {
            Page pageAttributePopulation = new Page(strPageName);
            pageAttributePopulation.open(context);
            String strProperties = pageAttributePopulation.getContents(context);
            pageAttributePopulation.close(context);
            InputStream input = new ByteArrayInputStream(strProperties.getBytes(StandardCharsets.UTF_8));
            propNotification.load(input);
            if (propNotification.containsKey(strKeyName)) {
                strProperty = propNotification.getProperty(strKeyName);
            } else {
                log(Level.INFO, strKeyName + " IS NOT PRESENT");
                System.exit(0);
            }
        } catch (Exception e) {
            log(Level.INFO, "readPageObject failed");
            e.printStackTrace();
        }
        return strProperty;
    }

    /**
     * log
     * @param level
     * @param args
     */
    private static void log(Level level, String... args) {
        logger.log(level, getLogString(args));
    }
    /**
     * Generates a log string that includes the current date and concatenates additional messages.
     *
     * @param args Messages to be included in the log string. The method can accept a variable number of string arguments.
     * @return A string containing the current date and the concatenated messages.
     */
    private static String getLogString(String... args) {
        StringBuilder sbMessage = new StringBuilder();
        sbMessage.append(new Date());
        sbMessage.append(",");
        for (String msg : args) {
            sbMessage.append(msg);
        }
        return sbMessage.toString();
    }

    /**
     * Initializes the logger with a specified log directory and logging level.
     *
     * @param LOG_DIR The directory where the log file will be created. Must be a valid path.
     * @param LoggerLevel The desired logging level as a string (e.g., "INFO", "WARNING", "SEVERE").
     *                    If null or empty, the default level "INFO" will be used.
     * @throws IOException If an I/O error occurs while creating the log file or setting up the logger.
     */
    private static void initiateLogger(String LOG_DIR, String LoggerLevel) throws IOException {
        String path = LOG_DIR + "/Logs";
        handler = new FileHandler(path +  formattedDate() + ".log");
        handler.setFormatter(new HD_LoggingFormatter());
        handler.setEncoding("UTF-8");
        logger.addHandler(handler);
        String level = LoggerLevel;
        if (level == null || level.isEmpty())
            level = "INFO";
        logger.setLevel(Level.parse(level));
    }

    /**
     * Custom logging formatter for formatting log records.
     */
    static class HD_LoggingFormatter extends Formatter {
        @Override
        public String format(LogRecord record) {
            StringBuilder sb = new StringBuilder();
            sb.append(record.getLevel()).append(',');
            sb.append(record.getMessage()).append('\n');
            return sb.toString();
        }
    }

}