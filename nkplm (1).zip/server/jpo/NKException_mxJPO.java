/**
 * Generic Exception Class for Process Revision.
 *
 * @param context
 * @param strPageName
 * @param strKeyName
 * @throws Exception
 */
public class NKException_mxJPO extends Exception {
	   public NKException_mxJPO(String errorMessage) {  
		    super(errorMessage);  
		    }  
}
