import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Map;
import java.util.Properties;
import java.util.Set;
import java.util.logging.FileHandler;
import java.util.logging.Formatter;
import java.util.logging.Level;
import java.util.logging.LogRecord;
import java.util.logging.Logger;
import com.matrixone.apps.domain.DomainConstants;
import com.matrixone.apps.domain.DomainObject;
import com.matrixone.apps.domain.util.FrameworkException;
import com.matrixone.apps.domain.util.MapList;
import com.matrixone.apps.domain.util.PropertyUtil;
import com.matrixone.apps.framework.ui.UIUtil;
import matrix.db.Context;
import matrix.db.Page;
import matrix.util.Pattern;
import matrix.util.StringList;
import java.util.ArrayList;
import java.util.List;

public class NK_ProChemistOut_mxJPO{
	private static Logger logger = Logger.getLogger(NK_ProChemistOut_mxJPO.class.getName());
	private static FileHandler handler = null;
	public static String ATTRIBUTE_EXPRESSION = "attribute[%s]";
	public static final String CONFIG_NK_PR_EXPORT_ITEM = "NK_PR_ExportItem";
	public static final String KEY_NO_TARGET_RATING_CLASSIFICATION = "NO_TARGET_RATING_CLASSIFICATION";
	public static final String KEY_PRIORITY_SUPPLIER = "PRIORITY_SUPPLIER";
	public static final String KEY_NO_TARGET_SUPPLIER = "NO_TAEGET_SUPPLIER";
	public static final String ERROR_OUTPUT_PROCESSING_FAILED = "Output processing failed. Please check the error message.";
	public static final String PARTS_FILE_NAME = "PR_PARTS";
	public static final String RELATION_FILE_NAME = "PR_RELATION";
	public static final String SUPPLIER_FILE_NAME = "PR_SUPPLIER";
	private static Map<String, String> objectAttributeMapforParts = new HashMap<>();
	private static Map<String, String> objectAttributeMapforRelation = new HashMap<>();
	public static final String SELECT_NK_RATING_CLASSIFICATION = "attribute[NK_EXT_MBOM_PARTS.NK_RATING_CLASSIFICATION]";
	public static final String SELECT_NK_VENDER_CODE1 = "attribute[NK_EXT_MBOM_BOSS.NK_VENDER_CODE1]";
	public static final String SELECT_NK_VENDER_CODE2 = "attribute[NK_EXT_MBOM_BOSS.NK_VENDER_CODE2]";
	public static final String SELECT_NK_VENDER_CODE3 = "attribute[NK_EXT_MBOM_BOSS.NK_VENDER_CODE3]";
	public static final String TYPE_CREATEASSEMBLY = PropertyUtil.getSchemaProperty("type_CreateAssembly");
	public static final String TYPE_DOCUMENT = PropertyUtil.getSchemaProperty("type_Document");
	public static final String CURRENT_STATUS_RELEASED = "current=='Released'";
	private static int outputNumberParts = 0;
	private static int outputNumberSupply = 0;
	private static int outputNumberRelation = 0;

	/** 
	 * This method reads all the keys from the config file and initiate the logger and check multiple execution 
	 * @param  context the 3dx<code>Context</code>object.
	 * @param args contains the three input files
	 * @throws Exception
	 */
	public static void NK_ProChemsitToCSV(Context context, String[] args) throws Exception {
		String outputDir = readPageObject(context, CONFIG_NK_PR_EXPORT_ITEM, "OUTPUT_DIR");
		String outputPartsFile = readPageObject(context, CONFIG_NK_PR_EXPORT_ITEM, "OUTPUT_PARTS_FILE");
		String outputRelationFile = readPageObject(context, CONFIG_NK_PR_EXPORT_ITEM, "OUTPUT_RELATION_FILE");
		String outputSuppulyFile = readPageObject(context, CONFIG_NK_PR_EXPORT_ITEM, "OUTPUT_SUPPULY_FILE");
		String logDir = readPageObject(context, CONFIG_NK_PR_EXPORT_ITEM, "LOG_DIR");
		String loggerLevel = readPageObject(context, CONFIG_NK_PR_EXPORT_ITEM, "Logger.Level");
		String sNoTargetRatingClassification = readPageObject(context, CONFIG_NK_PR_EXPORT_ITEM, KEY_NO_TARGET_RATING_CLASSIFICATION);
		String spriority = readPageObject(context, CONFIG_NK_PR_EXPORT_ITEM,KEY_PRIORITY_SUPPLIER);
		String snoTarget = readPageObject(context, CONFIG_NK_PR_EXPORT_ITEM,KEY_NO_TARGET_SUPPLIER);
		initiateLogger(logDir, loggerLevel);
		validateDirectory(outputDir);
		Path lockFilePath = Paths.get(outputDir, "process.lock");
		try {
			if (Files.exists(lockFilePath)) {
				logger.log(Level.WARNING, "Program is already running.(PR_E00001)");
				logger.log(Level.WARNING, ERROR_OUTPUT_PROCESSING_FAILED);	           
				System.exit(1);
			}
			createLockFile(lockFilePath);	
			logger.log(Level.INFO, "Processing has started.(PR_I00001)");
			if (args.length != 4) {
				handleArgumentError(lockFilePath);
			}
			if (args[0] == null || args[0].isEmpty() || !args[0].endsWith(".properties")) {
				handlePropertyFileError(lockFilePath);
			}
			checkSupplierExistence(context,lockFilePath,sNoTargetRatingClassification,spriority,snoTarget);
			checkAttribute(context,args,outputDir,outputPartsFile,outputRelationFile,outputSuppulyFile,lockFilePath);
			logOutput(outputPartsFile, outputNumberParts, outputRelationFile, outputNumberRelation, outputSuppulyFile, outputNumberSupply);

		} catch (IOException e) {
			e.printStackTrace();
		} finally {
		    try {
		        cleanUp(lockFilePath);
		    } catch (IOException e) {
		        System.out.println("Failed to delete lock file.");
		    } finally {
		        cleanUpLogger(); 
		    }
		}
	}

	/**
	 * This method checks the Supplier and NoTarget Existence in Database 
	 * @param context the 3dx<code>Context</code>object.
	 * @param lockFilePath - If it the execution stops , it will delete the current lock file 
	 * @param noTargetSupplier 
	 * @param prioritySupplier 
	 * @param noTargetRatingClassification 
	 * @throws Exception
	 */
	public static void checkSupplierExistence(Context context, Path lockFilePath, String noTargetRatingClassification, String prioritySupplier, String noTargetSupplier ) throws Exception {
		validateConfigValues(lockFilePath, noTargetRatingClassification, prioritySupplier, noTargetSupplier);    	
		Pattern typePattern = new Pattern(TYPE_CREATEASSEMBLY);
		typePattern.addPattern(TYPE_DOCUMENT);    
		StringList objectSelects = new StringList();
		objectSelects.add(DomainConstants.SELECT_ID);
		objectSelects.add(DomainConstants.SELECT_ATTRIBUTE_TITLE);
		objectSelects.add(SELECT_NK_RATING_CLASSIFICATION);

		MapList mlResults = (MapList) DomainObject.findObjects(context,typePattern.getPattern(), "*", "*", null, null, null, false, objectSelects);
		List<String> ratingClassifications = new ArrayList<>();
		List<String> suppliers = new ArrayList<>();
		for (Object obj : mlResults) {
			Map<?, ?> objectMap = (Map<?, ?>) obj;
			String strRatingClassificationValue = (String) objectMap.get(SELECT_NK_RATING_CLASSIFICATION);
			if (strRatingClassificationValue != null) {
				ratingClassifications.add(strRatingClassificationValue);
			}	        
			String attrTitle = (String) objectMap.get(DomainConstants.SELECT_ATTRIBUTE_TITLE);
			if (attrTitle != null) suppliers.add(attrTitle);
		}
		Set<String> targetRatings = new HashSet<>(List.of(noTargetRatingClassification.split(",")));
		for (String target : targetRatings) {
			boolean found = checkIfExistsWithWildcard(ratingClassifications, target);
			if (!found) {
				logger.log(Level.WARNING, "The rating classification value set in the configuration file does not exist: " + target +"(PR_E00009)");
				logger.log(Level.WARNING, ERROR_OUTPUT_PROCESSING_FAILED);
				cleanUp(lockFilePath);
				System.exit(0);
			}
		}
		Set<String> targetSuppliers = new HashSet<>(List.of(prioritySupplier.split(",")));
		for (String target : targetSuppliers) {
			boolean found = checkIfExistsWithWildcard(suppliers, target);
			if (!found) {
				logger.log(Level.WARNING, "There is no vendor master record with the value set for the preferred vendor.Value:"+target+"(EC_E00010)");
				logger.log(Level.WARNING, ERROR_OUTPUT_PROCESSING_FAILED);
				cleanUp(lockFilePath);
				System.exit(0);
			}
		}
		Set<String> noTargetSuppliers = new HashSet<>(List.of(noTargetSupplier.split(",")));
		for (String target : noTargetSuppliers) {
			boolean found = checkIfExistsWithWildcard(suppliers, target);
			if (!found) {
				logger.log(Level.WARNING, " There is no vendor master record with the value set for the ineligible vendor.Value:"+target+"(EC_E00011)");
				logger.log(Level.WARNING, ERROR_OUTPUT_PROCESSING_FAILED);
				cleanUp(lockFilePath);
				System.exit(0);
			}
		}
	}

	/**
	 * To check if the value have * at the end 
	 * @param list - contains all the values set in config file
	 * @param target - points to each value of attribute from the database
	 * @return
	 */
	private static boolean checkIfExistsWithWildcard(List<String> list, String target) {
		if (target.endsWith("*")) {
			String prefix = target.substring(0, target.length() - 1);
			for (String item : list) {
				if (item.startsWith(prefix)) {
					return true;
				}
			}
		} else {
			return list.contains(target);
		}
		return false;
	}

	/**
	 * To make sure the values has been set to the key sin config file
	 * @param lockFilePath -  If it the execution stops , it will delete the current lock file 
	 * @param values - All the values from config file keys
	 * @throws IOException
	 */
	private static void validateConfigValues(Path lockFilePath, String... values) throws IOException {
		for (String value : values) {
			if (UIUtil.isNullOrEmpty(value)) {
				logger.log(Level.WARNING, "An empty value is present in the configuration file. Please check.");
				cleanUp(lockFilePath);
				System.exit(1);
			}
		}
	}

	/**
	 * To create temporary file and reads all the inputs file and to process 
	 * @param context - the 3dx<code>Context</code>object.
	 * @param args - holds all the files from the arguments 
	 * @param outputDir - Directory path to create output file 
	 * @param outputPartsFile - holds the name of the outputParts
	 * @param outputRelationFile - holds the name of the outputRelation
	 * @param outputSuppulyFile - holds the name of the outputSuppuly
	 * @param lockFilePath - If it the execution stops , it will delete the current lock file 
	 * @throws Exception
	 */
	public static void checkAttribute(Context context, String args[], String outputDir, String outputPartsFile, String outputRelationFile, String outputSuppulyFile, Path lockFilePath) throws Exception {   
		for (int i = 1; i <= 3; i++) {
			String filePath = args[i];        
			String tempFileName = generateTempFileName();
			Path tempFilePath = Paths.get(outputDir, tempFileName);    
			StringBuilder sb = new StringBuilder();       
			Path outputPath = Paths.get(outputDir);
			Files.createDirectories(outputPath);
			try (BufferedWriter writer = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(tempFilePath.toFile()), StandardCharsets.UTF_8))) {
				StringList slAttributes = new StringList();
				try (BufferedReader br = new BufferedReader(new InputStreamReader(new FileInputStream(filePath), "UTF-8"))) {
					String line;
					boolean isFirstLine = true;                 
					while ((line = br.readLine()) != null) {
						if (line.startsWith("FIX[")) {                        
							processFixLine(sb, line, isFirstLine);
							isFirstLine = false;                    
						} else {                        
							slAttributes.add(line);
						}
					}	                
					String type = determineType(filePath);
					String sbWhere = buildWhereCondition(context, filePath);
					StringList objectSelects = createObjectSelects();                                    
					StringList orderBys = new StringList();
					orderBys.add("-revision");    
					MapList mlResults = DomainObject.findObjects(context, type, null, sbWhere,
							objectSelects, (short) 0, orderBys);    					
					validateResults(mlResults, writer, tempFilePath, lockFilePath); 
				    updateOutputCounts(filePath, mlResults);    
				    if (filePath.contains(RELATION_FILE_NAME)) {
			            mlResults = getSupplierCode(context, mlResults);
			            outputNumberRelation = mlResults.size();
			        }
					writeAttributesToFile(sb, slAttributes, mlResults, context, writer, filePath, tempFilePath, lockFilePath);                    
				} catch (IOException e) {
					logger.log(Level.WARNING, "Could not read attributes definition file. (PR_E00005)");
					logger.log(Level.WARNING, ERROR_OUTPUT_PROCESSING_FAILED);				
					writer.close(); 
					Files.delete(tempFilePath);
					cleanUp(lockFilePath);
					System.exit(0);	
				}
				writer.append(sb.toString());
				writer.close();
				moveTempFile(context, outputDir, tempFilePath, filePath, outputPartsFile, outputRelationFile, outputSuppulyFile, lockFilePath);
			} catch (IOException e) {
				e.printStackTrace();
			}
			finally {			
				try {
					Files.delete(tempFilePath);
				} catch (IOException e) {			
				}
			}
		} 
	}
	 /**
	  * To find the output number
	 * @param filePath - holds the file Path
	 * @param mlResults - holds the data which passes where clause
	 * @throws Exception
	 */
	private static void updateOutputCounts(String filePath, MapList mlResults){
	        if (filePath.contains(PARTS_FILE_NAME)) {
	            outputNumberParts = mlResults.size();           
	        }else if (filePath.contains(SUPPLIER_FILE_NAME)) {
	        	 outputNumberSupply = mlResults.size();
	        }
	    }
	/**
	 * To move the data from the temp file to actual file 
	 * @param context the 3dx<code>Context</code>object. 
	 * @param outputDir - Directory path to create output file 
	 * @param outputPartsFile - holds the name of the outputParts
	 * @param outputRelationFile - holds the name of the outputRelation
	 * @param outputSuppulyFile - holds the name of the outputSuppuly
	 * @param lockFilePath - If it the execution stops , it will delete the current lock file 
	 * @param tempFilePath - Holds the data in this temporary file .
	 * @param filePath - To create the file in this path 
	 * @throws IOException
	 */
	private static void moveTempFile(Context context, String outputDir, Path tempFilePath, String filePath, String outputPartsFile, String outputRelationFile, String outputSuppulyFile, Path lockFilePath) throws IOException {
		try {
			String outputFileName = getOutputFileName(filePath, outputPartsFile, outputRelationFile, outputSuppulyFile);
			Path finalFilePath = Paths.get(outputDir, outputFileName);
			Files.move(tempFilePath, finalFilePath, StandardCopyOption.REPLACE_EXISTING);
			logger.log( Level.INFO, "TSV file '" + outputFileName + "' created successfully at " + outputDir);
			System.out.println("TSV file '" + outputFileName + "' created successfully at " + outputDir);		
			updatePartsAttributesAfterExport(context);
			updateRelationAttributesAfterExport(context);
		}catch (Exception e) {
			e.printStackTrace();
			logger.log( Level.WARNING,"Failed to output the item information.(PR_E00012)");
			System.out.println("Failed to output the item information.(PR_E00012)");
			Files.delete(tempFilePath);
			Files.deleteIfExists(lockFilePath);
			System.exit(0);	
		}
	}
	/**
	 * To check the Type based on file name 
	 * @param filePath - holds the input file from the arguments 
	 * @return
	 */
	private static String determineType(String filePath) {
		if (filePath.contains(PARTS_FILE_NAME) || filePath.contains(RELATION_FILE_NAME)) {
			return "CreateAssembly,Provide";
		} else if (filePath.contains(SUPPLIER_FILE_NAME)) {
			return "Document";
		}
		return null;
	}
	/**
	 * To build the where condition for each file 
	 * @param context the 3dx<code>Context</code>object.
	 * @param filePath - holds the input file from the arguments 
	 * @return
	 * @throws Exception
	 */
	private static String buildWhereCondition(Context context, String filePath) throws Exception {
		if (filePath.contains(PARTS_FILE_NAME)) {
			return buildWhereConditionForParts(context);
		} else if (filePath.contains(RELATION_FILE_NAME)) {
			return buildWhereConditionForRelation(context);
		} else if (filePath.contains(SUPPLIER_FILE_NAME)) {
			return buildWhereConditionForSupplier(context);
		}
		return null;
	}

	/**
	 * To add the Object selects
	 * @return
	 */
	private static StringList createObjectSelects() {
		StringList objectSelects = new StringList();
		objectSelects.add(DomainConstants.SELECT_ID);
		objectSelects.add(SELECT_NK_VENDER_CODE1);
		objectSelects.add(SELECT_NK_VENDER_CODE2);
		objectSelects.add(SELECT_NK_VENDER_CODE3);
		return objectSelects;
	}

	/**
	 * to validate the results 
	 * @param mlResults - holds all the objects which passed where condition 
	 * @param writer - Builder to append the data
	 * @param lockFilePath - If it the execution stops , it will delete the current lock file 
	 * @param tempFilePath - Holds the data in this temporary file .
	 * @throws IOException
	 */
	private static void validateResults(MapList mlResults, BufferedWriter writer, Path tempFilePath, Path lockFilePath) throws IOException {
		if (!mlResults.iterator().hasNext()) { 
			logger.log(Level.WARNING, "Not found the target item.(PR_E00006)"); 
			logger.log(Level.WARNING, ERROR_OUTPUT_PROCESSING_FAILED);
			writer.close(); 
			Files.delete(tempFilePath);
			cleanUp(lockFilePath);
			System.exit(0);
		}
	}

	/**
	 * @param filePath - holds the input file from the arguments 
	 * @param outputPartsFile - holds the name of the outputParts
	 * @param outputRelationFile - holds the name of the outputRelation
	 * @param outputSuppulyFile - holds the name of the outputSuppuly
	 * @return
	 */
	private static String getOutputFileName(String filePath, String outputPartsFile, String outputRelationFile, String outputSuppulyFile) {
		if (filePath.contains(PARTS_FILE_NAME)) {
			return outputPartsFile + formattedDate() + ".tsv";
		} else if (filePath.contains(RELATION_FILE_NAME)) {
			return outputRelationFile +formattedDate() + ".tsv";
		} else if (filePath.contains(SUPPLIER_FILE_NAME)) {
			return outputSuppulyFile + formattedDate() +".tsv";
		}
		return null;
	}
	
	private static String formattedDate() {
	    LocalDateTime now = LocalDateTime.now();
	    DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyMMddHHmmss");
	    String formattedDate = now.format(formatter);
	    return formattedDate;
	}

	/**
	 * To update the NK_EXT_MBOM_BASE.NK_CONTAINED_MATERIAL_CLASSIFICATION_10 attribute after successful execution . 
	 * @param context the 3dx<code>Context</code>object.
	 */
	public static void updatePartsAttributesAfterExport(Context context) {
		for (Map.Entry<String, String> entry : objectAttributeMapforParts.entrySet()) {
			String objectId = entry.getKey();
			String attributeValue = entry.getValue();
			try {
				DomainObject domObj = DomainObject.newInstance(context,objectId);
				domObj.setId(objectId);
				domObj.setAttributeValue(context, "NK_EXT_MBOM_BASE.NK_CONTAINED_MATERIAL_CLASSIFICATION_10",
						attributeValue);         
				logger.log(Level.INFO, "Successfully updated the attribute for object ID: " + objectId);
			} catch (FrameworkException e) {
				logger.log(Level.WARNING, "Failed to update the item attribute value.(PR_E00013) . The object ID is " + objectId);
			}
		}
	}

	/**
	 * To update the NK_EXT_MBOM_EXT_PROCHEMIST.NK_FLAG_PROCHEMIST attribute after successful execution .
	 * @param context the 3dx<code>Context</code>object.
	 */
	public static void updateRelationAttributesAfterExport(Context context) {
		for (Map.Entry<String, String> entry : objectAttributeMapforRelation.entrySet()) {
			String objectId = entry.getKey();
			String attributeValue = entry.getValue();
			try {
				DomainObject domObj = DomainObject.newInstance(context,objectId);
				domObj.setId(objectId);
				domObj.setAttributeValue(context, "NK_EXT_MBOM_EXT_PROCHEMIST.NK_FLAG_PROCHEMIST",
						attributeValue);         
				logger.log(Level.INFO, "Successfully updated the attribute for object ID: " + objectId);
			} catch (FrameworkException e) {
				logger.log(Level.WARNING, "Failed to update the item attribute value. The object ID is " + objectId);
			}
		}
	}

	/**
	 * To get the id of each object and process its attributes 
	 * @param sb - builder 
	 * @param slAttributes - Attributes mentioned in input file .
	 * @param mlResults - Holds the data which passes where clause 
	 * @param context the 3dx<code>Context</code>object.
	 * @param writer - Builder to append the data
	 * @param lockFilePath - If it the execution stops , it will delete the current lock file 
	 * @param tempFilePath - Holds the data in this temporary file .
	 * @param filePath -  holds the input file from the arguments 
	 * @throws Exception
	 */
	private static void writeAttributesToFile(StringBuilder sb, StringList slAttributes, MapList mlResults , Context context, BufferedWriter writer, String filePath, Path tempFilePath, Path lockFilePath) throws Exception {
		for (Object obj : mlResults) {
			sb.append("\n");
			Map<?, ?> objectMap = (Map<?, ?>) obj;
			String strObjId = (String) objectMap.get("id");
			DomainObject domObj = DomainObject.newInstance(context, strObjId);
			Map<?, ?> attributeMap = domObj.getAttributeMap(context);
			processAttributes(sb, slAttributes, attributeMap, filePath, strObjId, context, writer, tempFilePath, lockFilePath);
		}
	}
	/**
	 * To process each attribute with its value if not present in database show error 
	 * @param sb - builder 
	 * @param slAttributes - Attributes mentioned in input file .
	 * @param attributeMap - Holds all the attributes 
	 * @param strObjId - holds each object id 
	 * @param context - the 3dx<code>Context</code>object.
	 * @param filePath -  holds the input file from the arguments 
	 * @param writer - Builder to append the data
	 * @param tempFilePath - Holds the data in this temporary file .
	 * @param lockFilePath - If it the execution stops , it will delete the current lock file 
	 * @throws Exception
	 */
	private static void processAttributes(StringBuilder sb,StringList slAttributes, Map<?, ?> attributeMap,String filePath, String strObjId, Context context, BufferedWriter writer, 
			Path tempFilePath, 
			Path lockFilePath) throws Exception {
		for (String sAttrName : slAttributes) {
			if (attributeMap.containsKey(sAttrName)) {
				processAttribute(sb, sAttrName, attributeMap, strObjId, context, filePath);
			} else {
				logErrorAndExit(writer, tempFilePath, lockFilePath, filePath, sAttrName);
			}
		}
	}

	/**
	 * To process with attribute name matches 
	 * @param sb - StringBuilder 
	 * @param sAttrName - holds attributeName 
	 * @param attributeMap - Holds all the attributes 
	 * @param strObjId - holds each object id 
	 * @param context - the 3dx<code>Context</code>object.
	 * @param filePath -  holds the input file from the arguments 
	 */
	private static void processAttribute(StringBuilder sb, String sAttrName, Map<?, ?> attributeMap, String strObjId, Context context, String filePath) {
		if (filePath.contains(PARTS_FILE_NAME)) {
			processAttributeforParts(sb, sAttrName, attributeMap, strObjId, context);
		} else if (filePath.contains(RELATION_FILE_NAME)) {
			processAttributeforForRelation(sb, sAttrName, attributeMap, strObjId, context);
		} else if (filePath.contains(SUPPLIER_FILE_NAME)) {
			processAttributeforSupplier(sb, sAttrName, attributeMap);
		}
	}

	/**
	 * If attribute not found in the database it will show this error 
	 * @param writer - Builder to append the data
	 * @param tempFilePath - Holds the data in this temporary file .
	 * @param lockFilePath - If it the execution stops , it will delete the current lock file 
	 * @param filePath -  holds the input file from the arguments 
	 * @param sAttrName - holds attribute name 
	 * @throws Exception
	 */
	private static void logErrorAndExit(BufferedWriter writer, Path tempFilePath, Path lockFilePath, String filePath,String sAttrName) throws Exception {

		logger.log(Level.WARNING, "Not found the value described in: " + filePath + " Attribute name that cannot be read: " + sAttrName + " (PR_E00008)");
		logger.log(Level.WARNING, ERROR_OUTPUT_PROCESSING_FAILED);
		writer.close();
		Files.delete(tempFilePath);
		cleanUp(lockFilePath);
		System.exit(0);
	}
	/**
	 * To process the attribute of Relation 
	 * @param sb - StringBuilder 
	 * @param sAttrName - Holds the attribute name 
	 * @param attributeMap - Holds all the attribute of each object 
	 * @param strObjId - hold the each object id 
	 * @param context the 3dx<code>Context</code>object.
	 */
	private static void processAttributeforForRelation(StringBuilder sb, String sAttrName, Map<?, ?> attributeMap, String strObjId, Context context) {
		String sValue = (String)attributeMap.get(sAttrName);						
		sValue = replaceSpecialCharacters(sValue);	
		if(UIUtil.isNotNullAndNotEmpty(sValue)) {
			sb.append(sValue+"\t");
		}
		else {
			sb.append("\t");
		}			
		try {
			objectAttributeMapforRelation.put(strObjId, "1");
		} catch (Exception e) {
			logger.log(Level.WARNING, "Failed to add the item to the map. The object ID is " + strObjId);
		}
	}

	/**
	 * To Process the attribute of Supplier 
	 * @param sb - StringBuilder
	 * @param sAttrName - Holds attribute name 
	 * @param attributeMap - Holds all the attribute 
	 */
	private static void processAttributeforSupplier(StringBuilder sb, String sAttrName, Map<?, ?> attributeMap) {
		String sValue = (String)attributeMap.get(sAttrName);						
		sValue = replaceSpecialCharacters(sValue);	
		if(UIUtil.isNotNullAndNotEmpty(sValue)) {
			sb.append(sValue+"\t");
		}
		else {
			sb.append("\t");
		}	
	}

	/**
	 * 
	 * To process the attribute of Parts 
	 * @param sb - StringBuilder 
	 * @param sAttrName - Holds the attribute name 
	 * @param attributeMap - Holds all the attribute of each object 
	 * @param strObjId - hold the each object id 
	 * @param NKconstants -To make use constants 
	 * @param context the 3dx<code>Context</code>object.
	 */
	private static void processAttributeforParts(StringBuilder sb, String sAttrName, Map<?, ?> attributeMap, String strObjId, Context context) {
		String sValue = replaceSpecialCharacters((String) attributeMap.get(sAttrName));

		if (NK_IntegrationConstants_mxJPO.NK_VERSION.equalsIgnoreCase(sAttrName)) {
			appendVersion(sb, sValue);
		} else if (NK_IntegrationConstants_mxJPO.NK_UNIT_BASIC_QUANTITY_SALES_ORDER.equalsIgnoreCase(sAttrName)) {
			appendUnitBasicQuantity(sb, sValue);
		} else if (NK_IntegrationConstants_mxJPO.NK_PLANT.equalsIgnoreCase(sAttrName)) {
			appendPlant(sb, sValue);
		}

		addToAttributeMap(strObjId);
	}

	/**
	 * To append the version if attribute matches 
	 * @param sb - StringBuilder
	 * @param sValue - Attribute value
	 */
	private static void appendVersion(StringBuilder sb, String sValue) {
		if (UIUtil.isNullOrEmpty(sValue)) {
			sb.append("-\t");
		} else {
			sb.append(sValue).append("\t");
		}
	}

	/**
	 * @param sb - StringBuilder
	 * @param sValue - Attribute value
	 */
	private static void appendUnitBasicQuantity(StringBuilder sb, String sValue) {
		if (UIUtil.isNotNullAndNotEmpty(sValue)) {
			String[] parts = sValue.split("_");
			String firstPiece = parts.length > 0 ? parts[0] : sValue;
			sb.append("PC".equalsIgnoreCase(firstPiece) ? "piece" : firstPiece).append("\t");
		} else {
			sb.append(sValue).append("\t");
		}
	}

	/**
	 * @param sb - StringBuilder
	 * @param sValue - Attribute value
	 */
	private static void appendPlant(StringBuilder sb, String sValue) {
		if (UIUtil.isNotNullAndNotEmpty(sValue)) {
			sb.append("CN01".equalsIgnoreCase(sValue) ? "30" : "20").append("\t");
		} else {
			sb.append(sValue).append("\t");
		}
	}

	/**
	 * To update the attribute of each object 
	 * @param strObjId
	 */
	private static void addToAttributeMap(String strObjId) {
		try {
			objectAttributeMapforParts.put(strObjId, "0");
		} catch (Exception e) {
			logger.log(Level.WARNING, "Failed to add the item to the map. The object ID is " + strObjId);
		}
	}


	/**
	 * Added where clause for Supplier
	 * @param  
	 * @return
	 */
	private static String buildWhereConditionForSupplier(Context context) {
		StringBuilder sbWhere = new StringBuilder();
		sbWhere.append(CURRENT_STATUS_RELEASED);
		sbWhere.append(" && ");
		sbWhere.append("attribute[NK_DOCTYPE].value=='3'");
		return sbWhere.toString();
	}

	/**
	 * Where clause for Relation 
	 * @param context the 3dx<code>Context</code>object.
	 * @return
	 * @throws FrameworkException
	 */
	private static String buildWhereConditionForRelation(Context context) throws FrameworkException {
		StringBuilder sbWhere = new StringBuilder();	
		sbWhere.append(CURRENT_STATUS_RELEASED)
		.append(" && ")
		.append("attribute[NK_EXT_MBOM_EXT_PROCHEMIST.NK_FLAG_PROCHEMIST].value=='0'")
		.append(" && ")
		.append("attribute[NK_EXT_MBOM_EXT_BOSS.NK_FLAG_BOSS].value=='2'")
		.append(" && ")
		.append("attribute[NK_EXT_MBOM_BASE.NK_FLAG_ENVIRONMENTAL_RESEARCH].value=='1'")
		.append(" && ")
		.append("attribute[NK_EXT_MBOM_BASE.NK_TYPE_BOSS_ITEM].value!=''")
		.append(" && ")
		.append("attribute[NK_EXT_MBOM_BASE.NK_TYPE_BOSS_ITEM].value!='99'")
		.append(" && ")
		.append("attribute[NK_EXT_MBOM_BASE.NK_TYPE_BOSS_ITEM].value!='98'")      
		.append(" && ")
		.append("attribute[NK_EXT_MBOM_BASE.NK_CONTAINED_MATERIAL_CLASSIFICATION_10].value!=''")
		.append(" && ")	
		.append("(")
		.append("attribute[NK_EXT_MBOM_BOSS.NK_ENVIRONMENTAL_RESEARCH_VENDER_CODE_10].value==''")
		.append(" || ")
		.append("attribute[NK_EXT_MBOM_BOSS.NK_ENVIRONMENTAL_RESEARCH_VENDER_CODE_10].value!=attribute[NK_EXT_MBOM_BOSS.NK_VENDER_CODE1].value")
		.append(" && ")
		.append("attribute[NK_EXT_MBOM_BOSS.NK_ENVIRONMENTAL_RESEARCH_VENDER_CODE_10].value!=attribute[NK_EXT_MBOM_BOSS.NK_VENDER_CODE2].value")
		.append(" && ")
		.append("attribute[NK_EXT_MBOM_BOSS.NK_ENVIRONMENTAL_RESEARCH_VENDER_CODE_10].value!=attribute[NK_EXT_MBOM_BOSS.NK_VENDER_CODE3].value")
		.append(")");

		return sbWhere.toString();
	}

	/**
	 * To get the supplier code
	 * @param context the 3dx<code>Context</code>object. 
	 * @param mlResults
	 * @return
	 * @throws Exception 
	 */
	private static MapList getSupplierCode(Context context, MapList mlResults) throws Exception {
		Iterator<?> itr = mlResults.iterator();
		MapList mlnew = new MapList();
		String priority = readPageObject(context, CONFIG_NK_PR_EXPORT_ITEM,KEY_PRIORITY_SUPPLIER);
		String noTarget = readPageObject(context, CONFIG_NK_PR_EXPORT_ITEM,KEY_NO_TARGET_SUPPLIER);
		while (itr.hasNext()) {
			Map<?, ?> objectMap = (Map<?, ?>) itr.next();
			String vendor1 = (String) objectMap.get(SELECT_NK_VENDER_CODE1);
			String vendor2 = (String) objectMap.get(SELECT_NK_VENDER_CODE2);
			String vendor3 = (String) objectMap.get(SELECT_NK_VENDER_CODE3);
			String[] vendorValues = {vendor1, vendor2, vendor3};
			String[] vendorNames = {"NK_EXT_MBOM_BOSS.NK_VENDER_CODE1", "NK_EXT_MBOM_BOSS.NK_VENDER_CODE2", "NK_EXT_MBOM_BOSS.NK_VENDER_CODE3"};
			String status = getStatus(vendorValues, priority, noTarget);
			System.out.println("status:"+status);
			switch (status) {
			case "XXX":
				System.out.println("Status XXX: Not applicable.");
				break;

			case "---":
			case "OOO":
				processVendorWithLargestDigits(objectMap, vendorValues, vendorNames, mlnew);
				break;

			case "-O-":
			case "-OX":
			case "X-X":
			case "XO-":
			case "XOX":
				processVendor(objectMap, vendorNames[1], mlnew);
				break;

			case "-OO":
			case "XOO":
				processVendorWithLargestDigitsInPriority(objectMap, vendorValues, vendorNames, priority, mlnew);
				break;

			case "-X-":
			case "--X":
				processVendorWithLargestDigitsExcludingNoTarget(objectMap, vendorValues, noTarget, vendorNames, mlnew);
				break;

			case "-XO":
			case "--O":
			case "X-O":
			case "XX-":
			case "XXO":
				processVendor(objectMap, vendorNames[2], mlnew);
				break;

			case "-XX":
			case "O--":
			case "O-X":
			case "OX-":
			case "OXX":
				processVendor(objectMap, vendorNames[0], mlnew);
				break;

			case "O-O":
			case "OO-":
			case "OOX":
			case "OXO":
				processVendorWithMoreDigits(objectMap, vendorValues, vendorNames, mlnew);
				break;

			case "X--":
				processVendorWithLargestDigitsForXCondition(objectMap, vendorValues, noTarget, vendorNames, mlnew);
				break;

			default:
				System.out.println("Result: Status is XXX does not meet the criteria.");
				break;
			}
		}
		return mlnew;	
	}

	/**
	 * To check largest digits 
	 * @param objectMap Holds the all the objects 
	 * @param vendorValues - holds vendor values 
	 * @param noTarget - holds the values from config file 
	 * @param vendorNames - holds venodr names 
	 * @param mlnew - maplist to hold the data 
	 */
	private static void processVendorWithLargestDigitsForXCondition(Map<?, ?> objectMap, String[] vendorValues, String noTarget, String[] vendorNames, MapList mlnew) {
		int targetVendorIndex = getVendorWithLargestDigitsForXCondition(vendorValues, noTarget, 0, 1);
		processVendor(objectMap, vendorNames[targetVendorIndex], mlnew);
	}

	/**
	 * To check vendors wit more digits 
	 * @param objectMap Holds the all the objects 
	 * @param vendorValues - holds vendor values 
	 * @param vendorNames - Holds vendor names 
	 * @param mlnew - maplist to hold the data 
	 */
	private static void processVendorWithMoreDigits(Map<?, ?> objectMap, String[] vendorValues, String[] vendorNames, MapList mlnew) {
		int vendor1Digits = vendorValues[0].length();
		int vendor3Digits = vendorValues[2].length();
		if (vendor1Digits > vendor3Digits) {
			processVendor(objectMap, vendorNames[0], mlnew);
		} else if (vendor3Digits > vendor1Digits) {
			processVendor(objectMap, vendorNames[2], mlnew);
		} else {
			processVendor(objectMap, vendorNames[0], mlnew);
		}
	}

	/**
	 * To check the largest digit in priority 
	 * @param objectMap Holds the all the objects 
	 * @param vendorValues - holds vendor values 
	 * @param vendorNames - Holds vendor names 
	 * @param mlnew - Maplist to hold the data 
	 * @param priority -Holds the value of priority from the config file .

	 */
	private static void processVendorWithLargestDigitsInPriority(Map<?, ?> objectMap, String[] vendorValues, String[] vendorNames, String priority, MapList mlnew) {
		int targetVendorIndex = getVendorWithLargestDigitsInPriority(vendorValues, priority, 1, 2);
		processVendor(objectMap, vendorNames[targetVendorIndex], mlnew);
	}

	/**
	 * To check all the vendors with largest digit 
	 * @param objectMap Holds the all the objects 
	 * @param vendorValues - holds vendor values 
	 * @param vendorNames - Holds vendor names 
	 * @param mlnew - maplist to hold the data 
	 */
	private static void processVendorWithLargestDigits(Map<?, ?> objectMap, String[] vendorValues, String[] vendorNames, MapList mlnew) {
		int targetVendorIndex = getVendorWithLargestDigits(vendorValues);
		processVendor(objectMap, vendorNames[targetVendorIndex], mlnew);
	}

	/**
	 * @param objectMap Holds the all the objects 
	 * @param vendorName - Holds vendor names 
	 * @param mlnew - maplist to hold the data 
	 */
	@SuppressWarnings("unchecked")
	private static void processVendor(Map<?, ?> objectMap, String vendorName, MapList mlnew) {
		String value = (String) objectMap.get(String.format(ATTRIBUTE_EXPRESSION, vendorName));
		System.out.println("The attribute is "+vendorName+"and value:"+value);
		if (UIUtil.isNotNullAndNotEmpty(value)) {
			mlnew.add(objectMap);
		}
	}

	/**
	 * To check vendors with largest digits excluding NoTarget 
	 * @param objectMap Holds the all the objects 
	 * @param vendorValues - holds vendor values 
	 * @param noTarget - holds the values from config file 
	 * @param vendorNames - holds venodr names 
	 * @param mlnew - maplist to hold the data 
	 */
	private static void processVendorWithLargestDigitsExcludingNoTarget(Map<?, ?> objectMap, String[] vendorValues, String noTarget, String[] vendorNames, MapList mlnew) {
		int targetVendorIndex = getVendorWithLargestDigitsExcludingNoTarget(vendorValues, noTarget, 0, 1);
		if (targetVendorIndex == -1) {
			processVendor(objectMap, vendorNames[0], mlnew);
		} else {
			processVendor(objectMap, vendorNames[targetVendorIndex], mlnew);
		}
	}

	/**
	 * @param vendorValues - Holds the vendor values 
	 * @param priority -  Holds the priority values from the config file .
	 * @param noTarget - holds the noTarget values from the config file 
	 * @return
	 */
	private static String getStatus(String[] vendorValues, String priority, String noTarget) {
		StringBuilder statusBuilder = new StringBuilder();
		for (String vendor : vendorValues) {
			boolean inPriority = priority.contains(vendor);
			boolean inNoTarget = noTarget.contains(vendor);

			if (inPriority && inNoTarget) {
				statusBuilder.append("O");
			} else if (inPriority) {
				statusBuilder.append("O");
			} else if (inNoTarget) {
				statusBuilder.append("X");
			} else {
				statusBuilder.append("-");
			}
		}
		return statusBuilder.toString();
	}
	/**
	 * To get the Largest digit from all the vendors 
	 * @param vendorValues - holds the vendor values 
	 * @param noTarget - holds the noTarget values from the config file 
	 * @param vendorIndex1 - to compare index
	 * @param vendorIndex2 - to compare index
	 * @return
	 */
	private static int getVendorWithLargestDigitsForXCondition(String[] vendorValues, String noTarget, int vendorIndex1, int vendorIndex2) {
		boolean vendor1InNoTarget = noTarget.contains(vendorValues[vendorIndex1]);
		boolean vendor2InNoTarget = noTarget.contains(vendorValues[vendorIndex2]);

		if (vendor1InNoTarget && vendor2InNoTarget) {
			return 1; // Both vendors are in `noTarget`, use vendor2
		} else if (vendor1InNoTarget) {
			return 1; // Vendor1 is in `noTarget`, prefer vendor2
		} else if (vendor2InNoTarget) {
			return 1; // Vendor2 is in `noTarget`, use vendor2
		} else {
			// Both vendors are not in `noTarget`, compare digits
			if (vendorValues[vendorIndex1].length() > vendorValues[vendorIndex2].length()) {
				return vendorIndex1;
			} else if (vendorValues[vendorIndex1].length() < vendorValues[vendorIndex2].length()) {
				return vendorIndex2;
			} else {
				return vendorIndex2; // If the number of digits is the same, default to vendor2
			}
		}
	}

	/**
	 * Overloaded method to compare two vendors for the "-X-" condition
	 * @param vendorValues - holds the vendor values 
	 * @param noTarget - holds the noTarget values from the config file 
	 * @param vendorIndex1 - to compare index
	 * @param vendorIndex2 - to compare index
	 * @return
	 */
	private static int getVendorWithLargestDigitsExcludingNoTarget(String[] vendorValues, String noTarget, int vendorIndex1, int vendorIndex2) {
		boolean vendor1InNoTarget = noTarget.contains(vendorValues[vendorIndex1]);
		boolean vendor2InNoTarget = noTarget.contains(vendorValues[vendorIndex2]);

		if (vendor1InNoTarget && vendor2InNoTarget) {
			return -1; // Means vendor1 should be the target in this case
		} else if (vendor1InNoTarget) {
			return vendorIndex2;
		} else if (vendor2InNoTarget) {
			return vendorIndex1;
		} else {
			// Compare the number of digits
			if (vendorValues[vendorIndex1].length() > vendorValues[vendorIndex2].length()) {
				return vendorIndex1;
			} else if (vendorValues[vendorIndex1].length() < vendorValues[vendorIndex2].length()) {
				return vendorIndex2;
			} else {
				return vendorIndex1; // If the digits are equal, default to vendor1
			}
		}
	}

	/**
	 * Method to find the vendor with the largest digits in the priority list (for -OO case)
	 * @param vendorValues - holds the vendor values 
	 * @param noTarget - holds the noTarget values from the config file 
	 * @param vendorIndex1 - to compare index
	 * @param vendorIndex2 - to compare index
	 * @return
	 */
	private static int getVendorWithLargestDigitsInPriority(String[] vendorValues, String priority, int vendorIndex1, int vendorIndex2) {
		boolean vendor1InPriority = priority.contains(vendorValues[vendorIndex1]);
		boolean vendor2InPriority = priority.contains(vendorValues[vendorIndex2]);

		if (vendor1InPriority && vendor2InPriority) {
			// Compare number of digits
			if (vendorValues[vendorIndex1].length() > vendorValues[vendorIndex2].length()) {
				return vendorIndex1;
			} else if (vendorValues[vendorIndex1].length() < vendorValues[vendorIndex2].length()) {
				return vendorIndex2;
			} else {
				// If digits are the same, vendor2 has priority
				return vendorIndex2;
			}
		} else if (vendor1InPriority) {
			return vendorIndex1;
		} else {
			return vendorIndex2;
		}
	}
	/**
	 * To get the largest vendor 
	 * @param vendorValues - holds the vendor values 
	 * @return
	 */
	private static int getVendorWithLargestDigits(String[] vendorValues) {
		int maxDigitsIndex = 0;
		for (int i = 1; i < vendorValues.length; i++) {
			if (vendorValues[i].length() > vendorValues[maxDigitsIndex].length()) {
				maxDigitsIndex = i;
			} else if (vendorValues[i].length() == vendorValues[maxDigitsIndex].length()) {
				// If they have the same number of digits, priority is vendor1 > vendor2 > vendor3
				// The first vendor in the list is already the highest priority, so no action needed
			}
		}
		return maxDigitsIndex;
	}


	/**
	 * Where condition for find objects for parts 
	 * @param context the 3dx<code>Context</code>object.
	 * @return string
	 * @throws Exception
	 */
	private static String buildWhereConditionForParts(Context context) throws Exception {		
		String sNO_TARGET_RATING_CLASSIFICATION = readPageObject(context, CONFIG_NK_PR_EXPORT_ITEM,KEY_NO_TARGET_RATING_CLASSIFICATION); 
		Set<String> values = new HashSet<>(Arrays.asList(sNO_TARGET_RATING_CLASSIFICATION.split(",\\s*")));	
		StringBuilder sbWhere = new StringBuilder();
		sbWhere.append(CURRENT_STATUS_RELEASED)
		.append(" && ")
		.append("attribute[NK_EXT_MBOM_EXT_PROCHEMIST.NK_FLAG_PROCHEMIST].value=='0'")
		.append(" && ")
		.append("attribute[NK_EXT_MBOM_EXT_BOSS.NK_FLAG_BOSS].value=='2'")
		.append(" && ")
		.append("attribute[NK_EXT_MBOM_BASE.NK_FLAG_ENVIRONMENTAL_RESEARCH].value=='1'")
		.append(" && ")
		.append("attribute[NK_EXT_MBOM_BASE.NK_TYPE_BOSS_ITEM].value!=''")
		.append(" && ")
		.append("attribute[NK_EXT_MBOM_BASE.NK_TYPE_BOSS_ITEM].value!='99'")
		.append(" && ")
		.append("attribute[NK_EXT_MBOM_BASE.NK_TYPE_BOSS_ITEM].value!='98'")      
		.append(" && ")
		.append("attribute[NK_EXT_MBOM_BASE.NK_CONTAINED_MATERIAL_CLASSIFICATION_10].value==''");
		sbWhere.append(" && ");
		sbWhere.append("(");
		boolean first = true;
		for (String value : values) {
			if (!first) {
				sbWhere.append(" && ");
			}
			sbWhere.append("attribute[NK_EXT_MBOM_PARTS.NK_RATING_CLASSIFICATION].value!='")
			.append(value)
			.append("'");
			first = false;
		} 
		sbWhere.append(")");
		return sbWhere.toString();    
	}

	/**
	 * @param input - Each attribute value to check whether it contains prohibited character or not
	 * @return
	 */
	public static String replaceSpecialCharacters(String input) {	
		if(UIUtil.isNotNullAndNotEmpty(input)) {
			return input.replace("\"", " ").replace("�cHB9H09}", " ");
		}else
			return input;
	}

	/**
	 * To generate temp file with the specific format 
	 * @return
	 */
	private static String generateTempFileName() {
		LocalDateTime now = LocalDateTime.now();
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyyMMddHHmmss");
		return "temp" + now.format(formatter) + ".tsv";
	}	
	/**
	 * To print whatever the content present in FIX[] headers . 
	 * @param sb
	 * @param line
	 * @param isFirstLine
	 */
	private static void processFixLine(StringBuilder sb, String line, boolean isFirstLine) {
		String content = line.substring(line.indexOf('[') + 1, line.lastIndexOf(']'));	       
		if (!isFirstLine) {
			sb.append("\n");
		}	        
		sb.append(content.trim());
	}

	/**
	 * @param lockFilePath to check multiple instance running and delete 
	 * @throws IOException
	 */
	private static void createLockFile(Path lockFilePath) throws IOException {
		try {
			Files.createFile(lockFilePath);
		} catch (IOException e) {
			System.out.println("Failed to create lock file. Exiting...");
			System.exit(1);
		}
	}	
	/**
	 * check the Property File Error
	 * @param lockFilePath to check multiple instance running and delete 
	 * @throws IOException
	 */
	private static void handlePropertyFileError(Path lockFilePath) throws IOException {
		logger.log(Level.WARNING, "Could not read NK_ExportItem.conf.(PR_E00003)");
		cleanUp(lockFilePath);
		System.exit(0);
	}
	/**
	 * prints the Argument Error 
	 * @param lockFilePathto check multiple instance running and delete 
	 * @throws IOException
	 */
	private static void handleArgumentError(Path lockFilePath) throws IOException {
		logger.log(Level.WARNING, "Not enough arguments. (PR_E00002)");
		cleanUp(lockFilePath);
		System.exit(0);
	}

	/**
	 * @param lockFilePath to check multiple instance running and delete 
	 * @throws IOException
	 */
	private static void cleanUp(Path lockFilePath) throws IOException {
		Files.deleteIfExists(lockFilePath);
		if (handler != null) {
			handler.close();
		}
	}
	/**
	 * Read Page object from the DB 
	 *
	 * @param context
	 * @param strPageName - Name of the page file 
	 * @param strKeyName - key name present in the page file 
	 * @throws Exception
	 */
	public static String readPageObject(Context context, String strPageName, String strKeyName) throws Exception {
		Properties propNotification = new Properties();
		String strProperty = DomainConstants.EMPTY_STRING;
		try {
			Page pageAttributePopulation = new Page(strPageName);
			pageAttributePopulation.open(context);
			String strProperties = pageAttributePopulation.getContents(context);
			pageAttributePopulation.close(context);
			InputStream input = new ByteArrayInputStream(strProperties.getBytes("UTF8"));
			propNotification.load(input);
			if(propNotification.containsKey(strKeyName)) {
				strProperty = propNotification.getProperty(strKeyName);
			}else {
				logger.log( Level.INFO, strKeyName +"IS NOT PRESENT");			
				System.exit(0);			
			}
		} catch (Exception e) {
			System.out.println("Check page file name");
			e.printStackTrace();
		}
		return strProperty;
	}
	/**
	 * @param dir holds the output directory path 
	 */
	private static void validateDirectory(String dir) {
		File file = new File(dir);
		if (file.exists() && file.isDirectory()) {
			logger.log(Level.INFO, "outputDir " + dir);
		} else {
			logger.log(Level.WARNING, "Not found the destination folder path.(PR_E00004)");
			System.exit(0);
		}
	}

	/**
	 * 
	 * @param args
	 * @return
	 */
	private static String getLogString(String... args) {
		StringBuilder sbMessage = new StringBuilder(200);
		sbMessage.append(new Date());
		sbMessage.append(",");
		for (String msg : args) {
			sbMessage.append(msg);
			sbMessage.append(",");
		}
		return sbMessage.toString();
	}
	/**
	 * 
	 * @param logDir - path specified to print the logs 
	 * @param loggerLevel
	 * @throws IOException
	 */
	private static void initiateLogger(String logDir , String loggerLevel ) throws IOException {
		if (handler != null) {
	        handler.close(); 
	    }
	    LocalDateTime now = LocalDateTime.now();
	    DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyyMMddHHmmss");
	    String formattedDate = now.format(formatter);	
	    String path = logDir + "/Logs";
	    handler = new FileHandler(path + formattedDate + ".log", true);
	    handler.setFormatter(new HD_LoggingFormatter());
	    handler.setEncoding("UTF-8");
	    logger.addHandler(handler);
	    String level = loggerLevel != null && !loggerLevel.isEmpty() ? loggerLevel : "INFO";
	    logger.setLevel(Level.parse(level));

	}
	private static void cleanUpLogger() {
	    if (handler != null) {
	        handler.close();
	        logger.removeHandler(handler);
	        handler = null; // Clear the handler reference
	    }
	}
	/**
	 * 
	 * @author DSGS
	 *
	 */
	private static class HD_LoggingFormatter extends Formatter {
		@Override
		public String format(LogRecord record) {
			StringBuilder sb = new StringBuilder();
			sb.append(record.getLevel()).append(',');
			sb.append(record.getMessage()).append('\n');
			return sb.toString();
		}
	}
	public static void logOutput(String outputPartsFile, int outputNumberParts,
			String outputRelationFile, int outputNumberRelation,
			String outputSuppulyFile, int outputNumberSupply) {
		String message = String.format(
				"Output processing completed. File Name: '%s' OutputNumber: %d " +
						"File Name: '%s' OutputNumber: %d " +
						"File Name: '%s' OutputNumber: %d (PR_I00002)",
						outputPartsFile, outputNumberParts,
						outputRelationFile, outputNumberRelation,
						outputSuppulyFile, outputNumberSupply
				);

		logger.log(Level.INFO, message);
	}
}
