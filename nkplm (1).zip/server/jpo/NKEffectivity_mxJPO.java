import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Properties;
import java.util.logging.FileHandler;
import java.util.logging.Formatter;
import java.util.logging.Logger;
import java.util.stream.Collectors;
import java.util.logging.Level;
import java.util.logging.LogRecord;
import java.util.stream.Stream;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;
import java.util.Arrays;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.matrixone.apps.domain.DomainConstants;
import com.matrixone.apps.domain.DomainObject;

import matrix.db.Context;
import matrix.db.Page;
import matrix.util.StringList;

import com.matrixone.apps.domain.util.FrameworkException;
import com.matrixone.apps.domain.util.MapList;
import com.matrixone.apps.domain.util.MqlUtil;

import java.util.Date;

public class NKEffectivity_mxJPO {

	// Logger setup with proper exception handling
	private static final Logger logger = Logger.getLogger(NKEffectivity_mxJPO.class.getName());
	private static FileHandler handler = null;

	/**
	 * This method is used to executeEffectivity
	 * 
	 * @param context
	 *            the ENOVIA <code>Context</code> object.
	 * @param args
	 *            [0] holds the document objectId. [1] holds the action
	 * @throws FrameworkException
	 * @throws InterruptedException
	 * @throws ParseException
	 * @throws Exception
	 *             if operation fails.
	 * @exclude
	 */

	public static void executeEffectivity(Context context, String[] args)
			throws IOException, FrameworkException, InterruptedException, ParseException {

		String logDir = readPageObject(context, NKConstants_mxJPO.EFFECT_PROP_FILE, "LOG_DIR");
		String loggerLevel = readPageObject(context, NKConstants_mxJPO.EFFECT_PROP_FILE, "Logger.Level");
		String INPUT_DIR = readPageObject(context, NKConstants_mxJPO.EFFECT_PROP_FILE, "INPUT_VALID_DATE_DIR");
		String RESULT_DIR = readPageObject(context, NKConstants_mxJPO.EFFECT_PROP_FILE, "RESULT_VALID_DATE_DIR");
		initiateLogger(logDir, loggerLevel);

		Path lockFilePath = Paths.get(logDir, "process.lock");
		try {
			checkIfAlreadyRunning(lockFilePath);
			createLockFile(lockFilePath);
			logger.log(Level.INFO, "BO_I03001:Processing has started ");

			if (args.length != 1) {
				handleArgumentError(lockFilePath);
			}
			File file = new File(args[0]);

			// Check if the file exists and is a file (not a directory)
			if (!file.exists()) {
				logger.log(Level.WARNING, "BO_E03003:Could not read NK_BO_validDateRevert.properties");
				cleanUp(lockFilePath);
				System.exit(0);
			}

			if (args[0] == null || args[0].isEmpty() || !args[0].endsWith(".properties")) {
				handlePropertyFileError(lockFilePath);
			}
			if (INPUT_DIR.isEmpty() || RESULT_DIR.isEmpty()) {
				logger.log(Level.WARNING, "BO_E03004: Not found the destination folder path");
				cleanUp(lockFilePath);
				System.exit(0);

			} else {
				validateDirectories(lockFilePath, INPUT_DIR, RESULT_DIR);
			}
			readEffectiveDate(context, INPUT_DIR, lockFilePath, RESULT_DIR);
			logger.log(Level.INFO, "BO_I03002:Input processing completed.File");
		} catch (IOException e) {
			logger.log(Level.INFO, "BO_I03003:Input processing failed. Please check the error message");
		} finally {
			cleanUpResources(lockFilePath);
		}
	}

	/**
	 * Cleans up resources, including the lock file and logger.
	 *
	 * @param lockFilePath
	 *            The path of the lock file to delete.
	 */
	private static void cleanUpResources(Path lockFilePath) {
		try {
			cleanUp(lockFilePath);
		} catch (IOException e) {
			logger.log(Level.INFO, "Error in cleanUpResources method:", e);
		} finally {
			cleanUpLogger();
		}
	}

	/**
	 * Checks if a process lock file exists and exits the program if it does.
	 *
	 * @param lockFilePath
	 *            The path of the lock file to check.
	 * @throws IOException
	 *             If an error occurs while checking the lock file.
	 */
	private static void checkIfAlreadyRunning(Path lockFilePath) throws IOException {
		if (Files.exists(lockFilePath)) {
			logger.log(Level.WARNING, "BO_E03001:Program is already running");
			System.exit(0);
		}
	}

	/**
	 * Validates that the specified directories exist.
	 *
	 * @param dirs
	 *            The directories to validate.
	 * @throws IOException
	 *             If an error occurs during validation.
	 */
	private static void validateDirectories(Path lockFilePath, String... dirs) throws IOException {
		for (String dir : dirs) {
			validateDirectory(dir, lockFilePath);
		}
	}

	/**
	 * Updates item attributes by processing TSV files in the specified input
	 * directory. Successfully processed files are moved to the success
	 * directory, while files that encounter errors are moved to the error
	 * directory.
	 *
	 * @param context
	 *            The context from which the method is called.
	 * @param inputDir
	 *            The directory containing input TSV files.
	 * @param lockFilePath
	 *            The path of the lock file to prevent concurrent processing.
	 * @param successDir
	 *            The directory where successfully processed files will be
	 *            moved.
	 * @param errorDir
	 *            The directory where files that failed processing will be
	 *            moved.
	 * @throws FrameworkException
	 * @throws ParseException
	 * @throws Exception
	 *             If an error occurs during processing.
	 */
	private static void readEffectiveDate(Context context, String INPUT_DIR, Path lockFilePath, String RESULT_DIR)
			throws IOException, FrameworkException, ParseException {

		Path inputDirectory = Paths.get(INPUT_DIR);

		try (Stream<Path> csvFilesStream = Files.list(inputDirectory)
				.filter(file -> file.toString().endsWith(".csv"))) {
			List<Path> csvFiles = csvFilesStream.collect(Collectors.toList());

			File directory = new File(inputDirectory.toString());
			File[] allFiles = directory.listFiles((dir, name) -> name.endsWith(".csv"));

			if (csvFiles.isEmpty()) {
				logger.log(Level.SEVERE, "BO_I01004:Not found the target item");
				cleanUp(lockFilePath);
				System.exit(0);
				return;
			}

			if (allFiles != null) {
				// Sort the files by the embedded timestamp in the filename
				Arrays.sort(allFiles, new Comparator<File>() {
					@Override
					public int compare(File file1, File file2) {
						// Extract and compare the timestamp from filenames
						String timestamp1 = extractTimestamp(file1.getName());
						String timestamp2 = extractTimestamp(file2.getName());

						// Compare timestamps (oldest to newest)
						return timestamp1.compareTo(timestamp2);
					}
				});

			}

			for (File file : allFiles) {
				logger.log(Level.FINE, "Processing file: {0}", file.getName());

				processCsvFile(context, file, lockFilePath, INPUT_DIR, RESULT_DIR);

			}
		} catch (IOException e) {
			logger.log(Level.SEVERE, "Error reading files in the directory:{0}", e.getMessage());
		}
	}

	/**
	 * Processes a CSV file to update attributes in the system based on the
	 * provided data.
	 *
	 * @param context
	 *            The context used for domain operations.
	 * @param csvFilePath
	 *            The path to the CSV file to be processed.
	 * @param lockFilePath
	 *            The path to the lock file, which prevents concurrent
	 *            processing.
	 * @return true if processing is successful; false otherwise.
	 * @throws FrameworkException
	 *             If an error occurs while processing the file.
	 * @throws IOException
	 * @throws ParseException
	 */
	private static void processCsvFile(Context context, File file, Path lockFilePath, String INPUT_DIR,
			String RESULT_DIR) throws FrameworkException, IOException, ParseException {
		Path folderName = null;
		String caID = null;
		SimpleDateFormat inputFormat = new SimpleDateFormat("yyyy/MM/dd");
		SimpleDateFormat outputFormat = new SimpleDateFormat("MM/dd/yyyy");

		try (BufferedReader reader = Files.newBufferedReader(file.toPath())) {
			String line;
			while ((line = reader.readLine()) != null) {
				// Split the line by a comma to separate ID and Date
				String[] columns = line.split("\t");
				if (columns.length == 2) {
					String changeNumber = columns[0].trim();
					String effectiveDate = columns[1].trim();
					// Process and print each row (ID and Date)
					logger.log(Level.FINE, "ECO:{0} ", changeNumber);
					logger.log(Level.FINE, "Date:{0} ", effectiveDate);

					boolean verify = verifyData(changeNumber, effectiveDate);

					if (verify) {
						folderName = createFolder(INPUT_DIR);
						caID = getChangeAction(context, changeNumber);
						if (caID == null) {
							logger.log(Level.WARNING, "BO_E03006:Failed to find Change Action data. name:{0}",
									changeNumber);

						} else {
							DomainObject dobj = DomainObject.newInstance(context, caID);
							Date date = inputFormat.parse(effectiveDate);

							// Format the Date object into the desired output
							// format
							String formattedDate = outputFormat.format(date);
							MqlUtil.mqlCommand(context, "mod bus $1 $2 $3", caID, "NK_APPLY_DATE", formattedDate);
						}

					}

				}

				if (columns.length == 2 && columns[0].isEmpty()) {
					logger.log(Level.WARNING, "BO_E03007:No ECO number is set in the effective start date file for:{0}",
							columns[1].trim());
				}
				if (columns.length == 1) {
					logger.log(Level.WARNING,
							"BO_E03008:No Effective start date is set in the effective start date file for:{0}",
							columns[0].trim());
					;
				}
			}
		} catch (IOException e) {
			cleanUp(lockFilePath);
			logger.log(Level.FINE, "Processing file:{0} ", file.getName());
		}

		if (folderName != null && caID != null) {
			moveFileToFolder(file, folderName);
			Path inputDir = Paths.get(INPUT_DIR);
			compressFolder(inputDir,folderName);
		}
	}

	private static boolean verifyData(String changeNumber, String effectiveDate) {
		boolean retVerify = true;
		try {
			if (changeNumber.isEmpty()) {
				logger.log(Level.FINE, "BO_E03007:No ECO number is set in the effective start date file");
				retVerify = false;
			}

			if (effectiveDate.isEmpty()) {
				logger.log(Level.FINE, "BO_E03008:No Effective start date is set in the effective start date file");
				retVerify = false;
			}

			if (!isValidDateFormat(effectiveDate)) {
				logger.log(Level.WARNING, "Effective date in the effective date file is in an incorrect format");
				logger.log(Level.WARNING, "{0}: Effective start date with incorrect format set", effectiveDate);
				retVerify = false;
			}

		} catch (Exception e) {
			logger.log(Level.FINE, "Error in Method verifyData");
		}
		return retVerify;
	}

	/**
	 * @param lockFilePath
	 *            to check multiple instance running and delete
	 * @throws IOException
	 */
	private static Path createFolder(String input_dir) {

		Path returnName = null;
		try {

			if (input_dir == null || input_dir.isEmpty()) {
				logger.log(Level.FINE, "Error: INPUT_VALID_DATE_DIR not found in the configuration file");
				return returnName;
			}

			// Get the current date and time in the specified format
			// (yyyyMMddHHmmss)
			String formattedDateTime = getCurrentDateTimeFormatted();

			// Create the full folder path
			Path newFolderPath = Paths.get(input_dir, formattedDateTime);

			// Create the folder
			File folder = newFolderPath.toFile();
			if (!folder.exists()) {
				if (folder.mkdirs()) {
					logger.log(Level.FINE, "Folder created successfully:{0}", newFolderPath);
					returnName = folder.toPath();

				} else {
					logger.log(Level.FINE, "Error: Unable to create the folder.");
				}
			} else {
				logger.log(Level.FINE, "Folder already exists:{0}", newFolderPath);
			}
		} catch (Exception e) {
			logger.log(Level.FINE, "Error in Method createFolder");
		}
		return returnName;
	}

	/**
	 * @param lockFilePath
	 *            to check multiple instance running and delete
	 * @throws IOException
	 */
	private static void createLockFile(Path lockFilePath) throws IOException {
		try {
			Files.createFile(lockFilePath);
		} catch (IOException e) {
			System.exit(1);
		}
	}

	/**
	 * check the Property File Error
	 * 
	 * @param lockFilePath
	 *            to check multiple instance running and delete
	 * @throws IOException
	 */
	private static void handlePropertyFileError(Path lockFilePath) throws IOException {
		logger.log(Level.WARNING, "BO_E03003:Could not read NK_BO_validDateRevert.properties");
		cleanUp(lockFilePath);
		System.exit(0);
	}

	/**
	 * prints the Argument Error
	 * 
	 * @param lockFilePathto
	 *            check multiple instance running and delete
	 * @throws IOException
	 */
	private static void handleArgumentError(Path lockFilePath) throws IOException {
		logger.log(Level.WARNING, "BO_E03002:Not enough arguments");
		cleanUp(lockFilePath);
		System.exit(0);
	}

	/**
	 * @param lockFilePath
	 *            to check multiple instance running and delete
	 * @throws IOException
	 */
	private static void cleanUp(Path lockFilePath) throws IOException {
		Files.deleteIfExists(lockFilePath);
		if (handler != null) {
			handler.close();
		}
	}

	/**
	 * Read Page object from the DB
	 *
	 * @param context
	 * @param strPageName
	 *            - Name of the page file
	 * @param strKeyName
	 *            - key name present in the page file
	 * @throws Exception
	 */
	public static String readPageObject(Context context, String strPageName, String strKeyName)
			throws FrameworkException {
		Properties propNotification = new Properties();
		String strProperty = DomainConstants.EMPTY_STRING;
		try {
			Page pageAttributePopulation = new Page(strPageName);
			pageAttributePopulation.open(context);
			String strProperties = pageAttributePopulation.getContents(context);
			pageAttributePopulation.close(context);
			InputStream input = new ByteArrayInputStream(strProperties.getBytes("UTF8"));
			propNotification.load(input);
			if (propNotification.containsKey(strKeyName)) {
				strProperty = propNotification.getProperty(strKeyName);
			} else {
				logger.log(Level.INFO, strKeyName, "{0}:IS NOT PRESENT");
				System.exit(0);
			}
		} catch (Exception e) {
			logger.log(Level.INFO, "Error in readPageObject method:", e);
		}
		return strProperty;
	}

	/**
	 * @param dir
	 *            holds the output directory path
	 */
	private static void validateDirectory(String dir, Path lockFilePath) {
		File file = new File(dir);
		if (!file.exists() || !file.isDirectory()) {
			logger.log(Level.WARNING, "BO_E03004: Not found the destination folder path");
			try {
				cleanUp(lockFilePath);
			} catch (IOException e) {
				logger.log(Level.INFO, "Error in validateDirectory method:", e);
			}
			System.exit(0);
		}
	}

	/**
	 * 
	 * @param logDir
	 *            - path specified to print the logs
	 * @param loggerLevel
	 * @throws IOException
	 */
	private static void initiateLogger(String logDir, String loggerLevel) throws IOException {
		if (handler != null) {
			handler.close();
		}
		LocalDateTime now = LocalDateTime.now();
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyyMMddHHmmss");
		String formattedDate = now.format(formatter);
		String path = logDir + "/Logs";
		handler = new FileHandler(path + formattedDate + ".log", true);
		handler.setFormatter(new HD_LoggingFormatter());
		handler.setEncoding("UTF-8");
		logger.addHandler(handler);
		String level = loggerLevel != null && !loggerLevel.isEmpty() ? loggerLevel : "INFO";
		logger.setLevel(Level.parse(level));

	}

	private static void cleanUpLogger() {
		if (handler != null) {
			handler.close();
			logger.removeHandler(handler);
			handler = null;
		}
	}

	private static class HD_LoggingFormatter extends Formatter {
		@Override
		public String format(LogRecord read) {
			StringBuilder sb = new StringBuilder();
			sb.append(read.getLevel()).append(',');
			sb.append(read.getMessage()).append('\n');
			return sb.toString();
		}
	}

	// Method to extract the timestamp (date and time) from the filename
	private static String extractTimestamp(String filename) {
		// Find the position of the last underscore in the filename
		int startIdx = filename.lastIndexOf('_') + 1;
		int endIdx = filename.indexOf(".csv");
		if (startIdx != -1 && endIdx != -1 && endIdx > startIdx) {
			return filename.substring(startIdx, endIdx);
		}
		return "";
	}

	// Function to check if the date string is in the correct format (YYYY/MM/DD
	// or YYYY/M/D)
	private static boolean isValidDateFormat(String dateStr) {
		// Define regex pattern for both formats
		String regex = "^\\d{4}/\\d{1,2}/\\d{1,2}$"; // Matches YYYY/MM/DD or
														// YYYY/M/D
		Pattern pattern = Pattern.compile(regex);
		Matcher matcher = pattern.matcher(dateStr);
		return matcher.matches();
	}

	// Method to get the current date and time in the format yyyyMMMddHHmmss
	private static String getCurrentDateTimeFormatted() {
		// Get the current date and time
		LocalDateTime now = LocalDateTime.now();
		// Format the date and time as yyyyMMMddHHmmss
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyyMMddHHmmss");
		return now.format(formatter);
	}

	public static String getChangeAction(Context context, String changeNumber) throws FrameworkException {

		String returnString = null;

		try {
			StringList objectSelects = new StringList();
			objectSelects.add(DomainConstants.SELECT_ID);
			String objectWhere = "name == \"" + changeNumber + "\" && current== \"Complete\" ";

			MapList cas = DomainObject.findObjects(context, NKConstants_mxJPO.TYPE_CHANGE_ACTION, // type
																									// filter
					"eService Production", // vault filter
					objectWhere, // where clause
					objectSelects); // object selects
			returnString = getStringFromMapList(cas, "id");
		} catch (FrameworkException e) {
			logger.log(Level.INFO, "Error in getChangeAction method:", e);
		}

		return returnString;
	}

	public static String getStringFromMapList(MapList mList, String key) {
		Map<String, String> map;
		int size = mList.size();
		String lreturn = null;

		for (int i = 0; i < size; i++) {
			map = (Map<String, String>) mList.get(i);
			lreturn = map.get(key);
		}

		return lreturn;
	}

	private static void moveFileToFolder(File file, Path folderName) {
		Path sourcePath = file.toPath();
		Path targetPath = folderName.resolve(file.getName());

		try {
			// Create the target folder if it doesn't exist
			Files.createDirectories(targetPath.getParent());

			// Move the file to the new directory
			Files.move(sourcePath, targetPath, StandardCopyOption.REPLACE_EXISTING);
			logger.log(Level.INFO, "File moved successfully to: {0}", targetPath);
		} catch (IOException e) {
			logger.log(Level.SEVERE, "Failed to move file {0} to {1}: {2}",
					new Object[] { sourcePath, targetPath, e.getMessage() });
		}
	}

	// Compresses the folder into a zip file
	private static void compressFolder(Path sourceFolder, Path zipFilePath) throws IOException {
		try (ZipOutputStream zipOut = new ZipOutputStream(new FileOutputStream(zipFilePath.toFile()))) {
			Path sourceFolderPath = sourceFolder.toAbsolutePath();
			Files.walk(sourceFolder).filter(path -> !Files.isDirectory(path)) // Skip
																				// directories
					.forEach(path -> {
						// Resolve the file's path relative to the source folder
						Path relativePath = sourceFolderPath.relativize(path);
						try {
							zipOut.putNextEntry(new ZipEntry(relativePath.toString()));
							Files.copy(path, zipOut);
							zipOut.closeEntry();
						} catch (IOException e) {
							logger.log(Level.SEVERE, "Error in compressFolder method ",e);
						}
					});
		}
	}

}
