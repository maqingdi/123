import java.io.*;
import java.io.File;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.logging.Level;
import com.matrixone.apps.domain.DomainConstants;
import com.matrixone.apps.domain.DomainObject;
import com.matrixone.apps.framework.ui.UIUtil;
import matrix.db.*;
import matrix.util.DateFormatUtil;
import matrix.util.StringList;
import java.util.logging.FileHandler;
import java.util.logging.Formatter;
import java.util.logging.LogRecord;
import java.util.logging.Logger;

public class NK_QDISOUT_mxJPO {
    private static Logger logger = Logger.getLogger(NK_QDISOUT_mxJPO.class.getName());
    private static FileHandler handler = null;
    private static String fileName = null;
    private static String NDES_Config = "NDES_Config.properties";
    private static String ERROR_OUTPUT_PROCESSING_FAILED = "Output processing failed. Please check the error message.";
    /**
     * author DSGS
     *
     */
    public static void NK_QDISOUTExportCSV(Context context, String[] args) throws Exception {
        String outputDir = readPageObject(context, NDES_Config, "OUTPUT_DIR");
        String outputChangehistoryFile = readPageObject(context, NDES_Config, "OUTPUT_CHANGEHISTORY_FILE");
        String targetChangehistoryDate = readPageObject(context, NDES_Config, "TARGET_CHANGEHISTORY_DATE");
        String logDir = readPageObject(context, NDES_Config, "LOG_DIR");
        String loggerLevel = readPageObject(context, NDES_Config, "LOGGER.LEVEL");
        String complete = readPageObject(context, NDES_Config, "Complete");
        initiateLogger(logDir, loggerLevel);
        validateDirectory(outputDir);
        Path lockFilePath = Paths.get(outputDir, "process.lock");
        try {
            if (Files.exists(lockFilePath)) {
                log(Level.WARNING, " Program is already running.(QD_E00001)");
                log(Level.WARNING, ERROR_OUTPUT_PROCESSING_FAILED);
                System.exit(1);
            }
            createLockFile(lockFilePath);
            log(Level.INFO, ": Processing has started.(QD_I00001)");
            argumentError(args,lockFilePath);
            if (args.length == 2) {
                validateFileArgument(args[0], lockFilePath, outputDir, targetChangehistoryDate, outputChangehistoryFile, complete);
            } else if (args.length > 2) {
                handleTooManyArguments(lockFilePath);
            }
            appendToCSV(args, context, outputDir, outputChangehistoryFile, lockFilePath);
        } catch (IOException e) {
            System.out.println("Try main failed");
            e.printStackTrace();
        } finally {
            try {
                cleanUp(lockFilePath);
            } catch (IOException e) {
                System.out.println("Failed to delete lock file.");
            }
        }
    }
    /**
     * @param dir holds the output directory path
     */
    private static void validateDirectory(String dir) {
        File file = new File(dir);
        if (file.exists() && file.isDirectory()) {
            log(Level.INFO, "outputDir " + dir);
        } else {
            log(Level.WARNING, "Not found the destination folder path.(QD_E00004)");
            System.exit(0);
        }
    }
    /**
     * validateFileArgument
     * @param filePath
     * @param lockFilePath
     * @param outputDir
     * @param targetChangehistoryDate
     * @param outputChangehistoryFile
     * @param complete
     * @throws IOException
     */
    private static void validateFileArgument(String filePath, Path lockFilePath, String outputDir, String targetChangehistoryDate,
                                             String outputChangehistoryFile, String complete) throws IOException {
        if (isValidFilePath(filePath)) {
            fileName = filePath;
            if (fileName.endsWith(".properties")) {
                loadAndValidateConfigFile(outputDir, targetChangehistoryDate, outputChangehistoryFile, complete , lockFilePath);
            } else {
                handleInvalidConfigFile(lockFilePath);
            }
        } else {
            logInvalidPropertiesFile(lockFilePath);
        }
    }
    /**
     * isValidFilePath
     * @param filePath
     * @return
     */
    private static boolean isValidFilePath(String filePath) {
        return filePath != null && !filePath.isEmpty() && Files.exists(Paths.get(filePath));
    }
    /**
     * handleTooManyArguments
     */
    private static void handleTooManyArguments(Path lockFilePath) throws IOException {
        log(Level.INFO, "Too many arguments");
        cleanUp(lockFilePath);
        System.exit(0);
    }
    /**
     * Invalid Properties File
     */
    private static void logInvalidPropertiesFile(Path lockFilePath) throws IOException {
        log(Level.INFO, "Invalid properties file");
        Files.deleteIfExists(lockFilePath);
        System.exit(0);
    }
    /**
     * handleInvalidConfigFile
     * @param lockFilePath
     * @throws IOException
     */
    private static void handleInvalidConfigFile(Path lockFilePath) throws IOException {
        log(Level.INFO, "Could not read NK_ExportCA.conf (QD_E00003)");
        Files.deleteIfExists(lockFilePath);
        System.exit(0);
    }
    /**
     * argumentError
     * @param args
     * @param lockFilePath
     * @throws IOException
     */
    private static void argumentError(String[] args,Path lockFilePath) throws IOException {
        if (args.length == 0 || args.length == 1) {
            log(Level.INFO, "Not enough arguments(QD_E00002)");
            cleanUp(lockFilePath);
            System.exit(0);
        }
    }
    /**
     * createLockFile
     * @param lockFilePath
     */
    private static void createLockFile(Path lockFilePath) {
        try {
            Files.createFile(lockFilePath);
        } catch (IOException e) {
            System.out.println("Failed to create lock file. Exiting...");
            System.exit(1);
        }
    }
    /**
     * loadAndValidateConfigFile
     * @param outputDir
     * @param targetChangehistoryDate
     * @param outputChangehistoryFile
     * @param complete
     * @throws IOException
     */
    private static void loadAndValidateConfigFile(String outputDir, String targetChangehistoryDate, String outputChangehistoryFile, String complete , Path lockFilePath) throws IOException {
        if (UIUtil.isNotNullAndNotEmpty(outputDir)) {
            if (UIUtil.isNullOrEmpty(targetChangehistoryDate) || targetChangehistoryDate.matches(".*\\D.*")) {
                log(Level.INFO, " Set a number for the targetChangehistoryDate.(QD_E00005)");
                Files.deleteIfExists(lockFilePath);
                System.exit(0);
            }
            if (UIUtil.isNotNullAndNotEmpty(outputChangehistoryFile)) {
            } else {
                log(Level.INFO, "outputChangehistoryFile value is not valid");
                Files.deleteIfExists(lockFilePath);
                System.exit(0);
            }
            if (UIUtil.isNotNullAndNotEmpty(complete)) {
            } else {
                log(Level.INFO, "complete value is not valid");
                Files.deleteIfExists(lockFilePath);
                System.exit(0);
            }
        }
    }
    /**
     * Read Property File Values.
     * @param context
     * @param strPageName
     * @param strKeyName
     */
    public static String readPageObject(Context context, String strPageName, String strKeyName) {
        Properties propNotification = new Properties();
        String strProperty = DomainConstants.EMPTY_STRING;
        try {
            Page pageAttributePopulation = new Page(strPageName);
            pageAttributePopulation.open(context);
            String strProperties = pageAttributePopulation.getContents(context);
            pageAttributePopulation.close(context);
            InputStream input = new ByteArrayInputStream(strProperties.getBytes("UTF8"));
            propNotification.load(input);
            if (propNotification.containsKey(strKeyName)) {
                strProperty = propNotification.getProperty(strKeyName);
            } else {
                log(Level.INFO, strKeyName + " IS NOT PRESENT");
                System.exit(0);
            }
        } catch (Exception e) {
            System.out.println("readPageObject failed");
            e.printStackTrace();
        }
        return strProperty;
    }
    /**
     * log
     * @param level
     * @param args
     */
    private static void log(Level level, String... args) {
        logger.log(level, getLogString(args));
    }
    /**
     * getLogString
     * @param args
     * @return
     */
    private static String getLogString(String... args) {
        StringBuilder sbMessage = new StringBuilder();
        sbMessage.append(new Date());
        sbMessage.append(",");
        for (String msg : args) {
            sbMessage.append(msg);
        }
        return sbMessage.toString();
    }
    /**
     * initiateLogger
     * @param LOG_DIR
     * @param LoggerLevel
     * @throws IOException
     */
    private static void initiateLogger(String LOG_DIR, String LoggerLevel) throws IOException {
        LocalDateTime now = LocalDateTime.now();
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyMMddHHmmss");
        String formattedDate = now.format(formatter);
        String path = LOG_DIR + "/Logs";
        handler = new FileHandler(path + formattedDate + ".log");
        handler.setFormatter(new HD_LoggingFormatter());
        handler.setEncoding("UTF-8");
        logger.addHandler(handler);
        String level = LoggerLevel;
        if (level == null || level.isEmpty())
            level = "INFO";
        logger.setLevel(Level.parse(level));
    }
    /**
     * HD_LoggingFormatter
     */
    private static class HD_LoggingFormatter extends Formatter {
        @Override
        public String format(LogRecord record) {
            StringBuilder sb = new StringBuilder();
            sb.append(record.getLevel()).append(',');
            sb.append(record.getMessage()).append('\n');
            return sb.toString();
        }
    }
    /**
     * Read fron input file and appendToCSV
     * @param args
     * @param context
     * @param outputDir
     * @param outputChangehistoryFile
     * @param lockFilePath
     * @throws IOException
     */
    private static void appendToCSV(String[] args, Context context, String outputDir, String outputChangehistoryFile, Path lockFilePath) throws IOException {
        NK_IntegrationConstants_mxJPO NKconstants = new NK_IntegrationConstants_mxJPO();
        StringBuilder sb = new StringBuilder();
        String filePath = args[1];
        LocalDateTime currentDate = LocalDateTime.now();
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyyMMddHHmmss");
        String formattedDate = currentDate.format(formatter);
        String outputExcelPath = outputDir;
        String outputFileName = outputChangehistoryFile;
        String tempOutputFileName = "temp" + formattedDate + ".csv";
        Path tempFilePath = Paths.get(outputExcelPath, tempOutputFileName);
        try (BufferedWriter writer = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(tempFilePath.toFile()), Charset.forName("Shift_JIS")))) {
            Path outputPath = Paths.get(outputExcelPath);
            Files.createDirectories(outputPath);
            Query q = new Query();
            String combinedWhereClause = getCombinedWhereClause(context);
            outputFileName = outputFileName + formattedDate + ".csv";
            StringList slAttributes = new StringList();
            int outputNumber = 0;
            try (BufferedReader br = new BufferedReader(new FileReader(filePath))) {
                processFixLine(sb, br, slAttributes);
                StringList objectSelects = new StringList();
                objectSelects.add(DomainConstants.SELECT_ID);
                String sType = "Change Action";
                q.open(context);
                q.setBusinessObjectType(sType);
                q.setBusinessObjectName("*");
                q.setBusinessObjectRevision("*");
                q.setWhereExpression(combinedWhereClause);
                q.setObjectLimit((short) 0);
                q.setExpandType(true);
                context.start(false);
                QueryIterator itr = q.getIterator(context, objectSelects, (short) 0, new StringList());
                q.close(context);
                handleNullIterator(itr, writer, tempFilePath, lockFilePath);
                sb.append("\r\n");  // Ensures CRLF line endings
                boolean flag;
                while (itr.hasNext()) {
                    flag = false;
                    BusinessObjectWithSelect bws = itr.next();
                    String strObjID = bws.getSelectData("id");
                    DomainObject doID = DomainObject.newInstance(context, strObjID);
                    Map attributeMap = doID.getAttributeMap(context);
                    StringList selectList = new StringList();
                    selectList.add("modified");
                    selectList.add("originated");
                    Map objectMap = doID.getInfo(context, selectList);
                    attributeMap.putAll(objectMap);
                    for (String sAttributes : slAttributes) {
                        if (attributeMap.containsKey(sAttributes)) {
                            flag = true;
                            String sValue = (String) attributeMap.get(sAttributes);
                            sValue = replaceSpecialCharacters(sValue);
                            sb.append("\"").append(sValue).append("\"").append(",");  // Enclosed in quotes and comma-separated
                        } else {
                            log(Level.INFO, "Not found the value described in " + filePath + ". Attribute name that cannot be read: " + sAttributes + " (EC_E00007)");
                            writer.close();
                            Files.delete(tempFilePath);
                            cleanUp(lockFilePath);
                            System.exit(0);
                        }
                    }
                    if (flag) {
                        sb.setLength(sb.length() - 1);  // Remove trailing comma
                        sb.append("\r\n");  // CRLF line endings
                        outputNumber++;
                    }
                }
            } catch (IOException e) {
                log(Level.INFO, "Could not read attributes definition file.");
                log(Level.WARNING, ERROR_OUTPUT_PROCESSING_FAILED);
                writer.close();
                Files.deleteIfExists(lockFilePath);
                Files.delete(tempFilePath);
                System.exit(0);
            }
            writer.append(sb.toString());
            writer.close();
            // Move temp file to final file
            Path finalFilePath = Paths.get(outputExcelPath, outputFileName);
            Files.move(tempFilePath, finalFilePath, StandardCopyOption.REPLACE_EXISTING);
            log(Level.INFO, "Output processing completed. File name: " + finalFilePath + ", OutputNumber: " + outputNumber + ". Name: " + outputChangehistoryFile + ". (QD_I00003)");
        } catch (Exception e) {
            log(Level.WARNING, ERROR_OUTPUT_PROCESSING_FAILED);
            log(Level.WARNING, "Failed to output the item information.");
            e.printStackTrace();
            Files.delete(tempFilePath);
            cleanUp(lockFilePath);
            System.exit(0);
        }
    }
    /**
     * handleNullIterator
     * @param itr
     * @param writer
     * @param tempFilePath
     * @param lockFilePath
     * @throws IOException
     */
    private static void handleNullIterator(QueryIterator itr, BufferedWriter writer, Path tempFilePath, Path lockFilePath) throws IOException {
        if (itr == null || !itr.hasNext()) {
            log(Level.INFO, "Not found the target item.(QD_I00002)");
            writer.close();
            Files.delete(tempFilePath);
            cleanUp(lockFilePath);
            System.exit(0);
        }
    }
    /**
     * changeHistoryAttribute
     * @param NKconstants
     * @param sb
     * @param sAttributes
     * @param sValue
     */
    private static void changeHistoryAttribute(NK_IntegrationConstants_mxJPO NKconstants, StringBuilder sb, String sAttributes, String sValue) {
        if (UIUtil.isNotNullAndNotEmpty(sValue)) {
            if (NKconstants.Originated.equalsIgnoreCase(sAttributes)) {
                sb.append(sValue + ",");
            } else if (NKconstants.Modified.equalsIgnoreCase(sAttributes)) {
                sb.append(sValue + ",");
            } else if (NKconstants.Synopsis.equalsIgnoreCase(sAttributes)) {
                sb.append(sValue + ",");
            } else if (NKconstants.NK_APPLY_DATE.equalsIgnoreCase(sAttributes)) {
                sb.append(sValue + ",");
            } else if (NKconstants.NK_OUTLINE.equalsIgnoreCase(sAttributes)) {
                sb.append(sValue + ",");
            } else if (NKconstants.NK_EXPLANATION.equalsIgnoreCase(sAttributes)) {
                sb.append(sValue + ",");
            } else if (NKconstants.NK_REASON_CHANGE.equalsIgnoreCase(sAttributes)) {
                sb.append(sValue + ",");
            }
        }else {
            sb.append(",");
        }
    }
    /**
     * cleanUp
     * @param lockFilePath
     * @throws IOException
     */
    private static void cleanUp(Path lockFilePath) throws IOException {
        Files.deleteIfExists(lockFilePath);
        if (handler != null) {
            handler.close();
        }
    }
    /**
     * print present in FIX[]
     * @param sb
     * @param br
     * @param slAttributes
     * @throws IOException
     */
    private static void processFixLine(StringBuilder sb,BufferedReader br ,StringList slAttributes ) throws IOException {
        String line;
        while ((line = br.readLine()) != null) {
            if (line.trim().startsWith("FIX[")) {
                String fixInput = line.trim();
                String fixedLine = fixInput.substring(fixInput.indexOf("[") + 1, fixInput.lastIndexOf("]")).replace("\"", "");
                sb.append(fixedLine).append("\n");
            } else {
                slAttributes.add(line);
                sb.append(line);
                sb.append(",");
            }
        }
    }
    /**
     * replaceSpecialCharacters
     * @param input
     * @return
     */
    public static String replaceSpecialCharacters(String input) {
        return input.replace("\"", " ");
    }
    /**
     * Combined where clause for all the condition.
     * @param context
     * @return
     * @throws Exception
     */
    private static String getCombinedWhereClause(Context context) throws Exception {
        SimpleDateFormat df = DateFormatUtil.initDateFormat(context, Locale.US);
        Date today = new Date();
        Calendar cal = Calendar.getInstance();
        cal.setTime(today);
        String targetChangehistoryDate = readPageObject(context, NDES_Config, "TARGET_CHANGEHISTORY_DATE");
        int targetChangeHistory = 0;
        String where = null;
        if (targetChangehistoryDate != null && !targetChangehistoryDate.isEmpty()) {
            try {
                targetChangeHistory = Integer.parseInt(targetChangehistoryDate);
            } catch (NumberFormatException e) {
                log(Level.INFO, "TargetChangeHistory entered is not a valid integer");
                System.exit(0);
            }
        }
        if (targetChangeHistory > 0) {
            cal.setTime(today);
            cal.add(Calendar.DATE, -targetChangeHistory);
            String targetWhereClause = "'modified' > '" + df.format(cal.getTime()) + "'";
            if (UIUtil.isNotNullAndNotEmpty(where)) {
                where += " && " + targetWhereClause;
            } else {
                where = targetWhereClause;
            }
        }
        String stateFlgComplete = readPageObject(context, NDES_Config, "Complete");
        StringBuilder whereClauseFlag = new StringBuilder();
        if ("1".equals(stateFlgComplete)) {
            if (where != null && !where.isEmpty()) {
                whereClauseFlag.append(where).append(" && ");
            }
            whereClauseFlag.append("'current' == 'Complete'");
        } else {
            whereClauseFlag.append(where);
        }
        whereClauseFlag.append(" && ");
        whereClauseFlag.append("attribute[Synopsis].value != ''");
        whereClauseFlag.append(" && ");
        whereClauseFlag.append("attribute[NK_REASON_CHANGE].value ~= '0864-*'");
        return whereClauseFlag.toString();
    }
}