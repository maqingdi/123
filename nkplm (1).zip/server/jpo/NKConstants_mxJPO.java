import com.matrixone.apps.domain.util.PropertyUtil;

public class NKConstants_mxJPO {
	
	/**
	   * Common Constants
	   *
	   * This section defines common constant values used in the Nihon Kohden Project.
	   * These constants represent various attributes and properties used in the module.
	   *
	   */
	  public static final String ATTR_BOSS_TYPE = "attribute[NK_EXT_MBOM_BASE.NK_TYPE_BOSS_ITEM]";
	  public static final String PROP_TARGET = "MBOM_REQUIRED_ATTRIBTE_TARGET";
	  public static final String CHECK1  = "MBOM_FROZEN_CHECK_1";
	  public static final String CHECK2 = "MBOM_FROZEN_CHECK_2";
	  public static final String CHECK4 = "MBOM_FROZEN_CHECK_4";
	  public static final String CHECK5 = "MBOM_FROZEN_CHECK_5";
	  public static final String CHECK6 = "MBOM_FROZEN_CHECK_6";
	  public static final String CHECK7 = "MBOM_FROZEN_CHECK_7";
	  public static final String PAGE_FILE = "NK_ApprovalRequest";
	  public static final String PROP_FILE = "dmcplanningStringResource";
	  public static final String MBOM_TYPES = "CreateAssembly,Provide";
	  public static final String ITEM_TYPE = "NK_EXT_MBOM_BASE.NK_PARTS_TYPE";
	  public static final String PRODUCT_NAME = "Product Name";
	  public static final String PRODUCT_CALSIFICATION = "NK_EXT_MBOM_PRODUCT.NK_PRODUCT_CLASSIFICATION";
	  public static final String RATING_CLASSIFICATION = "NK_EXT_MBOM_PARTS.NK_RATING_CLASSIFICATION";
	  public static final String SPECIFIC_PART = "Specific parts";
	  public static final String MARKET_PART = "Market parts";
	  public static final String DOCUMENT = "Document";
	  public static final String ROHS = "NK_EXT_MBOM_BASE.NK_CONTAINED_MATERIAL_CLASSIFICATION_10";
	  public static final String UNIT = "NK_EXT_MBOM_PLANT_COMMON.NK_UNIT_BASIC_QUANTITY_SALES_ORDER";
	  public static final String BOSS_FLAG = "NK_EXT_MBOM_EXT_BOSS.NK_FLAG_BOSS";
	  public static final String BASIC_NUMBER = "NK_EXT_MBOM_REL_BASE.NK_NUMERATOR";
	  public static final String BOSS_ITEM_TYPE = "NK_EXT_MBOM_BASE.NK_TYPE_BOSS_ITEM";
	  public static final String GATHERING_CLASS = "NK_EXT_MBOM_REL_BASE.NK_CLASS_MATERIAL";
	  public static final String SERVICE_PART = "Service Parts";
	  public static final String KIT_ASSY = "NK_EXT_MBOM_MAINTENANCE.NK_KIT_ASSY_CATEGORY";
	  public static final String BOM_LIFECYCLE = "NK_EXT_MBOM_BASE.NK_BOMLIFECYCLE";
	  public static final String SUBMIT_DIVISION = "NK_EXT_MBOM_BOSS.NK_BOSS_SUBMIT_DIVISION";
	  public static final String VERSION = "NK_EXT_MBOM_BASE.NK_VERSION";
	  public static final String REVISION = "NK_EXT_MBOM_BASE.NK_REVISION";
	  public static final String START_DATE = "NK_EXT_MBOM_REVISION_SYSTEM.NK_EFFECTIVE_START_DATE_TIME";
	  public static final String EFFECT_PROP_FILE = "NK_BO_validDateRevert";
	  public static final String TYPE_CHANGE_ACTION = PropertyUtil.getSchemaProperty("type_ChangeAction");
	  
	
private NKConstants_mxJPO() {
  throw new IllegalStateException("Constants class");
		  }


}
