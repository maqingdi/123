import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.FileInputStream;
import java.io.InputStreamReader;
import java.io.InputStream;
import java.io.OutputStreamWriter;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.charset.StandardCharsets;
import java.nio.file.StandardCopyOption;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Arrays;
import java.util.Date;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Map;
import java.util.Properties;
import java.util.Set;
import java.util.logging.Level;
import java.util.logging.FileHandler;
import java.util.logging.Formatter;
import java.util.logging.LogRecord;
import java.util.logging.Logger;
import com.matrixone.apps.domain.DomainConstants;
import com.matrixone.apps.domain.DomainObject;
import com.matrixone.apps.domain.util.MapList;
import com.matrixone.apps.framework.ui.UIUtil;
import matrix.db.Context;
import matrix.db.Page;
import matrix.util.StringList;

/**
 * @author DSGS
 *
 */
/**
 * @author DSGS
 *
 */
public class NK_ECADResult_mxJPO
{
	private static Logger logger = Logger.getLogger(NK_ECADResult_mxJPO.class.getName());
	private static FileHandler handler = null;
	private static int outputNumber = 0;
	private static String valueOfLargeClass = "resistors";
	/**
	 * @author DSGS
	 * @param  context the 3dx<code>Context</code>object.
	 * @param  args contains the first argument is File path of the property file and second argument is File path of the output item definition (electrical component) file .
	 * @throws Exception
	 */
	public static void NK_ECADtoCSVExport(Context context, String[] args) throws Exception {

		String outputDir = readPageObject(context, "NK_Config.properties", "OUTPUT_DIR");
		String outputPhysicalProductFile = readPageObject(context, "NK_Config.properties", "OUTPUT_PHYSICALPRODUCT_FILE");
		String logDir = readPageObject(context, "NK_Config.properties", "LOG_DIR");
		String loggerLevel = readPageObject(context, "NK_Config.properties", "Logger.Level");
		String itemNumbers = readPageObject(context, "NK_Config.properties", "Enterprise_Item_Number");
		String ratingClassificationRange = readPageObject(context, "NK_Config.properties", "RangeOfratingClassification");
		initiateLogger(logDir, loggerLevel);
		validateDirectory(outputDir);
		Path lockFilePath = Paths.get(outputDir, "process.lock");
		try {
			if (Files.exists(lockFilePath)) {
				log(Level.WARNING, " Program is already running. (EC_E00001)");
				log(Level.WARNING, "Output processing failed. Please check the error message.");	           
				System.exit(1);
			}
			createLockFile(lockFilePath);
			log(Level.INFO, "Processing has started.(EC_I00001)");

			if (args.length != 2) {
				handleArgumentError(lockFilePath);
			}
			if (args[0] == null || args[0].isEmpty() || !args[0].endsWith(".properties")) {
				handlePropertyFileError(lockFilePath);
			}	
			checkAttribute(context, args, outputDir , outputPhysicalProductFile , lockFilePath );		
		} catch (IOException e) {
			e.printStackTrace();
		} finally {			
			try {
				cleanUp(lockFilePath);
			} catch (IOException e) {
				System.out.println("Failed to delete lock file.");
			}
		}
	}

	/**
	 * @param dir holds the output directory path 
	 */
	private static void validateDirectory(String dir) {
		File file = new File(dir);
		if (file.exists() && file.isDirectory()) {
			log(Level.INFO, "outputDir " + dir);
		} else {
			log(Level.WARNING, "Not found the destination folder path .(EC_E00004)");
			System.exit(0);
		}
	}
	/**
	 * @param lockFilePath to check multiple instance running and delete 
	 * @throws IOException
	 */
	private static void createLockFile(Path lockFilePath) throws IOException {
		try {
			Files.createFile(lockFilePath);
		} catch (IOException e) {
			System.out.println("Failed to create lock file. Exiting...");
			System.exit(1);
		}
	}
	/**
	 * prints the Argument Error 
	 * @param lockFilePathto check multiple instance running and delete 
	 * @throws IOException
	 */
	private static void handleArgumentError(Path lockFilePath) throws IOException {
		log(Level.WARNING, "Not enough arguments.(EC_E00002)");
		cleanUp(lockFilePath);
		System.exit(0);
	}

	/**
	 * check the Property File Error
	 * @param lockFilePath to check multiple instance running and delete 
	 * @throws IOException
	 */
	private static void handlePropertyFileError(Path lockFilePath) throws IOException {
		log(Level.WARNING, "Could not read NK_ExportCA.conf.(EC_E00003)");
		cleanUp(lockFilePath);
		System.exit(0);
	}
	/**
	 * @param lockFilePath to check multiple instance running and delete 
	 * @throws IOException
	 */
	private static void cleanUp(Path lockFilePath) throws IOException {
		Files.deleteIfExists(lockFilePath);
		if (handler != null) {
			handler.close();
		}
	}
	/**
	 * 
	 * @param context 
	 * @param args to get the path of the output item definition
	 * @param outputDir to get the Folder path to output file (csv) of electrical component information
	 * @param outputPhysicalProductFile - Name of the output file (csv) of electrical component information
	 * @throws Exception
	 */
	public static void checkAttribute( Context context, String args[], String outputDir, String outputPhysicalProductFile ,Path lockFilePath) throws Exception
	{
		NK_IntegrationConstants_mxJPO NKconstants = new NK_IntegrationConstants_mxJPO();
		String filePath = args[1]; 		
		String tempFileName = generateTempFileName();
		Path tempFilePath = Paths.get(outputDir, tempFileName);	
		StringBuilder sb = new StringBuilder();
		try {
			Path outputPath = Paths.get(outputDir);
			Files.createDirectories(outputPath);
			BufferedWriter writer = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(tempFilePath.toFile()), StandardCharsets.UTF_8));
			StringList slAttributes = new StringList();
			try (BufferedReader br = new BufferedReader(new InputStreamReader(new FileInputStream(filePath), "UTF-8"))) {
				String line;
				boolean isFirstLine = true; 
				while ((line = br.readLine()) != null) {
					if (line.startsWith("FIX[")) {						
						processFixLine(sb, line, isFirstLine);
						isFirstLine = false;					
					} else {						
						slAttributes.add(line);
					}
				}
				StringList objectSelects = new StringList();
				objectSelects.add(DomainConstants.SELECT_ID);
				objectSelects.add("attribute[PLMEntity.V_Name]");
				
				String whereCondition = buildWhereCondition(context);
				StringList orderBys = new StringList();
				orderBys.add("-revision");	
				MapList	mlResults = DomainObject.findObjects(context,NKconstants.NK_ECAD_TYPE, null, whereCondition.toString(),
						objectSelects,(short)0, orderBys);				
				mlResults.sort("attribute[PLMEntity.V_Name]","ascending","String");				
				outputNumber = mlResults.size();			
				Iterator<?> itr = mlResults.iterator();
				if(!itr.hasNext()) { 
					log( Level.WARNING,"Not found the target item.(EC_E00006)"); 
					log(Level.WARNING,"Output processing failed . Please check the error message." );
					writer.close(); 
					Files.delete(tempFilePath);
					cleanUp(lockFilePath);
					System.exit(0);
				}
				writeAttributesToFile(sb, slAttributes, mlResults , context , writer , filePath , tempFilePath , lockFilePath );			
			} catch (IOException e) {
				log( Level.WARNING, "Could not read NK_ItemColumns.txt. (EC_E00005)");
				log( Level.WARNING,"Output processing failed . Please check the error message."  );
				writer.close(); 
				Files.delete(tempFilePath);
				cleanUp(lockFilePath);
				System.exit(0);	
			}
			writer.append(sb.toString());
			writer.close();
			moveTempFile(outputDir, outputPhysicalProductFile, tempFilePath , lockFilePath);

		} catch (IOException e) {
			e.printStackTrace();
		} 
		finally {			
			try {
				cleanUp(lockFilePath);
				Files.delete(tempFilePath);
			} catch (IOException e) {			
			}
		}
	}
	/**
	 * @param sb
	 * @param sValue The vale of the attribute 
	 * @param attributeKey holds the unit of the attribute 
	 * @param attributeMap to check the attribute in the attribute map
	 */
	private static void appendValue(StringBuilder sb, String sValue, String attributeKey, Map<?, ?> attributeMap) {
		String attributeValue = (String) attributeMap.get(attributeKey);
		attributeValue = replaceSpecialCharacters(attributeValue);
		if (UIUtil.isNotNullAndNotEmpty(attributeValue)) {
			sb.append(sValue + attributeValue + ",");
		} else {
			sb.append(sValue + ",");
		}
	}	
	private static void writeAttributesToFile(StringBuilder sb, StringList slAttributes, MapList mlResults , Context context, BufferedWriter writer, String filePath, Path tempFilePath, Path lockFilePath) throws Exception {
		Iterator<?> itr = mlResults.iterator();
		while (itr.hasNext()) {
			sb.append("\n");
			Map<?, ?> objectMap = (Map<?, ?>) itr.next();
			String strObjId = (String) objectMap.get("id");
			DomainObject domObj = DomainObject.newInstance(context,strObjId);	
			Map<?, ?> attributeMap = domObj.getAttributeMap(context);
			for(String sAttrName : slAttributes) {
				if(attributeMap.containsKey(sAttrName)) {
					processAttribute(sb, sAttrName, attributeMap);						
				}else {
					log( Level.WARNING, "Not found the value described in: "+filePath +" Attribute name that cannot be read : "+sAttrName +"(EC_E00007)");
					log( Level.WARNING,"Output processing failed . Please check the error message."  );
					writer.close();
					Files.delete(tempFilePath);
					cleanUp(lockFilePath);
					System.exit(0);	
				}
			}
		}
	}

	/**
	 * To check all the attribute conditions 
	 * @param sb builder to append the data 
	 * @param sAttrName The attribute name from item definition file 
	 * @param attributeMap holds the attribute map of the object 
	 */
	private static void processAttribute(StringBuilder sb, String sAttrName, Map<?, ?> attributeMap) {
		NK_IntegrationConstants_mxJPO NKconstants = new NK_IntegrationConstants_mxJPO();
		String sValue = (String)attributeMap.get(sAttrName);						
		sValue = replaceSpecialCharacters(sValue);	
		String sNK_PARTS_NO = (String)attributeMap.get(NKconstants.NK_PARTS_NO);
		sNK_PARTS_NO = replaceSpecialCharacters(sNK_PARTS_NO);
		if (NKconstants.NK_PLMENTITY_V_NAME.equalsIgnoreCase(sAttrName)) {								
			if(UIUtil.isNotNullAndNotEmpty(sNK_PARTS_NO)) {								
				String modifiedValue = sNK_PARTS_NO.replaceAll("-(.*)","");								
				sb.append(modifiedValue + ",");		
			}else {
				sb.append(","); 
			}						
		}else if(NKconstants.NK_USER_REVISION.equalsIgnoreCase(sAttrName)){
			String sNK_USER_REVISION =  (String)attributeMap.get(NKconstants.NK_USER_REVISION);
			sNK_USER_REVISION =  replaceSpecialCharacters(sNK_USER_REVISION);
			String modifiedValue = " ";
			if(UIUtil.isNotNullAndNotEmpty(sNK_PARTS_NO)) {
				modifiedValue = sNK_PARTS_NO.replaceAll("^[^-]*-","");							
				sb.append(modifiedValue+"-"+sNK_USER_REVISION+",");	
			}else{
				sb.append(modifiedValue+"-"+sNK_USER_REVISION+",");	
			}		 								
		}else if(NKconstants.NK_PARTS_NAME.equalsIgnoreCase(sAttrName) || NKconstants.NK_MANUFACTURER.equalsIgnoreCase(sAttrName) ) {
			StringBuilder result = new StringBuilder();
			for (char c : sValue.toCharArray()) {
				if (c >= 0xFF61 && c <= 0xFF9F) { 						                    
					result.append((char) (c + 0x60));
				} else {					                    
					result.append(c);
				}
			}					         				         
			sb.append(result.toString()).append(",");		
		}else if(NKconstants.NK_UNIT_PRICE1.equalsIgnoreCase(sAttrName) || NKconstants.NK_UNIT_PRICE2.equalsIgnoreCase(sAttrName)
				||NKconstants.NK_UNIT_PRICE3.equalsIgnoreCase(sAttrName)){							
			appendValueWithUnit(sb, sValue, "yen");
		}else if(NKconstants.NK_ELEC_HE_NUMBER.equalsIgnoreCase(sAttrName) || NKconstants.NK_ELEC_POLES_PITCH.equalsIgnoreCase(sAttrName) ) {							
			appendValueWithUnit(sb, sValue, "mm");
		}else if(NKconstants.NK_ELEC_POWER_RATING.equalsIgnoreCase(sAttrName)){								
			appendValueWithUnit(sb, sValue, "w");
		}else if(NKconstants.NK_ELEC_VOLATEG_PROOF.equalsIgnoreCase(sAttrName) || NKconstants.NK_ELEC_POWER_VOLTAGE.equalsIgnoreCase(sAttrName) ||
				NKconstants.NK_ELEC_OUTPUT_VOLTAGE.equalsIgnoreCase(sAttrName) || NKconstants.NK_ELEC_MAXIMUM_VOLTAGE.equalsIgnoreCase(sAttrName)
				|| NKconstants.NK_ELEC_REFERENCE_VOLTAGE.equalsIgnoreCase(sAttrName)|| NKconstants.NK_ELEC_ZENER_VOLTAGE.equalsIgnoreCase(sAttrName) 
				|| NKconstants.NK_ELEC_VF_VOLTAGE.equalsIgnoreCase(sAttrName)){						
			appendValueWithUnit(sb, sValue, "V");
		}else if(NKconstants.NK_ELEC_F_TEMPERATURE_CRYSTAL.equalsIgnoreCase(sAttrName)){								
			appendValueWithUnit(sb, sValue, "ppm");
		}else if(NKconstants.NK_ELEC_F_TEMPERATURE_CERAMIC.equalsIgnoreCase(sAttrName)){															
			appendValueWithUnit(sb, sValue, "%");
		}else if(NKconstants.NK_ELEC_NOISE_VOLTAGE_DENSITY.equalsIgnoreCase(sAttrName)){								
			appendValueWithUnit(sb, sValue, "nV/√Hz");
		}else if(NKconstants.NK_ELEC_BUS_WIDTH.equalsIgnoreCase(sAttrName)){																
			appendValueWithUnit(sb, sValue, "bit");
		}else if(NKconstants.NK_ELEC_ACCESSTIME.equalsIgnoreCase(sAttrName)){															
			appendValueWithUnit(sb, sValue, "ns");
		}else if(NKconstants.NK_ELEC_RATED_VALUE.equalsIgnoreCase(sAttrName)){ 
			String sNK_ELEC_UNIT_OF_RATED_VALUE =  (String)attributeMap.get(NKconstants.NK_ELEC_UNIT_OF_RATED_VALUE);
			sNK_ELEC_UNIT_OF_RATED_VALUE = replaceSpecialCharacters(sNK_ELEC_UNIT_OF_RATED_VALUE);
			String sNK_ELEC_LARGENESS_CLASS =  (String)attributeMap.get(NKconstants.NK_ELEC_LARGENESS_CLASS);	
			sNK_ELEC_LARGENESS_CLASS = replaceSpecialCharacters(sNK_ELEC_LARGENESS_CLASS);
			if (valueOfLargeClass.equalsIgnoreCase(sNK_ELEC_LARGENESS_CLASS)) {							        
				if (sNK_ELEC_UNIT_OF_RATED_VALUE != null && !sNK_ELEC_UNIT_OF_RATED_VALUE.isEmpty()) {
					char firstChar = sNK_ELEC_UNIT_OF_RATED_VALUE.trim().charAt(0);
					if (Character.isDigit(firstChar)) {
						sb.append(firstChar);
					}
				}
			}else if (sNK_ELEC_UNIT_OF_RATED_VALUE != null) {																
				String trimmedUnitValue = sNK_ELEC_UNIT_OF_RATED_VALUE.trim();
				if (trimmedUnitValue.startsWith("-")) {
					trimmedUnitValue = trimmedUnitValue.substring(1).trim();
				}
				sb.append(trimmedUnitValue);								
			}	
			sb.append(",");
		}else if (NKconstants.NK_ELEC_UNIT_OF_RATED_ACTUAL.equalsIgnoreCase(sAttrName)) { 
			String sNK_ELEC_UNIT_OF_RATED_ACTUAL =  (String)attributeMap.get(NKconstants.NK_ELEC_UNIT_OF_RATED_ACTUAL);
			sNK_ELEC_UNIT_OF_RATED_ACTUAL =  replaceSpecialCharacters(sNK_ELEC_UNIT_OF_RATED_ACTUAL);
			String sNK_ELEC_LARGENESS_CLASS =  (String)attributeMap.get(NKconstants.NK_ELEC_LARGENESS_CLASS);
			sNK_ELEC_LARGENESS_CLASS =  replaceSpecialCharacters(sNK_ELEC_LARGENESS_CLASS);
			if (valueOfLargeClass.equalsIgnoreCase(sNK_ELEC_LARGENESS_CLASS)) {								
				sb.append(sNK_ELEC_UNIT_OF_RATED_ACTUAL);
			}
			sb.append(","); 
		}else if (NKconstants.NK_ELEC_RATINGS_CURRENT_VALUE.equalsIgnoreCase(sAttrName)) { 								
			appendValue(sb,sValue,NKconstants.NK_ELEC_UNIT_RATINGS_CURRENT, attributeMap) ;
		}else if (NKconstants.NK_ELEC_NOMINAL_FREQUENCY_VALUE.equalsIgnoreCase(sAttrName)) {							
			appendValue(sb,sValue,NKconstants.NK_ELEC_UNIT_OF_NOMINAL_FREQUENCY, attributeMap) ;
		}else if (NKconstants.NK_ELEC_CLOCK_FREQUENCY_VALUE.equalsIgnoreCase(sAttrName)) { 								
			appendValue(sb,sValue,NKconstants.NK_ELEC_UNIT_OF_CLOCK_FREQUENCY, attributeMap) ;
		}else if (NKconstants.NK_ELEC_CIRCUIT_CURRENT_VALUE.equalsIgnoreCase(sAttrName)) { 							
			appendValue(sb,sValue,NKconstants.NK_ELEC_UNIT_OF_CIRCUIT_CURRENT, attributeMap) ;
		}else if (NKconstants.NK_ELEC_INPUT_OFFSET_VOLTAGE_VALUE.equalsIgnoreCase(sAttrName)) { 
			appendValue(sb,sValue,NKconstants.NK_ELEC_UNIT_OFF_INPUT_OFFSET_VOLTAGE, attributeMap) ;				
		}else if (NKconstants.NK_ELEC_INPUT_BIAS_CURRENT_VALUE.equalsIgnoreCase(sAttrName)) {								
			appendValue(sb,sValue,NKconstants.NK_ELEC_UNIT_OF_INPUT_BIAS_CURRENT, attributeMap) ;
		}else if (NKconstants.NK_ELEC_GAIN_BANDWIDTH_PRODUCT_VALUE.equalsIgnoreCase(sAttrName)) {								
			appendValue(sb,sValue,NKconstants.NK_ELEC_UNIT_OF_GAIN_BANDW_PRODUCT, attributeMap) ;
		}else if (NKconstants.NK_ELEC_NOISE_VOLTAGE_VALUE.equalsIgnoreCase(sAttrName)) { 							
			appendValue(sb,sValue,NKconstants.NK_ELEC_UNIT_OF_NOISE_VOLTAGE, attributeMap) ;
		}else if (NKconstants.NK_ELEC_MEMORY_CAPACITY_VALUE.equalsIgnoreCase(sAttrName)) { 
			String sNK_ELEC_MEMORY_CAPACITY_VALUE_Value = (String)attributeMap.get(NKconstants.NK_ELEC_MEMORY_CAPACITY_VALUE);
			sNK_ELEC_MEMORY_CAPACITY_VALUE_Value =  replaceSpecialCharacters(sNK_ELEC_MEMORY_CAPACITY_VALUE_Value);
			String sNK_ELEC_UNIT_OF_MEMORY_CAPACITY_Value =(String)attributeMap.get(NKconstants.NK_ELEC_UNIT_OF_MEMORY_CAPACITY);
			sNK_ELEC_UNIT_OF_MEMORY_CAPACITY_Value =  replaceSpecialCharacters(sNK_ELEC_UNIT_OF_MEMORY_CAPACITY_Value);
			sb.append(sValue+sNK_ELEC_MEMORY_CAPACITY_VALUE_Value+sNK_ELEC_UNIT_OF_MEMORY_CAPACITY_Value+",");
		}else if (NKconstants.NK_ELEC_WITHSTAND_VOLTAGE_VALUE.equalsIgnoreCase(sAttrName)) { 								
			appendValue(sb,sValue,NKconstants.NK_ELEC_UNIT_OF_WITHSTAND_VOLTAGE, attributeMap) ;
		}

	}
	/**
	 * To move the content from temporary file to the outputPhysicalProductFile
	 * @param outputDir holds the directory path
	 * @param outputPhysicalProductFile Name of the file .
	 * @param tempFilePath holds the temporary file 
	 * @param lockFilePath to delete if program terminates .
	 * @throws IOException
	 */
	private static void moveTempFile(String outputDir, String outputPhysicalProductFile, Path tempFilePath , Path lockFilePath) throws IOException {
		try {
			Path finalFilePath = Paths.get(outputDir, outputPhysicalProductFile);
			Files.move(tempFilePath, finalFilePath, StandardCopyOption.REPLACE_EXISTING);
			log( Level.INFO, "CSV file '" + outputPhysicalProductFile + "' created successfully at " + outputDir);
			System.out.println("CSV file '" + outputPhysicalProductFile + "' created successfully at " + outputDir);				
			log( Level.INFO, "Output processing completed. File Name'" + outputPhysicalProductFile  + "' OutputNumber " + outputNumber +" (EC_I00002)");
			System.out.println("Output processing completed. File Name'" + outputPhysicalProductFile  + "' OutputNumber " + outputNumber +" (EC_I00002)");					
		}catch (Exception e) {
			log( Level.WARNING,"Failed to output the item information.(EC_E00008)");
			System.out.println("Failed to output the item information.(EC_E00008)");
			Files.delete(tempFilePath);
			cleanUp(lockFilePath);
			System.exit(0);	
		}
	}
	/**
	 * @param sb to append 
	 * @param sValue 
	 * @param unit holds the value of unit
	 */
	private static void appendValueWithUnit(StringBuilder sb, String sValue, String unit) {
		if (UIUtil.isNotNullAndNotEmpty(sValue)) {
			sb.append(sValue + unit + ",");
		} else {
			sb.append(",");
		}
	}
	/** 
	 * for temporary file name .
	 * @return tempyyyyMMddHHmmss format 
	 */
	private static String generateTempFileName() {
		LocalDateTime now = LocalDateTime.now();
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyyMMddHHmmss");
		return "temp" + now.format(formatter) + ".csv";
	}
	/**
	 * Read Page object from the DB 
	 *
	 * @param context
	 * @param strPageName - Name of the page file 
	 * @param strKeyName - key name present in the page file 
	 * @throws Exception
	 */
	public static String readPageObject(Context context, String strPageName, String strKeyName) throws Exception {
		Properties propNotification = new Properties();
		String strProperty = DomainConstants.EMPTY_STRING;
		try {
			Page pageAttributePopulation = new Page(strPageName);
			pageAttributePopulation.open(context);
			String strProperties = pageAttributePopulation.getContents(context);
			pageAttributePopulation.close(context);
			InputStream input = new ByteArrayInputStream(strProperties.getBytes("UTF8"));
			propNotification.load(input);
			if(propNotification.containsKey(strKeyName)) {
				strProperty = propNotification.getProperty(strKeyName);
			}else {
				log( Level.INFO, strKeyName +"IS NOT PRESENT");			
				System.exit(0);			
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return strProperty;
	}
	/**
	 * Where condition for find objects 
	 * @param context
	 * @return string
	 * @throws Exception
	 */
	private static String buildWhereCondition(Context context) throws Exception {    
		String itemNumbers = readPageObject(context, "NK_Config.properties", "Enterprise_Item_Number");
		String ratingClassificationRange = readPageObject(context, "NK_Config.properties", "RangeOfratingClassification");
		Set<String> values = new HashSet<>(Arrays.asList(itemNumbers.split(",\\s*")));
		Set<String> ratingValues = new HashSet<>(Arrays.asList(ratingClassificationRange.split(",\\s*")));
		StringBuilder whereCondition = new StringBuilder();
		whereCondition.append("Type=='VPMReference' && (")
		.append(buildCondition("attribute[EnterpriseExtension.V_PartNumber].value", values))
		.append(") && attribute[NK_EXT_EBOM_ELEC.NK_ELEC_LARGENESS_CLASS].value!='' && (")
		.append(buildCondition("attribute[NK_EXT_EBOM_PARTS.NK_RATING_CLASSIFICATION].value", ratingValues))
		.append(") && revision=='last'");

		return whereCondition.toString();
	}

	/**
	 * To compare each value 
	 * @param attributeName holds the attribute name 
	 * @param values
	 * @return
	 */
	private static String buildCondition(String attributeName, Set<String> values) {
		StringBuilder condition = new StringBuilder();
		boolean first = true;
		for (String value : values) {
			if (!first) {
				condition.append(" || ");
			}
			condition.append(attributeName).append("=='").append(value).append("'");
			first = false;
		}
		return condition.toString();
	}

	/**
	 * To print whatever the content present in FIX[] headers . 
	 * @param sb
	 * @param line
	 * @param isFirstLine
	 */
	private static void processFixLine(StringBuilder sb, String line, boolean isFirstLine) {
		String content = line.substring(line.indexOf('\"') + 1, line.lastIndexOf('\"'));
		String[] values = content.split("\"\"");
		if (!isFirstLine) {
			sb.append("\n");
		}
		for (int i = 0; i < values.length; i++) {
			String value = values[i].replace("\"", "").trim();
			sb.append(value);
			if (i < values.length - 1) {
				sb.append(",");
			}
		}
	}

	/**
	 * 
	 * @param level
	 * @param args
	 */
	private static void log(Level level, String... args) {
		logger.log(level, getLogString(args));
	}
	/**
	 * 
	 * @param args
	 * @return
	 */
	private static String getLogString(String... args) {
		StringBuilder sbMessage = new StringBuilder(200);
		sbMessage.append(new Date());
		sbMessage.append(",");
		for (String msg : args) {
			sbMessage.append(msg);
			sbMessage.append(",");
		}
		return sbMessage.toString();
	}
	/**
	 * 
	 * @param logDir - path specified to print the logs 
	 * @param loggerLevel
	 * @throws IOException
	 */
	private static void initiateLogger(String logDir , String loggerLevel ) throws IOException {
		LocalDateTime now = LocalDateTime.now();
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyyMMddHHmmss");
		String formattedDate = now.format(formatter);	
		String path = logDir+"/Logs";
		handler = new FileHandler(path+formattedDate+".log");
		handler.setFormatter(new HD_LoggingFormatter());
		handler.setEncoding("UTF-8");
		logger.addHandler(handler);
		String level = loggerLevel;
		if (level == null || level.isEmpty())
			level = "INFO";
		logger.setLevel(Level.parse(level));
	}
	/**
	 * 
	 * @author DSGS
	 *
	 */
	private static class HD_LoggingFormatter extends Formatter {
		@Override
		public String format(LogRecord record) {
			StringBuilder sb = new StringBuilder();
			sb.append(record.getLevel()).append(',');
			sb.append(record.getMessage()).append('\n');
			return sb.toString();
		}
	}

	/**
	 * @param input - Each attribute value to check whether it contains prohibited character or not
	 * @return
	 */
	public static String replaceSpecialCharacters(String input) {	
		if(UIUtil.isNotNullAndNotEmpty(input)) {
			return input.replace("\"", " ").replace("¥cHB9H09}", " ");
		}else
			return input;
	}
}
