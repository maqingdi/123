import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Properties;
import java.util.Set;
import java.util.logging.FileHandler;
import java.util.logging.Formatter;
import java.util.logging.Level;
import java.util.logging.LogRecord;
import java.util.logging.Logger;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import com.matrixone.apps.domain.DomainConstants;
import com.matrixone.apps.domain.DomainObject;
import com.matrixone.apps.domain.DomainRelationship;
import com.matrixone.apps.domain.util.FrameworkException;
import com.matrixone.apps.domain.util.FrameworkUtil;
import com.matrixone.apps.domain.util.MapList;
import com.matrixone.apps.domain.util.MqlUtil;
import com.matrixone.apps.framework.ui.UIUtil;
import matrix.db.Context;
import matrix.db.Page;
import matrix.db.Policy;
import matrix.util.MatrixException;
import matrix.util.StringList;

public class NK_Boss_IN_mxJPO{
	// Logger setup with proper exception handling
	private static final Logger logger = Logger.getLogger(NK_Boss_IN_mxJPO.class.getName());
	private static FileHandler handler = null;
	// Constant values (configuration keys, schema properties, attribute selections)
	public static final String CONFIG_NK_BOSS_ImportItem = "NK_BOSS_ImportItem";
	public static final String ERROR_OUTPUT_PROCESSING_FAILED = "Output processing failed. Please check the error message.";
	public static final String SUCCESS_OUTPUT_PROCESSING = "Input processing completed.File : ((BO_I01002)";
	public static final String ERROR_OUTPUT_PROCESSING = "input processing failed. Please check the error message.(BO_I01003)";
	public static final String FILE_NOT_EXITS = "NK_BOSS_ImportItem.properties does not exist in the specified path";
	public static final String PROCESS_STARTED = "Processing has started.(BO_I01001)";
	public static final String Processing_file = "Processing file: ";
	public static final String INSUFFICIENT_COLUMNS = "Skipping line due to insufficient columns:";
	public static final String NOTFOUND = 	"Not found the target item.(BO_I00004)";
	public static final String TYPE_DOCUMENT = 	"Document";
	public static final String ORDER_BY = 	"-revision";
	private static int iCountItem = 0;
	private static int iCountItemInTransaction = 0;
	/** 
	 * This method reads all the keys from the config file and initiate the logger and check multiple execution 
	 * @param  context the 3dx<code>Context</code>object.
	 * @param args contains property file  files
	 * @throws Exception
	 */
	public static void NK_BossInExecute(Context context, String[] args) throws Exception {

		String logDir = readPageObject(context, CONFIG_NK_BOSS_ImportItem, "LOG_DIR");
		String loggerLevel = readPageObject(context, CONFIG_NK_BOSS_ImportItem, "Logger.Level");
		String INPUT_SUPPLIER_DIR = readPageObject(context, CONFIG_NK_BOSS_ImportItem, "INPUT_SUPPLIER_DIR");
		String INPUT_PRICE_DIR = readPageObject(context, CONFIG_NK_BOSS_ImportItem, "INPUT_PRICE_DIR");			
		initiateLogger(logDir, loggerLevel);
		validateDirectories(INPUT_SUPPLIER_DIR, INPUT_PRICE_DIR);
		Path lockFilePath = Paths.get(logDir, "process.lock");
		try {
			checkIfAlreadyRunning(lockFilePath);
			createLockFile(lockFilePath);
			System.out.println(PROCESS_STARTED);
			logger.log(Level.INFO, PROCESS_STARTED);
			if (args.length != 1) {
				handleArgumentError(lockFilePath);
			}
			if (args[0] == null || args[0].isEmpty() || !args[0].endsWith(".properties")) {
				handlePropertyFileError(lockFilePath);
			}	
			Path propertyFilePath = Paths.get(args[0]);
			if (!Files.exists(propertyFilePath)) {
				System.out.println(FILE_NOT_EXITS);
				logger.log(Level.INFO, FILE_NOT_EXITS);
				cleanUp(lockFilePath);
				System.exit(0);
			}
			ProcessSupplierFolder(context,INPUT_SUPPLIER_DIR,lockFilePath);
			ProcessUnitPriceFolder(context,INPUT_PRICE_DIR,lockFilePath);
			System.out.println(SUCCESS_OUTPUT_PROCESSING);
			logger.log(Level.INFO, SUCCESS_OUTPUT_PROCESSING);
		} catch (IOException e) {			
			e.printStackTrace();
			System.out.println(ERROR_OUTPUT_PROCESSING);
			logger.log(Level.INFO, ERROR_OUTPUT_PROCESSING);
		} finally {
			cleanUpResources(lockFilePath);
		}
	}
	/**
	 * Cleans up resources, including the lock file and logger.
	 * @param lockFilePath The path of the lock file to delete.
	 */
	private static void cleanUpResources(Path lockFilePath) {
		try {
			cleanUp(lockFilePath);
		} catch (IOException e) {
			System.out.println("Failed to delete lock file.");
		} finally {
			cleanUpLogger();
		}
	}
	/**
	 * Checks if a process lock file exists and exits the program if it does.
	 *
	 * @param lockFilePath The path of the lock file to check.
	 * @throws IOException If an error occurs while checking the lock file.
	 */
	private static void checkIfAlreadyRunning(Path lockFilePath) throws IOException {
		if (Files.exists(lockFilePath)) {
			logger.log(Level.WARNING, " Program is already running.(BO_E01001)");
			logger.log(Level.WARNING, ERROR_OUTPUT_PROCESSING_FAILED);
			System.exit(1);
		}
	}
	/**
	 * Validates that the specified directories exist.
	 * @param dirs The directories to validate.
	 * @throws IOException If an error occurs during validation.
	 */
	private static void validateDirectories(String... dirs) throws IOException {
		for (String dir : dirs) {
			validateDirectory(dir);
		}
	}
	/**
	 * Updates item attributes by processing CSV files in the specified input directory.
	 * @param context        The context from which the method is called.	
	 * @param lockFilePath  The path of the lock file to prevent concurrent processing.
	 * @throws Exception If an error occurs during processing.
	 */
	private static void ProcessSupplierFolder(Context context, String INPUT_SUPPLIER_DIR, Path lockFilePath) throws Exception {
		Path inputDirectory = Paths.get(INPUT_SUPPLIER_DIR);
		try (Stream<Path> csvFilesStream = Files.list(inputDirectory)
				.filter(file -> file.toString().endsWith(".csv"))) {	        
			List<Path> csvFiles = csvFilesStream.collect(Collectors.toList());       
			if (csvFiles.isEmpty()) {
				String errorMessage = NOTFOUND;
				System.out.println(errorMessage);
				logger.log(Level.SEVERE, errorMessage);
				return; 
			}
			for (Path csvFilePath : csvFiles) {       
				System.out.println(Processing_file + csvFilePath.getFileName());
				logger.log(Level.FINE, Processing_file + csvFilePath.getFileName());
				try {                
					processCsvFile(context, csvFilePath, lockFilePath);
				} catch (Exception e) {    				
					logger.log(Level.SEVERE, "Error processing file: " + csvFilePath.getFileName() + " - " + e.getMessage(), e);
				}	            		
			}
		} catch (IOException e) {
			logger.log(Level.SEVERE, "Error reading files in the directory: " + e.getMessage(), e);
		}
	}

	/**
	 * Processes a CSV file to update attributes in the system based on the provided data.
	 * @param context       The context used for domain operations.
	 * @param csvFilePath   The path to the CSV file to be processed.
	 * @param lockFilePath  The path to the lock file, which prevents concurrent processing.
	 * @return true if processing is successful; false otherwise.
	 * @throws Exception 
	 */
	private static void processCsvFile(Context context, Path csvFilePath, Path lockFilePath) throws Exception {
		try {
			List<String> lines = Files.readAllLines(csvFilePath);
			Pattern csvPattern = Pattern.compile("\"([^\"]*)\"|(?<=,|^)([^,]*)(?=,|$)");
			for (String line : lines) {
				Matcher matcher = csvPattern.matcher(line);
				List<String> columns = new ArrayList<>();
				while (matcher.find()) {				
					String field = matcher.group(1) != null ? matcher.group(1) : matcher.group(2);
					if (field != null) {
						columns.add(field.trim());
					}
				}
				if (columns.size() < 13) {
					logger.log(Level.WARNING, INSUFFICIENT_COLUMNS + line);
					System.out.println(INSUFFICIENT_COLUMNS + line);
					continue;
				}						
				String suppliercode = getColumn(columns, 1);
				String SupplierName = getColumn(columns, 2);
				String supplierNameJPN = getColumn(columns, 3);
				String postalCode = getColumn(columns, 4);
				String address1 = getColumn(columns, 5);
				String address2Half = getColumn(columns, 6);
				String phone = getColumn(columns, 7);
				String fax = getColumn(columns, 8);
				String personInCharge = getColumn(columns, 9);
				String ourCharge = getColumn(columns, 10);									
				String sbWhere = buildWhereConditionForSupplier(suppliercode);	  				
				StringList objectSelects = new StringList();
				objectSelects.add(DomainConstants.SELECT_ID);
				objectSelects.add(DomainConstants.SELECT_TYPE);
				objectSelects.add(DomainConstants.SELECT_NAME);
				objectSelects.add(DomainConstants.SELECT_REVISION);			
				StringList orderBys = new StringList();
				orderBys.add(ORDER_BY);
				MapList mlResults = DomainObject.findObjects(context, TYPE_DOCUMENT, null, sbWhere,
						objectSelects, (short) 0, orderBys);			
				if (!mlResults.iterator().hasNext()) { 					   							 
					logger.info(suppliercode + " is not present as supplier master.Creating it.");
					createDocObject(context , SupplierName, supplierNameJPN,postalCode,address1,address2Half,phone,fax,personInCharge,ourCharge,suppliercode);
				} else {
					Iterator<?> itr = mlResults.iterator();
					while (itr.hasNext()) {
						Map<?, ?> objectMap = (Map<?, ?>) itr.next();
						String Id = (String) objectMap.get(DomainConstants.SELECT_ID);	 						
						String mqlCommand = String.format("revise bus %s select id dump |;", Id);
						String sNewId =	MqlUtil.mqlCommand(context, mqlCommand, false);
						logger.info(sNewId + " Revised new Document id");
						System.out.println("Revised new Document id"+sNewId);		
						UpdateExtensionAttribute(context,sNewId,SupplierName, supplierNameJPN,postalCode,address1,address2Half,phone,fax,personInCharge,ourCharge,suppliercode);
						String mqlCommandStatus = String.format("mod bus %s current %s;", sNewId, "Released");							
						MqlUtil.mqlCommand(context, mqlCommandStatus, false);
						System.out.println("Updated revisedID : " + sNewId + " to status: " + "Released");
						DomainObject domObj = DomainObject.newInstance(context,Id);
						StringList selectables = new StringList();
						selectables.add(DomainConstants.SELECT_ID);
						MapList mlDocInfoList = domObj.getRelatedObjects(context, "SpecificationDocument",DomainConstants.QUERY_WILDCARD,selectables,
								new StringList(DomainRelationship.SELECT_ID),true, false, (short) 1, DomainConstants.EMPTY_STRING, DomainConstants.EMPTY_STRING, 0);									
						for(int j=0; j<mlDocInfoList.size(); j++) {
							Map objMap = (Map)mlDocInfoList.get(j);						
							String objectId = (String)objMap.get(DomainConstants.SELECT_ID);
							String connID = (String)objMap.get(DomainRelationship.SELECT_ID);																			
							MqlUtil.mqlCommand(context, "DELETE CONNECTION "+connID, false);
							String mqlCommandAddConnection = String.format("connect bus %s relationship \"SpecificationDocument\" from %s",sNewId,objectId);
							String mqlCommandAddConnectionValue =MqlUtil.mqlCommand(context, mqlCommandAddConnection, false); 						
						}	                
					}
				}
			}
		} catch (IOException e) {
			logger.log(Level.SEVERE, " Failed to regist or update the item.: " + csvFilePath.getFileName() + " - " + e.getMessage(), e);
		}
	}
	/**
	 * Safely fetches a column value or returns an empty string if the index is out of bounds.
	 */
	private static String getColumn(List<String> columns, int index) {
		if (index >= 0 && index < columns.size()) {
			return columns.get(index).trim();  
		}
		return ""; 
	}

	/**
	 * Creates a new Document object in the system, sets its attributes, and updates its status to "Released".
	 * Attributes such as supplier details and owner are assigned during the process.
	 */
	private static void createDocObject(Context context, String supplierName, String supplierNameJPN, String postalCode, String address1, String address2Half, String phone, 
			String fax, String personIncharge, String ourcharge, String suppliercode) throws Exception{

		DomainObject doObj = DomainObject.newInstance(context);
		String strRevision = getRevisionFromPolicy(context, "Document Release");	
		String strName =  getNativeAutonumberingValues(context, TYPE_DOCUMENT);
		doObj.createObject(context, TYPE_DOCUMENT, strName, strRevision, "Document Release", "eService Production");
		String newObejctID = doObj.getInfo(context, DomainConstants.SELECT_ID);
		logger.info(newObejctID + " Created Document ID .");
		System.out.println("newDocumentObejctID--->"+newObejctID);
		doObj.setId(newObejctID);
		UpdateExtensionAttribute(context,newObejctID,supplierName, supplierNameJPN,postalCode,address1,address2Half,phone,fax,personIncharge,ourcharge,suppliercode);
		doObj.setOwner(context, "admin_platform");
		String mqlCommandStatus = String.format("mod bus %s current %s;", newObejctID, "Released");							
		MqlUtil.mqlCommand(context, mqlCommandStatus, false);
		System.out.println("Updated newObejctID : " + newObejctID + " to status: " + "Released");

	}

	/**
	 * This method used to get the auto numbering values
	 * @param context
	 * @param strFilePrefix
	 * @return
	 * @throws Exception
	 */
	private static String getNativeAutonumberingValues(Context context, String strFilePrefix) throws Exception {
		String strAutoName = "";
		String strName = "";
		try {
			if (strFilePrefix.equalsIgnoreCase(TYPE_DOCUMENT)) {
				String strAttrAutoNamingValue = "attribute[VPLMsys/AutoNamingValue].value";
				String strItemCounter = MqlUtil.mqlCommand(context,
						"temp query bus VPLMCounter PLMDmtDocument/PLMDMTDocument* * select " 
								+ strAttrAutoNamingValue + " id dump |", true);				
				StringList slItem = FrameworkUtil.split(strItemCounter, "|");
				iCountItemInTransaction = Integer.parseInt(slItem.get(3));
				strAutoName = String.valueOf(++iCountItemInTransaction); 
				String strAutoNamePrefix = "NK_DOC_";
				strName = strAutoNamePrefix + strAutoName;
				DomainObject dObjItemCounterId = DomainObject.newInstance(context, slItem.get(4));			
				dObjItemCounterId.setAttributeValue(context, "VPLMsys/AutoNamingValue",
						String.valueOf(Integer.parseInt(slItem.get(3)) + 1));	           
			}
		} catch (MatrixException e) {
			e.printStackTrace();
		} 
		return strName;
	}
	/**
	 * This method gets the revision
	 * @param context
	 * @param strPolicy
	 * @return
	 */
	private static String getRevisionFromPolicy(Context context, String strPolicy) {
		Policy policy = new Policy(strPolicy);
		String strMajor = DomainConstants.EMPTY_STRING;
		String strMinor = DomainConstants.EMPTY_STRING;
		String strDelimeter = DomainConstants.EMPTY_STRING;
		try {
			strMajor = policy.getFirstInMajorSequence(context);
			strMinor = policy.getFirstInMinorSequence(context);
			strDelimeter = policy.delimiter(context);		
		} catch (MatrixException e) {
			e.printStackTrace();
		}
		return strMajor + strDelimeter + strMinor;
	}

	/**
	 * Constructs a where condition string for a supplier based on the provided attribute name.
	 * The condition is formatted to match the title attribute of the supplier.
	 * @param attrName the attribute name to build the condition for
	 * @return the constructed where condition string
	 */
	private static String buildWhereConditionForSupplier(String attrName) {
		StringBuilder sbWhere = new StringBuilder();	
		attrName = attrName.replace("\"", "").trim(); 
		sbWhere.append("attribute[title]=='").append(attrName).append("'");		
		return sbWhere.toString();
	}

	/**
	 * Updates the attributes of the given object with supplier details and ensures the required interface is added.
	 * If the interface "NK_EXT_DOC_SUPPLIER" does not exist, it is added before updating the attributes.
	 * @throws Exception if the update process fails
	 */
	private static void UpdateExtensionAttribute(Context context, String objectId, String supplierName, String supplierNameJPN, String postalCode,String address1, 
			String address2Half, String phone, String fax, String personIncharge, String ourcharge, String suppliercode) throws Exception {

		DomainObject doObj = DomainObject.newInstance(context, objectId);
		String interfaceList = MqlUtil.mqlCommand(context, "print bus "+objectId+" select interface dump |");	
		String[] interfaces = interfaceList.split("\\|");
		boolean interfaceExists = Arrays.asList(interfaces).contains("NK_EXT_DOC_SUPPLIER");
		if (!interfaceExists) {
			MqlUtil.mqlCommand(context, "mod bus $1 add interface $2", objectId, "NK_EXT_DOC_SUPPLIER");		
		}	
		try {			
			Map<String, String> attributes = new HashMap<>();
			attributes.put("NK_SUPPLIER_NAME_JPN", supplierName);			
			attributes.put("NK_SUPPLIER_NAME_KANA", supplierNameJPN);
			attributes.put("NK_POSTAL_CODE", postalCode);
			attributes.put("NK_ADDRESS1_JPN", address1);
			attributes.put("NK_ADDRESS1_KANA", address2Half);
			attributes.put("NK_TEL_NO", phone);
			attributes.put("NK_FAX_NO", fax);
			attributes.put("NK_PERSON_NAME_JPN", personIncharge);
			attributes.put("NK_KEYWORD_1", ourcharge);
			attributes.put("Title", suppliercode);
			for (Map.Entry<String, String> entry : attributes.entrySet()) {
				doObj.setAttributeValue(context, entry.getKey(), entry.getValue());
			}
			System.out.println("Attribute updated successfully with values for extension Document");			
		} catch (FrameworkException e) {
			System.out.println("Failed to update attribute values for extension Document: " + e.getMessage());
			throw e;
		}
	}
	/**
	 * @param lockFilePath to check multiple instance running and delete 
	 * @throws IOException
	 */
	private static void createLockFile(Path lockFilePath) throws IOException {
		try {
			Files.createFile(lockFilePath);
		} catch (IOException e) {
			System.out.println("Failed to create lock file. Exiting...");
			System.exit(1);
		}
	}	
	/**
	 * check the Property File Error
	 * @param lockFilePath to check multiple instance running and delete 
	 * @throws IOException
	 */
	private static void handlePropertyFileError(Path lockFilePath) throws IOException {
		logger.log(Level.WARNING, "Could not read NK_BO_ImportItem.conf.(BO_E01003)");
		cleanUp(lockFilePath);
		System.exit(0);
	}
	/**
	 * prints the Argument Error 
	 * @param lockFilePath to check multiple instance running and delete 
	 * @throws IOException
	 */
	private static void handleArgumentError(Path lockFilePath) throws IOException {
		logger.log(Level.WARNING, "Not enough arguments. (BO_E01002)");
		cleanUp(lockFilePath);
		System.exit(0);
	}
	/**
	 * @param lockFilePath to check multiple instance running and delete 
	 * @throws IOException
	 */
	private static void cleanUp(Path lockFilePath) throws IOException {
		Files.deleteIfExists(lockFilePath);
		if (handler != null) {
			handler.close();
		}
	}
	/**
	 * Read Page object from the DB 
	 * @param context
	 * @param strPageName - Name of the page file 
	 * @param strKeyName - key name present in the page file 
	 * @throws Exception
	 */
	public static String readPageObject(Context context, String strPageName, String strKeyName) throws Exception {
		Properties propNotification = new Properties();
		String strProperty = DomainConstants.EMPTY_STRING;
		try {
			Page pageAttributePopulation = new Page(strPageName);
			pageAttributePopulation.open(context);
			String strProperties = pageAttributePopulation.getContents(context);
			pageAttributePopulation.close(context);
			InputStream input = new ByteArrayInputStream(strProperties.getBytes("UTF8"));
			propNotification.load(input);
			if(propNotification.containsKey(strKeyName)) {
				strProperty = propNotification.getProperty(strKeyName);
			}else {
				logger.log( Level.INFO, strKeyName +"IS NOT PRESENT");			
				System.exit(0);			
			}
		} catch (Exception e) {
			System.out.println("Check page file name");
			e.printStackTrace();
		}
		return strProperty;
	}
	/**
	 * @param dir holds the output directory path 
	 */
	private static void validateDirectory(String dir) {
		File file = new File(dir);
		if (!file.exists() || !file.isDirectory()) { 
			logger.log(Level.WARNING, "Not found the destination folder path.(BO_E01004) Check INPUT_SUPPLIER_DIR, INPUT_PRICE_DIR paths.");
			System.exit(0);
		}
	}
	/**
	 * 
	 * @param logDir - path specified to print the logs 
	 * @param loggerLevel
	 * @throws IOException
	 */
	private static void initiateLogger(String logDir , String loggerLevel ) throws IOException {
		if (handler != null) {
			handler.close(); 
		}
		LocalDateTime now = LocalDateTime.now();
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyyMMddHHmmss");
		String formattedDate = now.format(formatter);	
		String path = logDir + "/Logs";
		handler = new FileHandler(path + formattedDate + ".log", true);
		handler.setFormatter(new HD_LoggingFormatter());
		handler.setEncoding("UTF-8");
		logger.addHandler(handler);
		String level = loggerLevel != null && !loggerLevel.isEmpty() ? loggerLevel : "INFO";
		logger.setLevel(Level.parse(level));

	}

	/**
	 * Cleans up the logger by closing and removing the associated handler.
	 * Ensures that resources tied to the logger are released properly.
	 */
	private static void cleanUpLogger() {
		if (handler != null) {
			handler.close();
			logger.removeHandler(handler);
			handler = null;
		}
	}
	/**
	 * Custom formatter for logging that formats log messages into a simple, comma-separated format 
	 * containing the log level and the log message.
	 * 
	 * This class extends the `Formatter` class to provide a customized log format suitable for 
	 * outputting log entries in a more concise and readable manner, typically used in scenarios 
	 * where logs are consumed or processed in a structured way, such as CSV logging.
	 */
	private static class HD_LoggingFormatter extends Formatter {
		@Override
		public String format(LogRecord record) {
			StringBuilder sb = new StringBuilder();
			sb.append(record.getLevel()).append(',');
			sb.append(record.getMessage()).append('\n');
			return sb.toString();
		}
	}

	/**
	 * Processes all CSV files in the specified unit price folder, logging progress and handling errors.
	 * Each CSV file is passed to a method for further processing, and appropriate logs are created for errors.
	 * @param context       the eMatrix context
	 * @param INPUT_PRICE_DIR the directory containing unit price CSV files
	 * @param lockFilePath  the path to the lock file to coordinate processing
	 * @throws Exception if there is an error during the folder processing
	 */
	private static void ProcessUnitPriceFolder(Context context, String INPUT_PRICE_DIR, Path lockFilePath) throws Exception {
		Path inputDirectory = Paths.get(INPUT_PRICE_DIR);
		try (Stream<Path> csvFilesStream = Files.list(inputDirectory)
				.filter(file -> file.toString().endsWith(".csv"))) {	        
			List<Path> csvFiles = csvFilesStream.collect(Collectors.toList());       
			if (csvFiles.isEmpty()) {
				String errorMessage =  NOTFOUND;
				System.out.println(errorMessage);
				logger.log(Level.SEVERE, errorMessage);
				return; 
			}
			for (Path csvFilePath : csvFiles) {       
				System.out.println(Processing_file + csvFilePath.getFileName());
				logger.log(Level.FINE, Processing_file + csvFilePath.getFileName());
				try {                
					processUnitPriceCsvFile(context, csvFilePath, lockFilePath);
				} catch (Exception e) {    				
					logger.log(Level.SEVERE, "Error processing file: " + csvFilePath.getFileName() + " - " + e.getMessage(), e);
				}	            		
			}
		} catch (IOException e) {
			logger.log(Level.SEVERE, "Error reading files in the directory: " + e.getMessage(), e);
		}
	}

	/**
	 * Processes a single unit price CSV file, extracting data and performing operations like creating or updating MBOM objects.
	 * Checks if the item already exists and updates its attributes or relationships accordingly.
	 * @param context       the eMatrix context
	 * @param csvFilePath   the path to the CSV file to process
	 * @param lockFilePath  the path to the lock file to coordinate processing
	 * @throws Exception if an error occurs during file processing or object operations
	 */
	private static void processUnitPriceCsvFile(Context context, Path csvFilePath, Path lockFilePath) throws Exception {
		try {
			List<String> lines = Files.readAllLines(csvFilePath);
			Pattern csvPattern = Pattern.compile("\"([^\"]*)\"|(?<=,|^)([^,]*)(?=,|$)");
			for (String line : lines) {
				Matcher matcher = csvPattern.matcher(line);
				List<String> columns = new ArrayList<>();
				while (matcher.find()) {
					String field = matcher.group(1) != null ? matcher.group(1) : matcher.group(2);
					if (field != null) {			         
						field = field.trim().replaceAll("^\"|\"$", "");
						columns.add(field);
					}
				}
				if (columns.size() < 26) {
					logger.log(Level.WARNING, INSUFFICIENT_COLUMNS + line);
					System.out.println(INSUFFICIENT_COLUMNS + line);
					continue;
				}
				String plant = getColumn(columns, 1);
				String itemNumber = getColumn(columns, 2);
				String versionNumber = getColumn(columns, 3);
				String unitPrice1 = getColumn(columns, 4);
				String currencyUnit1 = getColumn(columns, 5);
				String quantity1 = getColumn(columns, 6);
				String supplierCode1 = getColumn(columns, 7);
				String purchaseRatio1 = getColumn(columns, 8);
				String unitPriceCategory1 = getColumn(columns, 9);
				String purchasingInfoCategory1 = getColumn(columns, 10);
				String unitPrice2 = getColumn(columns, 11);
				String currencyUnit2 = getColumn(columns, 12);
				String quantity2 = getColumn(columns, 13);
				String supplierCode2 = getColumn(columns, 14);
				String purchaseRatio2 = getColumn(columns, 15);
				String unitPriceCategory2 = getColumn(columns, 16);
				String purchasingInfoCategory2 = getColumn(columns, 17);
				String unitPrice3 = getColumn(columns, 18);
				String currencyUnit3 = getColumn(columns, 19);
				String quantity3 = getColumn(columns, 20);
				String supplierCode3 = getColumn(columns, 21);
				String purchaseRatio3 = getColumn(columns, 22);
				String unitPriceCategory3 = getColumn(columns, 23);
				String purchasingInfoCategory3 = getColumn(columns, 24);
				String dateOfDiscontinuation = getColumn(columns, 25);
				String dateOfMaintenanceDiscontinuation = getColumn(columns, 26);
				String productionBOMAvailability = getColumn(columns, 27);
				String standardCost = getColumn(columns, 28);
				String sbWhere = buildWhereConditionForUnitPrice(plant ,itemNumber,versionNumber);	 

				StringList objectSelects = new StringList();
				objectSelects.add(DomainConstants.SELECT_ID);
				objectSelects.add(DomainConstants.SELECT_TYPE);
				objectSelects.add(DomainConstants.SELECT_NAME);
				objectSelects.add(DomainConstants.SELECT_REVISION);
				objectSelects.add("attribute[NK_EXT_MBOM_BOSS.NK_VENDER_CODE1]");
				objectSelects.add("attribute[NK_EXT_MBOM_BOSS.NK_VENDER_CODE2]");
				objectSelects.add("attribute[NK_EXT_MBOM_BOSS.NK_VENDER_CODE3]");

				StringList orderBys = new StringList();
				orderBys.add(ORDER_BY);
				MapList mlResults = DomainObject.findObjects(context, "CreateAssembly", null, sbWhere,
						objectSelects, (short) 0, orderBys);			
				if (!mlResults.iterator().hasNext()) {   		
					System.out.println("No found the target data");
					logger.info(plant + " is not present as supplier master.");					
				} else {
					Iterator<?> itr = mlResults.iterator();
					while (itr.hasNext()) {
						Map<?, ?> objectMap = (Map<?, ?>) itr.next();
						String Id = (String) objectMap.get(DomainConstants.SELECT_ID);	
						String NK_VENDER_CODE1 = (String) objectMap.get("attribute[NK_EXT_MBOM_BOSS.NK_VENDER_CODE1]");	 
						String NK_VENDER_CODE2 = (String) objectMap.get("attribute[NK_EXT_MBOM_BOSS.NK_VENDER_CODE2]");	 
						String NK_VENDER_CODE3 = (String) objectMap.get("attribute[NK_EXT_MBOM_BOSS.NK_VENDER_CODE3]");	 
						UpdateAttributeMBOM(context,Id,plant,itemNumber,versionNumber,unitPrice1,currencyUnit1,quantity1,supplierCode1,purchaseRatio1,unitPriceCategory1,
								purchasingInfoCategory1,unitPrice2,currencyUnit2,quantity2,supplierCode2,purchaseRatio2,unitPriceCategory2,purchasingInfoCategory2,unitPrice3,
								currencyUnit3 ,quantity3 ,supplierCode3,purchaseRatio3 , unitPriceCategory3 ,purchasingInfoCategory3, dateOfDiscontinuation , 
								dateOfMaintenanceDiscontinuation, productionBOMAvailability , standardCost );
						if(UIUtil.isNotNullAndNotEmpty(supplierCode1)) {
							if(!NK_VENDER_CODE1.equalsIgnoreCase(supplierCode1)) {									
								deleteSupplierMasterRelationship(context, Id);
								createSupplierMasterRelationship(context, supplierCode1,Id);							    
							}else {
								System.out.println("Both the supplierCode1 and vendor code same ");
							}
						}else {
							System.out.println("supplierCode1 is null or empty in input file ");
						}	
						if(UIUtil.isNotNullAndNotEmpty(supplierCode2)) {
							if(!NK_VENDER_CODE2.equalsIgnoreCase(supplierCode2)) {								
								deleteSupplierMasterRelationship(context, Id);
								createSupplierMasterRelationship(context, supplierCode2,Id);							    
							}else {
								System.out.println("Both the supplierCode2 and vendor code same ");
							}
						}else {
							System.out.println("supplierCode2 is null or empty in input file ");
						}	
						if(UIUtil.isNotNullAndNotEmpty(supplierCode3)) {
							if(!NK_VENDER_CODE3.equalsIgnoreCase(supplierCode3)) {									
								deleteSupplierMasterRelationship(context, Id);
								createSupplierMasterRelationship(context, supplierCode3,Id);							    
							}else {
								System.out.println("Both the supplierCode3 and vendor code same ");
							}
						}else {
							System.out.println("supplierCode3 is null or empty in input file ");
						}	
					}
				}
			}
		} catch (IOException e) {
			logger.log(Level.SEVERE, "Failed to regist or update the item.: " + csvFilePath.getFileName() + " - " + e.getMessage(), e);
		}

	}

	/**
	 * Creates a relationship between a supplier document and an MBOM object using the specified supplier code and MBOM ID.
	 * Searches for the supplier document based on the supplier code and connects it to the MBOM object via the "SpecificationDocument" relationship.
	 *
	 * @param context       the eMatrix context
	 * @param supplierCode1 the supplier code to find the supplier document
	 * @param MbOMID        the ID of the MBOM object to connect with the supplier document
	 * @throws FrameworkException if an error occurs during the relationship creation process
	 */
	private static void createSupplierMasterRelationship(Context context, String supplierCode1, String MbOMID) throws FrameworkException {
		System.out.println("CreateSupplierMasterRelationship");
		String sbWhere = buildWhereConditionForSupplier(supplierCode1);	  		
		StringList objectSelects = new StringList();
		objectSelects.add(DomainConstants.SELECT_ID);
		objectSelects.add(DomainConstants.SELECT_TYPE);
		objectSelects.add(DomainConstants.SELECT_NAME);
		objectSelects.add(DomainConstants.SELECT_REVISION);

		StringList orderBys = new StringList();
		orderBys.add(ORDER_BY);
		MapList mlResults = DomainObject.findObjects(context, TYPE_DOCUMENT, null, sbWhere,
				objectSelects, (short) 0, orderBys);
		if (!mlResults.iterator().hasNext()) {   							 
			logger.info("Not found the Document please check supplier code in Unit Price File ");
		} else {
			Iterator<?> itr = mlResults.iterator();
			while (itr.hasNext()) {
				Map<?, ?> objectMap = (Map<?, ?>) itr.next();
				String Id = (String) objectMap.get(DomainConstants.SELECT_ID);	 
				String mqlCommandAddConnection = String.format("connect bus %s relationship \"SpecificationDocument\" from %s",Id,MbOMID);
				String mqlCommandAddConnectionValue =MqlUtil.mqlCommand(context, mqlCommandAddConnection, false); 
				System.out.println("Connection Success");
			}
		}
	}

	/**
	 * Deletes all "SpecificationDocument" relationships connected to the specified MBOM object.
	 * Iterates through the relationships and removes them using MQL commands.
	 *
	 * @param context the eMatrix context
	 * @param id      the ID of the MBOM object whose relationships need to be deleted
	 * @throws FrameworkException if an error occurs during the relationship deletion process
	 */
	private static void deleteSupplierMasterRelationship(Context context, String id) throws FrameworkException {

		DomainObject domObj = DomainObject.newInstance(context,id);
		StringList selectables = new StringList();
		selectables.add(DomainConstants.SELECT_ID);
		MapList mlDocInfoList = domObj.getRelatedObjects(context, "SpecificationDocument", "*", selectables, 
				new StringList(DomainRelationship.SELECT_ID), true, true, (short) 1, null, null, 0);					
		Iterator<?> itr = mlDocInfoList.iterator();
		while (itr.hasNext()) {		
			Map<?, ?> objectMap = (Map<?, ?>) itr.next();								
			String connID = (String)objectMap.get(DomainRelationship.SELECT_ID);											
			String command = String.format("delete connection %s ",connID);																	
			MqlUtil.mqlCommand(context, command);
		}
	}

	/**
	 * Updates attributes of a specified MBOM (Manufacturing Bill of Materials) object, including adding required 
	 * interfaces and setting various attributes related to pricing, supplier information, and other BOM details.
	 **/
	private static void UpdateAttributeMBOM(Context context, String id, String plant, String itemNumber,
			String versionNumber, String unitPrice1, String currencyUnit1, String quantity1, String supplierCode1,
			String purchaseRatio1, String unitPriceCategory1, String purchasingInfoCategory1, String unitPrice2,
			String currencyUnit2, String quantity2, String supplierCode2, String purchaseRatio2,
			String unitPriceCategory2, String purchasingInfoCategory2, String unitPrice3, String currencyUnit3,
			String quantity3, String supplierCode3, String purchaseRatio3, String unitPriceCategory3,
			String purchasingInfoCategory3, String dateOfDiscontinuation, String dateOfMaintenanceDiscontinuation,
			String productionBOMAvailability, String standardCost) throws FrameworkException {

		DomainObject doObj = DomainObject.newInstance(context, id);
		String interfaceList = MqlUtil.mqlCommand(context, "print bus "+id+" select interface dump |");	
		String[] interfaces = interfaceList.split("\\|");
		String[] requiredInterfaces = {"NK_EXT_MBOM_REVISION_SYSTEM", "NK_EXT_MBOM_BOSS"};

		Set<String> interfaceSet = new HashSet<>(Arrays.asList(interfaces));

		for (String requiredInterface : requiredInterfaces) {
			if (!interfaceSet.contains(requiredInterface)) {		     
				MqlUtil.mqlCommand(context, "mod bus $1 add interface $2", id, requiredInterface);
				System.out.println("Interface '" + requiredInterface + "' added to business object. Not present.");
			}
		}
		try {			
			Map<String, String> attributes = new HashMap<>();
			attributes.put("NK_EXT_MBOM_REVISION_SYSTEM.NK_PLANT", plant);
			attributes.put("EnterpriseExtension.V_PartNumber", itemNumber);
			attributes.put("NK_EXT_MBOM_BASE.NK_REVISION", versionNumber);			
			attributes.put("NK_EXT_MBOM_BOSS.NK_UNIT_PRICE1", unitPrice1); 
			attributes.put("NK_EXT_MBOM_BOSS.NK_CURRENCY_UNIT1", currencyUnit1); 
			attributes.put("NK_EXT_MBOM_BOSS.NK_QUANTITY1", quantity1);
			attributes.put("NK_EXT_MBOM_BOSS.NK_VENDER_CODE1", supplierCode1); 
			attributes.put("NK_EXT_MBOM_BOSS.NK_PURCHASING_PROPORTION1", purchaseRatio1); 
			attributes.put("NK_EXT_MBOM_BOSS.NK_UNIT_PRICE_INDICATOR1", unitPriceCategory1); 
			attributes.put("NK_EXT_MBOM_BOSS.NK_PURCHASING_INFORMATION_INDICATOR1", purchasingInfoCategory1);
			attributes.put("NK_EXT_MBOM_BOSS.NK_UNIT_PRICE2", unitPrice2);
			attributes.put("NK_EXT_MBOM_BOSS.NK_CURRENCY_UNIT2", currencyUnit2); 
			attributes.put("NK_EXT_MBOM_BOSS.NK_QUANTITY2", quantity2);
			attributes.put("NK_EXT_MBOM_BOSS.NK_VENDER_CODE2", supplierCode2); 
			attributes.put("NK_EXT_MBOM_BOSS.NK_PURCHASING_PROPORTION2", purchaseRatio2); 
			attributes.put("NK_EXT_MBOM_BOSS.NK_UNIT_PRICE_INDICATOR2", unitPriceCategory2);
			attributes.put("NK_EXT_MBOM_BOSS.NK_PURCHASING_INFORMATION_INDICATOR2", purchasingInfoCategory2); 
			attributes.put("NK_EXT_MBOM_BOSS.NK_UNIT_PRICE3", unitPrice3); 
			attributes.put("NK_EXT_MBOM_BOSS.NK_CURRENCY_UNIT3", currencyUnit3); 
			attributes.put("NK_EXT_MBOM_BOSS.NK_QUANTITY3", quantity3); 
			attributes.put("NK_EXT_MBOM_BOSS.NK_VENDER_CODE3", supplierCode3); 
			attributes.put("NK_EXT_MBOM_BOSS.NK_PURCHASING_PROPORTION3", purchaseRatio3); 
			attributes.put("NK_EXT_MBOM_BOSS.NK_UNIT_PRICE_INDICATOR3", unitPriceCategory3); 
			attributes.put("NK_EXT_MBOM_BOSS.NK_PURCHASING_INFORMATION_INDICATOR3", purchasingInfoCategory3); 
			for (Map.Entry<String, String> entry : attributes.entrySet()) {
				doObj.setAttributeValue(context, entry.getKey(), entry.getValue());				
			}
			System.out.println("Attribute updated successfully with values for extension MBOM Object");			
		} catch (FrameworkException e) {
			System.out.println("Failed to update attribute values for extension  MBOM Object: " + e.getMessage());
			throw e;
		}
	}

	/**
	 * Builds a WHERE condition string for filtering unit price records based on the provided plant, 
	 * item number, and version number. This condition can be used to query the relevant business objects 
	 * for further processing in the context of unit price updates in the MBOM (Manufacturing Bill of Materials).
	 */
	private static String buildWhereConditionForUnitPrice(String plant, String itemNumber, String versionNumber) {
		StringBuilder sbWhere = new StringBuilder();
		sbWhere.append("attribute[NK_EXT_MBOM_REVISION_SYSTEM.NK_PLANT].value=='").append(plant.replace("\"", "").trim()).append("'")
		.append("&&")
		.append("attribute[EnterpriseExtension.V_PartNumber].value=='").append(itemNumber.replace("\"", "").trim()).append("'")
		.append("&&")
		.append("attribute[NK_EXT_MBOM_BASE.NK_REVISION].value=='").append(versionNumber.replace("\"", "").trim()).append("'");
		return sbWhere.toString();
	}

}