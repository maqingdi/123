let spaceURLForWS = "";

function get3DSpaceURLWS() {
  return new Promise((resolve, reject) => {
    if (spaceURLForWS.length > 0) {
      resolve(spaceURLForWS);
      return;
    }
    requirejs(["DS/PlatformAPI/PlatformAPI"], function (PlatformAPI) {
      let appConfigs = PlatformAPI.getAllApplicationConfigurations();

      for (let index = 0; index < appConfigs.length; index++) {
        if (appConfigs[index]["propertyKey"] === "app.urls.myapps") {
          let url = appConfigs[index]["propertyValue"];
          spaceURLForWS = url;
          break;
        }
      }
      resolve(spaceURLForWS);
    });
  });
}

export const getURL= async () => {
  let res = await get3DSpaceURLWS();
  console.log("res----"+res);
  return spaceURLForWS ;
};
