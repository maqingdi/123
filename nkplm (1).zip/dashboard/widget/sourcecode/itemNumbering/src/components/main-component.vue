/** *number.vue * @Author : DSGS * @Description ---. * Item Numbering
Application */
<template>
  <v-container max-width="600">
    <v-card class="mx-auto vCard">
      <v-card-title class="vCardHeader">
        <span class="headline">Perform Item Numbering</span>
      </v-card-title>
      <v-divider></v-divider>
      <v-card-text class="cardText">
        <v-form @submit.prevent="handleSubmit">
          <v-row>
            <v-col cols="6">
              <v-field-label class="labelField">Parts No</v-field-label>
            </v-col>
            <v-col cols="6">
              <v-text-field v-model="textInput" disabled variant="outlined"></v-text-field>
            </v-col>
          </v-row>
          <v-row>
            <v-col cols="6">
              <v-field-label class="labelField">Items Type</v-field-label>
            </v-col>
            <v-col cols="6">
              <v-select v-model="selectedOption" item-class="blue-option" :items="options()" item-title="label"
                item-value="typeName" @update:modelValue="onSelectChange" variant="solo"></v-select>
            </v-col>
          </v-row>
          <v-card class="mx-auto vCard">
            <v-card-title>
              <span class="text-subtitle-1 vcardTitle">{{
                getLabel("DetailedItems")
                }}</span>
            </v-card-title>
            <v-spacer></v-spacer>
            <v-card-text class="subCard" :key="somevalue">
              <v-row v-for="(field, index) in additionalFields" :key="index">
                <v-row v-if="field.itemType == 'Textbox'">
                  <v-col cols="6">
                    <v-field-label class="labelField">{{
                      getLabel(field.itemName)
                      }}</v-field-label>
                  </v-col>
                  <v-col cols="6">
                    <v-text-field v-model="textInput" :maxlength="field.max ? field.max : undefined"
                      placeholder="Enter a value" @input="checkInput(field)" variant="solo"></v-text-field>
                  </v-col>
                </v-row>
                <v-row v-if="field.itemType == 'Dropdown'">
                  <v-col cols="6">
                    <v-field-label class="labelField">{{
                      getLabel(field.itemName)
                      }}</v-field-label>
                  </v-col>
                  <v-col cols="6">
                    <v-select :v-model="selectedOption + '|' + field.itemName" :items="field.Options" item-title="label"
                      item-value="optionName" @blur="validateSelect(field)" @update:modelValue="(value) => onSelectOptions(value, field)
                        " variant="solo"></v-select>
                  </v-col>
                </v-row>
              </v-row>
            </v-card-text>
          </v-card>
          <v-row class="mt-4">
            <v-spacer></v-spacer>
            <v-col cols="auto">
              <v-btn type="submit" :disabled="!isNextEnabled" color="#368ec4">{{
                getLabel("Next")
                }}</v-btn>
              <v-btn color="#fff" @click="handleCancel" class="ml-2">{{
                getLabel("Cancel")
                }}</v-btn>
            </v-col>
          </v-row>
        </v-form>
      </v-card-text>
    </v-card>
    <!-- Confirmation Dialog -->
    <confirmation :params="dialogParams" />
    <showAlert ref="alertMessage" />
  </v-container>
</template>

<script setup>
//Import Components
import WebServicesData from "../assets/constants/webServices.json";
import Constants from "../assets/constants/constants.json";
import NkReferenceNumber from "../assets/constants/NKReferenceNumbering.json";
import DefaultAttribute from "../assets/constants/NKDefaultAttribute.json";
import confirmation from "./confirmation-dialog.vue";
import showAlert from "./alert-component.vue";
import i18n from "../plugins/i18n.js";
import { makeWSCall } from "../js/api.js";
import { ref, computed, defineEmits, onMounted } from "vue";

const props = defineProps({
  objectData: {
    type: Array,
    required: true,
  },
  securityContext: {
    required: true,
  },
  csrf: {
    required: true,
  },
  SpaceUrl: {
    required: true,
  },
  category: {
    required: true,
  },
});
// Reactive variables
const textInput = ref("");
const selectedOption = ref("");
const submitted = ref(false);
const isValueSelected = ref(false);
const additionalFields = ref([]);
const somevalue = ref(0);
const extendedAttributes = ref([]);
const stockInput = ref([]);
const dialogParams = ref([]);
const serialNumberTarget = ref("");
const seqNumber = ref([]);
const dAttribute = ref([]);
const itemStock = ref([]);
const alertMessage = ref([]);
const getParentNames = ref([]);

const filteredData = NkReferenceNumber.filter(
  (ele) => ele.ItemTypeList.objectType === props.category
);

const lang = widget.getValue("enable-language");

const options = () => {
  //To check the itemTypes empty in the JSON file
  if (filteredData[0].ItemTypeList.ItemTypes) {
    const returnData = filteredData[0].ItemTypeList.ItemTypes.filter(
      (ele) => ele.typeName
    );
    if (returnData.length === 0) {
      alertMessage.value.showAlert(i18n.global.t("MESSAGE5")).error();
    } else {
      return filteredData[0].ItemTypeList.ItemTypes.filter(
        (ele) => ele.typeName
      );
    }
  } else {
    alertMessage.value.showAlert(i18n.global.t("MESSAGE5")).error();
  }

  //return filteredData[0].ItemTypeList.ItemTypes.filter(ele => ele.typeName);
};

onMounted(() => {
  addLabelToOptionNames(filteredData[0].ItemTypeList.ItemTypes);
});

const addLabelToOptionNames = (obj) => {
  if (Array.isArray(obj)) {
    obj.forEach((item) => addLabelToOptionNames(item));
  } else if (typeof obj === "object" && obj !== null) {
    if (obj.optionName) {
      obj.label = getLabel(obj.optionName);
    }
    if (obj.typeName) {
      obj.label = getLabel(obj.typeName);
    }
    Object.keys(obj).forEach((key) => {
      addLabelToOptionNames(obj[key]);
    });
  }
};

const isNextEnabled = computed(() => {
  return textInput.value && textInput.value.length >= 4;
});

const validateSelect = (field) => {
  if (field.Options.length === 0) {
    alertMessage.value.showAlert(i18n.global.t("MESSAGE7")).error();
  }
};

// Handle form submission
const handleSubmit = async () => {
  submitted.value = true;
  itemStock.value = textInput.value;
  if (props.category === "E-BOM") {
    extendedAttributes.value = extendedAttributes.value.filter(
      (ele) => ele.exTarget === "PhysicalProduct"
    );
  } else if (props.category === "M-BOM") {
    extendedAttributes.value = extendedAttributes.value.filter(
      (ele) => ele.exTarget === "ManufacturingAssembly"
    );
  } else if (props.category === "Document") {
    extendedAttributes.value = extendedAttributes.value.filter(
      (ele) => ele.exTarget === "Document"
    );
  }

  if (serialNumberTarget.value) {
    await registerSeqNo();
    textInput.value = seqNumber.value;
    dAttribute.value = defaultAttribute();

    dialogParams.value = {
      title: i18n.global.t("CONFIRM"),
      message: i18n.global.t("REGISTER", [textInput.value]),
      button: {
        yes: {
          label: i18n.global.t("Yes"),
        },
        no: {
          label: i18n.global.t("No"),
        },
      },
      callback: async (confirm) => {
        if (confirm) {
          await registerPartNo();
        } else {
          refresh();
        }
      },
    };
  } else {
    dAttribute.value = defaultAttribute();
    dialogParams.value = {
      title: i18n.global.t("CONFIRM"),
      message: i18n.global.t("REGISTER", [textInput.value]),
      button: {
        yes: {
          label: i18n.global.t("Yes"),
        },
        no: {
          label: i18n.global.t("No"),
        },
      },
      callback: async (confirm) => {
        if (confirm) {
          registerPartNo();
        } else {
          refresh();
        }
      },
    };
  }
};

const refresh = () => {
  textInput.value = "";
  selectedOption.value = "";
  additionalFields.value = [];
};

const handleCancel = () => {
  emit("mainPage", true);
};

//Get the NLS
const getLabel = (labelInput) => {
  const label = i18n.global.t(labelInput);
  return label || labelInput;
};

const onSelectChange = (value) => {
  isValueSelected.value = true;
  textInput.value = "";
  stockInput.value = [];
  additionalFields.value = [];
  somevalue.value += 1;

  //additional Value
  const filteredData = NkReferenceNumber.filter(
    (ele) => ele.ItemTypeList.objectType === props.category
  );
  const getIfAddValue = filteredData[0].ItemTypeList.ItemTypes.filter(
    (ele) => ele.typeName === value
  );
  if (getIfAddValue[0].ExtendedAttributes) {
    extendedAttributes.value = getIfAddValue[0].ExtendedAttributes;
  }
  if (getIfAddValue[0].getParentName) {
    getParentNames.value = getIfAddValue[0].getParentName;
    if (props.objectData[0].parentType && props.objectData[0].parentNumber) {
      if (props.objectData[0].parentType === "52") {
        stockInput.value.push(props.objectData[0].parentNumber);
        textInput.value = stockInput.value.join("");
      }else{
        alertMessage.value.showAlert(i18n.global.t("MESSAGE9")).error();
      }
    } else{
      alertMessage.value.showAlert(i18n.global.t("MESSAGE8")).error();
    }
  }
  serialNumberTarget.value = getIfAddValue[0].serialNumberTarget;

  if (getIfAddValue[0].hasOwnProperty("additionalValue")) {
    if (getIfAddValue[0].serialNumberTarget) {
      let start = 0;
      if (getIfAddValue[0].startDigits) {
        start = getIfAddValue[0].startDigits;
      }
      let end = getIfAddValue[0].endDigits;
      if (typeof getIfAddValue[0].additionalValue === "number") {
        stockInput.value[start - 1] =
          getIfAddValue[0].additionalValue.toString();
        textInput.value = stockInput.value.join("");
      }
    }
  }
  const dyanmicFields = filteredData[0].ItemTypeList.ItemTypes.filter(
    (ele) => ele.typeName === value
  );
  //To check the items empty in the JSON file
  const items = dyanmicFields[0].Items;
  if (items.length === 0) {
    alertMessage.value.showAlert(i18n.global.t("MESSAGE6")).error();
  } else {
    additionalFields.value = dyanmicFields[0].Items;
  }
};

const onSelectOptions = (value, field) => {
  let jsonField = JSON.parse(JSON.stringify(field));
  const getNestedObj = jsonField.Options.filter(
    (ele) => ele.optionName === value
  );
  
  if (getNestedObj[0].Items) {
    isValueSelected.value = true;
    let items = getNestedObj[0].Items;
    for (let ele in items) {
      let newItem = items[ele].itemName;
      const exists = additionalFields.value.some(
        (item) => item.itemName === newItem
      );
      if (exists) {
        additionalFields.value = additionalFields.value.filter(
          (item) => item.itemName !== newItem
        );
      }
      additionalFields.value.push(items[ele]);

      if (items[ele].initValue) {
        textInput.value = items[ele].initValue;
      }
    }
  }
  let getAdditionalVal = getNestedObj[0].additionalValue;
  let start = 1;
  let end = 0;
  if (getNestedObj[0].startDigits && getNestedObj[0].endDigits) {
    start = getNestedObj[0].startDigits;
    end = getNestedObj[0].endDigits;
    if (typeof getNestedObj[0].additionalValue === "number") {
      stockInput.value[start - 1] = getNestedObj[0].additionalValue.toString();
      textInput.value = stockInput.value.join("");
    } else {
      stockInput.value[start - 1] = getNestedObj[0].additionalValue;
      textInput.value = stockInput.value.join("");
    }
  } else {
    if (getAdditionalVal) {
      textInput.value = getAdditionalVal;
      if (getParentNames.value) {
        if (
          props.objectData[0].parentType &&
          props.objectData[0].parentNumber
        ) {
          if (props.objectData[0].parentType === "52") {
            stockInput.value=[];
            stockInput.value.push(props.objectData[0].parentNumber);
            stockInput.value.push(getAdditionalVal);
            textInput.value = stockInput.value.join("");
          }
        }

      } else {
        textInput.value = getAdditionalVal;
      }
    }
  }
};

const checkInput = (field) => {
  textInput.value = textInput.value.replace(/[^a-zA-Z0-9]/g, "");
  if (field.initValue) {
    if (
      textInput.value.length < 3 ||
      textInput.value.slice(0, 3) !== field.initValue
    ) {
      textInput.value = field.initValue;
    }
  }
  textInput.value = textInput.value.toUpperCase();
};
//Method to update default attribute values
const defaultAttribute = () => {
  let Result = [];
  let result = DefaultAttribute.filter((ele) =>
    itemStock.value.match(ele.Regex)
  );
  if (result.length > 0) {
    let finalRes = result[0].DefaultAttributes;

    finalRes.forEach((element) => {
      // Determine which attribute value to use
      let value = element.attrValue;
      if (element.attrValue_ch && lang === "zh") {
        value = element.attrValue_ch;
      } else if (element.attrValue_en && lang === "en") {
        value = element.attrValue_en;
      }
      Result.push({ attrName: element.attrName, value: value });
    });
  }
  return Result;
};

//Call the webservice to register sequence number
const registerSeqNo = async () => {
  const serviceUrl = props.SpaceUrl + WebServicesData.NK_REGISTER_SEQ_NO;
  const data = {
    PartPrefix: textInput.value,
  };
  let errorMsg = "";
  let res = null;
  return new Promise((resolve, reject) => {
    const userCallbackOnComplete = function (dataResp) {
      resolve(dataResp);
      res = dataResp;
    };
    const userCallBackOnFailure = function (error, response) {
      if (response !== null && response.status === "error") {
        errorMsg = response.error;
        showAlert(i18n.global.t(errorMsg)).error();
        reject(JSON.stringify(error));
      }
    };
    makeWSCall(
      serviceUrl,
      Constants.POST,
      props.securityContext,
      props.csrf,
      JSON.stringify(data),
      userCallbackOnComplete,
      userCallBackOnFailure
    );
  })
    .then(async () => {
      seqNumber.value = res.seqNumber;
    })
    .catch((e) => {
      console.log(e);
      showAlert(i18n.global.t("GENERAL")).error();
    })
    .finally(() => {
      return res;
    });
};

//Call the webservice to register Part Number
const registerPartNo = async () => {
  const serviceUrl = props.SpaceUrl + WebServicesData.NK_REGISTER_ITEM_NO;
  const data = {
    physicalid: props.objectData[0].id,
    ItemNumber: textInput.value,
    attributes: dAttribute.value,
    extAttributes: extendedAttributes.value,
    objectType: props.category,
  };
  let errorMsg = "";
  let res = null;
  new Promise((resolve, reject) => {
    const userCallbackOnComplete = function (dataResp) {
      resolve(dataResp);
      res = dataResp;
    };
    const userCallBackOnFailure = function (error, response) {
      if (response !== null && response.status === "error") {
        errorMsg = response.error;
        alertMessage.value.showAlert(i18n.global.t("MESSAGE10")).error();
        reject(JSON.stringify(error));
      }
    };
    makeWSCall(
      serviceUrl,
      Constants.POST,
      props.securityContext,
      props.csrf,
      JSON.stringify(data),
      userCallbackOnComplete,
      userCallBackOnFailure
    );
  })
    .then(async () => {
      if (res.status === "Success") {
        dialogParams.value = {
          title: i18n.global.t("CONFIRM"),
          message: i18n.global.t("SUCCESS"),
          button: {
            yes: {
              label: i18n.global.t("OK"),
            },
          },
          callback: async (confirm) => {
            if (confirm) {
              emit("mainPage", true);
            }
          },
        };
      }
      if (res.status === "error") {
        alertMessage.value.showAlert(i18n.global.t("MESSAGE10")).error();
      }
    })
    .catch((e) => {
      console.log(e);
      showAlert(i18n.global.t("GENERAL")).error();
    })
    .finally(() => { });
};

const emit = defineEmits(["mainPage"]);
</script>

<style>
.ItemsClass {
  padding: 10px;
  border: 1px solid black;
  border-radius: 4px;
}

.cardText {
  padding: 20px;
}

.labelField {
  color: #3c3d3f;
  font-weight: bold;
}

.vCard {
  max-width: 600px;
  border: 1px solid lightgrey;
}

.subCard {
  padding: 30px;
}

.vcardTitle {
  color: #368ec4 !important;
}

.vCardHeader {
  background-color: #368ec4;
}

.headline {
  color: white;
  font-weight: bold;
}

.btnNext {
  background-color: #368ec4 !important;
}

.dropdown {
  color: #777c !important;
}
</style>
