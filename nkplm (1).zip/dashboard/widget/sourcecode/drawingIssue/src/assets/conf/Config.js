//Define version -start
const configVersion = '1.0'
//Define version -end
