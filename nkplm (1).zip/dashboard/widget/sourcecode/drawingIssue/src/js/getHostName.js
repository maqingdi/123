/**
 *getHostname.js
 * @Author : DSGS
 * @Description ---.
 */
export const getUrl = () => {
  let finalUrl = "https://";
  finalUrl = finalUrl + window.location.hostname;
  return finalUrl;
};
