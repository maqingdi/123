
let spaceURLForWS='';
let spaceURL = '';
let federatedURL = '';
let dashboardURL ='';
const personDetailsWS = '/resources/modeler/pno/person?current=true&select=preferredcredentials&select=collabspaces';
const csrfWS ='/resources/v1/application/CSRF';

export const get3DSpaceURLWS = function() {
  return new Promise((resolve, _reject) => {
    if (spaceURLForWS.length > 0) {
      resolve(spaceURLForWS);
      return;
    }
    requirejs(['DS/PlatformAPI/PlatformAPI'], function (PlatformAPI) {
      const appConfigs = PlatformAPI.getAllApplicationConfigurations();

      for (const element of appConfigs) {
        if (element['propertyKey'] === 'app.urls.myapps') {
          const url = element['propertyValue'];
          spaceURLForWS = url;
          break;
        }
      }
      resolve(spaceURLForWS);
    });
  });
}

export const loadServiceUrls = function() {
  return new Promise((resolve, reject) => {
    const onComplete = function (data) {
      data = JSON.parse(data);
      const services = data['platforms'][0]['services'];
      services.forEach((item) => {
        if (item.id === 'search') {
          federatedURL = item.url;
        }
        if (item.id === '3ddashboard') {
          dashboardURL = item.url;
        }
        if (item.id === 'space') {
          spaceURL = item.url;
          console.log("spaceURL:",spaceURL);
        }
      });
      resolve(services);
    };
    const urlPromise = get3DSpaceURLWS();
    urlPromise.then((url) => {
      url = url + '/resources/AppsMngt/api/v1/services';
      makeWSCall(url, 'GET', '', {}, onComplete);
    });
  });
}

export const getFederatedURL = function() {
  return new Promise((resolve, reject) => {
    if (federatedURL.length > 0) {
      resolve(federatedURL);
    } else {
      const promise = loadServiceUrls();
      promise.then((data) => {
        resolve(federatedURL);
      });
    }
  });
}

export const getSpaceURLLink = function() {
  return new Promise((resolve, reject) => {
    if (spaceURL.length > 0) {
      resolve(spaceURL); //return;
    } else {
      const promise = loadServiceUrls();
      promise.then(() => {
        resolve(spaceURL);
      });
    }
  });
}
export const makeWSCall = function(
  url,
  httpMethod,
  securityContext,
  ReqBody,
  userCallbackOnComplete,
  userCallbackOnFailure
) {
  const finalUrl1 = url;
  console.log(url);
  requirejs(['DS/WAFData/WAFData'], function (WAFData) {
    const queryobject = {};
    queryobject.method = httpMethod;
    queryobject.timeout = 700000;
    queryobject.type = 'json';
    queryobject.crossOrigin = true;
    queryobject.headers = {
      SecurityContext: securityContext,
      'Content-Type': 'application/json',
    };
    queryobject.data = ReqBody;
    queryobject.responseType = 'json';
    queryobject.onComplete = function (dataResp) {
      this.dataResp2=dataResp;
      userCallbackOnComplete(dataResp);
    };

    queryobject.onFailure = function (error, response, headers) {
      userCallbackOnFailure(error, response, headers);
    };
    WAFData.authenticatedRequest(finalUrl1, queryobject);
  });
}

export const  getSecurityContext = function() {
  return new Promise((resolve, _reject) => {
    get3DSpaceURLWS().then(url => {
      url = url + personDetailsWS;
      let securityContext = ''; // Define securityContext variable
      const onComplete = function (dataResp) {
        if (
          Object.prototype.hasOwnProperty.call(
            dataResp,
            'preferredcredentials'
          )
        ) {
          if (
            Object.prototype.hasOwnProperty.call(
              dataResp.preferredcredentials,
              'role'
            )
          )
            if (
              Object.prototype.hasOwnProperty.call(
                dataResp.preferredcredentials.role,
                'name'
              )
            )
              securityContext =
                dataResp.preferredcredentials.role.name;
          securityContext += '.';
          if (
            Object.prototype.hasOwnProperty.call(
              dataResp.preferredcredentials,
              'organization'
            )
          )
            if (
              Object.prototype.hasOwnProperty.call(
                dataResp.preferredcredentials.organization,
                'name'
              )
            )
              securityContext +=
                dataResp.preferredcredentials.organization.name;
          securityContext += '.';
          if (
            Object.prototype.hasOwnProperty.call(
              dataResp.preferredcredentials,
              'collabspace'
            )
          ) {
            if (
              Object.prototype.hasOwnProperty.call(
                dataResp.preferredcredentials.collabspace,
                'name'
              )
            ) {
              securityContext +=
                dataResp.preferredcredentials.collabspace.name;
            }
          }
        }
        resolve(securityContext); 
      };
      const onFailure = function (error) {
        _reject(error);
      };

      makeWSCall(url, 'GET', '', {}, onComplete, onFailure);
    });
  });
}

export const  getCSRFToken = function() {
  return new Promise((resolve, reject) => {
    get3DSpaceURLWS().then(url => {
      url = url + csrfWS;
      const onComplete = function (dataResp) {
        resolve(dataResp);
      };
      const onFailure = function (errorresponse) {
        console.error('Error Data: ' + errorresponse);
        reject(errorresponse);
      };

      makeWSCall(url, 'GET', '', {}, onComplete, onFailure);
    });
  });
}
