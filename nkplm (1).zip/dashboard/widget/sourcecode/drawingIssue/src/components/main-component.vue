/** *number.vue * @Author : DSGS * @Description ---. * Item Numbering
Application */
<template>
  <v-container max-width="600">
    <v-card class="mx-auto vCard">
      <v-card-title class="vCardHeader">
        <span class="headline">{{ props.objectData[0].name }}</span>
      </v-card-title>
      <v-divider></v-divider>
      <v-card-text class="cardText">
        <v-form @submit.prevent="handleSubmit">
          <v-row>
            <v-col cols="6">
              <v-field-label class="labelField">Release Notes</v-field-label>
            </v-col>
            <v-col cols="6">
              <v-select v-model="releasenotes" item-class="blue-option" :items="optionsReleaseNotes()"
            ></v-select>
            </v-col>            
          </v-row>
          <v-row>
            <v-col cols="6">
              <v-field-label class="labelField">At One's Destination</v-field-label>
            </v-col>
            <v-col cols="6">
              <v-select v-model="destination" item-class="blue-option" :items="optionsDestination()"
            ></v-select>
            </v-col>            
          </v-row>
          <v-row class="mt-4">
            <v-spacer></v-spacer>
            <v-col cols="auto">
              <v-btn type="submit" :disabled="!isOkEnabled" color="#368ec4">{{
                getLabel("Ok")
                }}</v-btn>
              <v-btn color="#fff" @click="handleCancel" class="ml-2">{{
                getLabel("Cancel")
                }}</v-btn>
            </v-col>
          </v-row>
        </v-form>
      </v-card-text>
    </v-card>
   <!-- Confirmation Dialog -->
   <confirmation :params="dialogParams" />
   <showAlert ref="alertMessage" />
  </v-container>
</template>

<script setup>
//Import Components
import WebServicesData from "../assets/constants/webServices.json";
import Constants from "../assets/constants/constants.json";
import NkReferenceNumber from "../assets/constants/NKReferenceNumbering.json";
import confirmation from "./confirmation-dialog.vue";
import showAlert from "./alert-component.vue";
import i18n from "../plugins/i18n.js";
import { makeWSCall } from "../js/api.js";
import { ref, computed, defineEmits, onMounted } from "vue";
import { getSecurityContext, getCSRFToken } from "../js/common";

const props = defineProps({
  objectData: {
    type: Array,
    required: true,
  },
  securityContext: {
    required: true,
  },
  csrf: {
    required: true,
  },
  SpaceUrl: {
    required: true,
  },
  category: {
    required: true,
  },
});
// Reactive variables
const releasenotes = ref("");
const destination = ref("");
const submitted = ref(false);
const alertMessage = ref([]);
const dialogParams = ref([]);

const optionsReleaseNotes = () => {

  console.log("nkreference inside optionsReleaseNotes method : "+NkReferenceNumber[0].releasenotes);

  const jsonDestination = NkReferenceNumber[0].releasenotes;

  let retObject = [];
  for (let key in jsonDestination) {
    if (jsonDestination.hasOwnProperty(key)) {
        const value = jsonDestination[key];
        console.log("value : "+value);
        const label = getLabel(value);
        console.log("label : "+label);
        retObject.push(label);        
    }
  }
  console.log("retObject : "+retObject);
  return retObject;

};

const optionsDestination = () => {
  console.log("nkreference inside optionsDestination method : "+NkReferenceNumber[1].destination);

  const jsonDestination = NkReferenceNumber[1].destination;;

  let retObject = [];

  for (let key in jsonDestination) {
    if (jsonDestination.hasOwnProperty(key)) {
        const value = jsonDestination[key];
        console.log("value : "+value);
        const label = getLabel(value);
        console.log("label : "+label);
        retObject.push(label);        
    }
  }
  console.log("retObject : "+retObject);
  return retObject;

};

onMounted(() => {

});

const isOkEnabled = computed(() => {
  return releasenotes.value && destination.value;
});

// Handle form submission
const handleSubmit = async () => {
  submitted.value = true; 

  const serviceUrl = props.SpaceUrl + WebServicesData.NK_DP_Instruction + props.objectData[0].id;
  console.log("serviceUrl : "+serviceUrl);
  
  console.log("props.objectData[0].id : "+props.objectData[0].id);

    getObjectInfo();
  
};

//Call the webservice to get the Object details
const getObjectInfo = async () => {
  console.log("Inside getObjectInfo");
  var jsonObj = {};
  const typeObj = props.objectData[0].type;
  if (typeObj === Constants.VPMREFERENCE) {
    jsonObj =
    {
      task : {
        functionId : "issueDrawing",
        role: "user",
        retry: "0",
        userInfo : {
          name: props.objectData[0].User_Name,
          email: props.objectData[0].Email_Address,
        },
        parameters : {
          type: props.objectData[0].Drawing.type,
          name: props.objectData[0].Drawing.name,
          revision: props.objectData[0].Drawing.revision,
          Title: props.objectData[0].Drawing.Title,
          partsNo: props.objectData[0].Drawing.DocItemNumber,
          version: props.objectData[0].Drawing.NK_USER_REVISION,
          label: releasenotes.value,
          plant: destination.value,
        },
      }
    };
  } else if (typeObj === Constants.DRAWING_PRINT || typeObj === Constants.DOCUMENT) {
    jsonObj =
    {
      task : {
        functionId : "issueDrawing",
        role: "user",
        retry: "0",
        userInfo : {
          name: props.objectData[0].User_Name,
          email: props.objectData[0].Email_Address,
        },
        parameters : {
          type: props.objectData[0].type,
          name: props.objectData[0].name,
          revision: props.objectData[0].revision,
          Title: props.objectData[0].Title,
          partsNo: props.objectData[0].DocItemNumber,
          version: props.objectData[0].NK_USER_REVISION,
          label: releasenotes.value,
          plant: destination.value,
        },
      }
    };
  }
  console.log("jsonObj : "+jsonObj);
  for (let key in jsonObj) {
    if (jsonObj.hasOwnProperty(key)) {
        const value = jsonObj[key];
        console.log(key, value);
    }
  }

  const serviceUrl = props.SpaceUrl + WebServicesData.NK_DP_Read;
  let errorMsg = "";
  let res = null;
  new Promise((resolve, reject) => {
    const userCallbackOnComplete = function (dataResp) {
      resolve(dataResp);
      res = dataResp;
    };
    const userCallBackOnFailure = function (error, response) {
      if (response !== null && response.status === "error") {
        errorMsg = response.error;
        alertMessage.value.showAlert(i18n.global.t("MESSAGE10")).error();
        reject(JSON.stringify(error));
      }
    };
    makeWSCall(
      serviceUrl,
      Constants.GET,
      props.securityContext,
      props.csrf,
      jsonObj,
      userCallbackOnComplete,
      userCallBackOnFailure
    );
  })
    .then(async () => {
      console.log("res.status : "+res.status);
      if (res.status === "Success" || res.status === 200) {
        console.log("Inside iff ");
        console.log("props.objectData[0].name : "+props.objectData[0].name);
        dialogParams.value = {
          title: i18n.global.t("CONFIRM"),
          //message: i18n.global.t("SUCCESS"),
          message: i18n.global.t("CompleteMessage", [props.objectData[0].name]),
          button: {
            yes: {
              label: i18n.global.t("OK"),
            },
          },
          callback: async (confirm) => {
            console.log("confirm : "+confirm);
            if (confirm) {
              console.log("Inside confirm : ");
              emit("mainPage", true);
            }
          },
        };
      }
      if (res.status === "error") {
        alertMessage.value.showAlert(i18n.global.t("MESSAGE10")).error();
      }
    })
    .catch((e) => {
      console.log(e);
      showAlert(i18n.global.t("GENERAL")).error();
    })
    .finally(() => { });
};

const handleCancel = () => {
  emit("mainPage", true);
};

//Get the NLS
const getLabel = (labelInput) => {
  const label = i18n.global.t(labelInput);
  return label || labelInput;
};

const emit = defineEmits(["mainPage"]);
</script>

<style>
.ItemsClass {
  padding: 10px;
  border: 1px solid black;
  border-radius: 4px;
}

.cardText {
  padding: 20px;
}

.labelField {
  color: #3c3d3f;
  font-weight: bold;
}

.vCard {
  max-width: 600px;
  border: 1px solid lightgrey;
}

.subCard {
  padding: 30px;
}

.vcardTitle {
  color: #368ec4 !important;
}

.vCardHeader {
  background-color: #368ec4;
}

.headline {
  color: white;
  font-weight: bold;
}

.btnNext {
  background-color: #368ec4 !important;
}

.dropdown {
  color: #777c !important;
}
</style>
