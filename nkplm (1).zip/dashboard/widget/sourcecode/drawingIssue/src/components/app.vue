<template>
  <v-app class="main">
    <showAlert ref="alertMessage" />
    <v-content class="content">
      <dropPage v-if="showDrop" @dropData="dropData($event)"> </dropPage>
      <maincomponent
        v-if="!showDrop"
        :objectData="respData"
        :securityContext="securityContext"
        :csrf="csrf"
        :SpaceUrl="SpaceUrl"
        @mainPage="backtoMainPage($event)"
      ></maincomponent>
    </v-content>
    <confirmation :params="dialogParams" />
  </v-app>
</template>

<script>
//Import Components
import dropPage from "./drop-component.vue";
import maincomponent from "./main-component.vue";
import WebServicesData from "../assets/constants/webServices.json";
import Constants from "../assets/constants/constants.json";
import { getSecurityContext, getCSRFToken } from "../js/common";
import { getUrl } from "../js/getHostName.js";
import confirmation from "./confirmation-dialog.vue";
import showAlert from "./alert-component.vue";
import i18n from "../plugins/i18n.js";
import { makeWSCall } from "../js/api.js";

export default {
  components: {
    dropPage,
    showAlert,
    maincomponent,
    confirmation,
  },

  //Define data here
  data() {
    return {
      Drop: false,
      object: [],
      objids: [],
      respData: [],
      dropCount: 0,
      dialogParams: {},
      WebServices: "",
      ConstantValues: "",
      SpaceUrl: "",
      showDrop: true,
      securityContext: "",
      csrf: "",
      rev: "",
    };
  },
  //Call the methods before the component mount
  beforeMount() {
    this.WebServices = WebServicesData;
    this.ConstantValues = Constants;
    this.setPreferences(this.ConstantValues.langPreferences);
  },
  //Call the methods after the component created
  created() {
    this.getUserSecurityContext();
    this.SpaceUrl = getUrl();
  },
  //Define methods here
  methods: {
    backtoMainPage(value) {
      console.log("Inside backtoMainPage");
      if (value) this.showDrop = true;
    },
    //Get the object id
    async dropData(Data) {
      console.log("Inside dropdata");
      this.object = Data;
      const info = Data;
      console.log("info : "+info);
      this.dropCount = this.object.data.items.length;
      console.log("this.dropCount : "+this.dropCount);
      if (this.dropCount === 1) {
        if (this.isValidObjectType(Data)) {
          this.objids.push(this.object.data.items[0].objectId);
          this.rev = await this.ObjectResponse(); //call webservices
        } else {
          this.$refs.alertMessage.showAlert(i18n.global.t("MESSAGE1")).error();
        }
      } else {
        this.$refs.alertMessage.showAlert(i18n.global.t("MESSAGE2")).error();
      }
    },
    //Calculate dropdown count
    getdropCount({ x, y }) {
      this.dropCount = x;
      if (y) {
        this.Drop = true;
      }
    },

    //Get Security context
    getUserSecurityContext() {
      const scPromise = getSecurityContext();
      scPromise.then((sc) => {
        this.securityContext = sc;
      });
      //Get csrf token
      const csrfPromise = getCSRFToken();
      csrfPromise.then((res) => {
        this.csrf = res.csrf.value;
      });
    },
    //validating the Object Type
    isValidObjectType(info) {
      // Split the NK_TYPE by commas and check if objectType exists in the resulting array
      const allowedTypes = this.ConstantValues.NK_TYPE.split(",");
      const currentObjectType = info.data.items[0].objectType;

      console.log("allowedTypes : "+allowedTypes);
      console.log("currentObjectType : "+currentObjectType);

      return allowedTypes.includes(currentObjectType);
    },

    //Get the NLS
    getLabel(labelInput) {
      const label = i18n.global.t(labelInput);
      return label || labelInput;
    },

    //Call the webservice to read the info
    async ObjectResponse() {
      let that = this;
      console.log("this.objids : "+this.objids);
      const serviceUrl =
        this.SpaceUrl + this.WebServices.NK_DP_Instruction + this.objids;
      console.log("serviceUrl : "+serviceUrl);
      let errorMsg = "";
      let res = null;
      new Promise((resolve, reject) => {
        const userCallbackOnComplete = function (dataResp) {
          resolve(dataResp);
          res = dataResp;
        };
        const userCallBackOnFailure = function (error, response) {
          if (response !== null && response.status === "error") {
            errorMsg = response.error;
            this.$refs.alertMessage.showAlert(i18n.global.t(errorMsg)).error();
            reject(JSON.stringify(error));
          }
        };
        makeWSCall(
          serviceUrl,
          this.ConstantValues.GET,
          this.securityContext,
          this.csrf,
          "",
          userCallbackOnComplete,
          userCallBackOnFailure
        );
      })
        .then(async () => {
          console.log("res : "+res);
          if(null != res.data && undefined != res.data) {
            console.log("res.data : "+res.data);
            const state = res.data.current;
            const itemNumber = res.data.ItemNumber;
            const docitemNumber = res.data.DocItemNumber;
            const nameObj = res.data.name;
            const typeObj = res.data.type;
            this.respData=[];
            console.log("state : "+state);
            console.log("itemNumber : "+itemNumber);
            console.log("docitemNumber : "+docitemNumber);
            console.log("typeObj : "+typeObj);
            if (typeObj === this.ConstantValues.VPMREFERENCE) {
              if (state === this.ConstantValues.STATE_RELEASED) {
                this.respData.push(res.data);
                if (itemNumber) {
                  const drawingAvailable = res.data.Drawing_Print_Available;
                  console.log("drawingAvailable : "+drawingAvailable);
                  console.log("this.ConstantValues.Yes : "+this.ConstantValues.Yes);
                  if (drawingAvailable === this.ConstantValues.Yes) {
                    const pdfAvailable = res.data.PDF_Available;
                    console.log("pdfAvailable : "+pdfAvailable);
                    if (pdfAvailable === this.ConstantValues.Yes) {
                      this.showDrop = false;
                    } else {
                        this.$refs.alertMessage
                      .showAlert(i18n.global.t("PDFApprovalMarkMissed"))
                      .error();
                    }
                  } else {
                      this.$refs.alertMessage
                      .showAlert(i18n.global.t("PhysicalProductDocumentMissed"))
                      .error();
                  }                  
                } else {
                  this.$refs.alertMessage
                    .showAlert(i18n.global.t("PhysicalProductItemNumberMissed"))
                    .error();
                }
              } else {
                this.$refs.alertMessage
                  .showAlert(i18n.global.t("ObjectNotReleased"))
                  .error();
              }
            } else if (typeObj === this.ConstantValues.DRAWING_PRINT || typeObj === this.ConstantValues.DOCUMENT) {
              if (state === this.ConstantValues.STATE_RELEASE) {
                this.respData.push(res.data);
                if (docitemNumber) {
                  this.showDrop = false;
                } else {
                  this.$refs.alertMessage
                    .showAlert(i18n.global.t("DrawingPrintItemNumberMissed"))
                    .error();
                }
              } else {
                this.$refs.alertMessage
                  .showAlert(i18n.global.t("ObjectNotReleased"))
                  .error();
              }
            }           
        } else {
          console.log("Data not returned from the webservice and got the data as below");
          for (let key in res) {
              if (exampleObj.hasOwnProperty(key)) {
                  const value = exampleObj[key];
                  console.log(key, value);
              }
          }
          this.showDrop = false;
        }
        })
        .catch((e) => {
          console.log(e);
          this.$refs.alertMessage.showAlert(i18n.global.t("GENERAL")).error();
        })
        .finally(() => {
          this.objids = [];
        });
      this.objids = [];
      this.dropCount = 0;
      this.dropFlag = false;
    },

    //Set Langugage Preference for selections
    setPreferences(Options) {
      widget.addPreference({
        name: "enable-language",
        type: "list",
        label: "Select Language",
        defaultValue: "en",
        options: Options,
      });
    },
  },
};
</script>

<style>
.v-app {
  overflow: hidden;
}
#title {
  font-family: "Arial", sans-serif;
}
#footer {
  align-items: first baseline;
  max-height: 10%;
}
.main {
  flex: 0 0 0;
  height: auto;
  max-height: fit-content;
}
.content {
  height: auto;
  max-height: fit-content;
}
.moduleWrapper {
  overflow: auto !important;
}
</style>
