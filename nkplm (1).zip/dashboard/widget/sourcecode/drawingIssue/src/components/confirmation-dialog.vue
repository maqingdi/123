<template>
  <v-dialog v-model="showDialog" persistent max-width="500">
    <v-card>
      <v-layout justify-end class="pg-card-title-layout card-border-bottom">
        <v-card-title class="pg-card-title text">
          {{ dialog.title }}
        </v-card-title>
        <v-spacer></v-spacer>
        <v-btn
          icon
          variant="text"
          :height="defaultOptions.size"
          :width="defaultOptions.size"
          class="ma-1 mt-3"
          @click="showDialog = !showDialog"
        >
          <mdi-icon-renderer :icon="'mdi-close'" :size="defaultOptions.size" :color="'#737373'" />
        </v-btn>
      </v-layout>

      <v-card-text class="pg-v-card-text">
        <span v-if="dialog.renderMsgAsHTML" v-html="dialog.message"></span>
        <template v-else>{{ dialog.message }}</template>
      </v-card-text>

      <v-card-actions class="pt-3 bg-grey-lighten-2">
        <v-spacer></v-spacer>
        <v-btn
          v-if="dialog.button.yes"
          variant="flat"
          @click.stop="(e) => handleClickButton(e, true)"
          :color="dialog.button.yes.color ? dialog.button.yes.color : defaultOptions.primaryActionBase"
          class="ma-1"
          style="color: white"
        >
          {{ dialog.button.yes.label }}
        </v-btn>
        <v-btn
          variant="flat"
          v-if="dialog.button.no"
          @click.stop="(e) => handleClickButton(e, false)"
          :color="dialog.button.no.color ? dialog.button.no.color : defaultOptions.errorAactionBase"
          class="ma-1"
        >
          {{ dialog.button.no.label }}
        </v-btn>
      </v-card-actions>
    </v-card>
  </v-dialog>
</template>
<style>
.card-border-bottom {
  border-bottom: 1px solid #c7c7c7;
}
.pg-v-card-text {
  font-size: 14px !important;
  color: rgba(0, 0, 0, 0.6);
}
.pg-card-title-layout {
  height: 48px;
  padding: 0px 12px 0px 5px;
}
.pg-card-title {
  font-size: 15px;
  font-weight: bold;
}
</style>

<script>
//import MdiIconRenderer from "../mdi-icons/mdi-icon-renderer.vue";
export default {
  components: {
    
  },
  props: {
    params: { type: Object },
  },
  data: function () {
    return {
      showDialog: false,
      dialog: {
        title: "",
        message: "",
        button: {},
        renderMsgAsHTML: false,
      },
      defaultOptions: {
        size: "24",
        primaryActionBase: "#1976d2",
        errorAactionBase: "#BDBDBD",
      },
    };
  },
  watch: {
    params: {
      handler(newValue) {
        const instance = this;
        this.resetState();
        this.showDialog = newValue;
        Object.entries(instance.params).forEach((param) => {
          if (typeof param[1] === typeof instance.dialog[param[0]]) {
            instance.dialog[param[0]] = param[1];
          }
        });
      },
      deep: true,
    },
  },
  mounted: function () {},
  methods: {
    resetState: function () {
      this.dialog = {
        title: "",
        message: "",
        renderMsgAsHTML: false,
        button: {},
        callback: () => {},
      };
    },
    handleClickButton: function ({ target }, confirm) {
      this.showDialog = false;
      // callback
      if (this.params.callback) {
        this.params.callback(confirm);
      }
    },
  },
};
</script>
