/** *drop-zone.vue * @Author : DSGS * @Description ---. * Item Numbering
Application */
<template>
  <v-app class="maindrop">
    <v-div
      id="DropZone"
      ref="dragAndDrop"
      class="drop-container"
      :disabled="dropCount > 0"
    >
      <ul id="text" class="drop_class">
        {{
          getLabel("DropZone")
        }}
      </ul>
      <img alt="drop here." :src="image" />
    </v-div>
  </v-app>
</template>
<script>
import image from "../assets/images/drop.PNG";
import i18n from "../plugins/i18n.js";

export default {
  components: {},
  data: function () {
    return {
      image,
      name: "",
    };
  },
  //Get the dropped object info
  mounted() {
    const dropElement = this.$refs["dragAndDrop"];
    const that = this;
    requirejs(
      ["DS/DataDragAndDrop/DataDragAndDrop"],
      function (DataDragAndDrop) {
        DataDragAndDrop.droppable(dropElement, {
          drop: function (data, $event) {
            const object = JSON.parse(data);
            that.$emit("dropData", object);
          },
        });
      }
    );
  },

  methods: {
    //Get the NLS
    getLabel(labelInput) {
      const label = i18n.global.t(labelInput);
      return label || labelInput;
    },
  },
};
</script>
<style scoped>
.drop-container {
  margin-top: auto;
  margin-bottom: auto;
  margin-left: 80px;
  margin-right: 80px;
  padding: 20px;
  text-align: center;
  min-height: 200px;
  min-width: 400px;
  background-color: white;
  border-radius: 12px;
}
.maindrop {
  background-color: white;
}
.drop_class {
  margin-left: 0% !important;
}
</style>
