// Import all components
import { createApp } from 'vue';
import App from './components/app.vue';
import i18n from './plugins/i18n.js';
import { initWidget } from './lib/widget.js';
import config from './assets/conf/Config.js';
import './assets/css/style.css';

// Import Vuetify
import 'vuetify/styles';
import { createVuetify } from 'vuetify';
import { aliases, mdi } from 'vuetify/iconsets/mdi-svg';

const vuetify = createVuetify({
  icons: {
    defaultSet: 'mdi',
    aliases,
    sets: {
      mdi,
    },
  }
});

//Get and set browser language.
i18n.global.locale = navigator.language;
const app = createApp(App);

const widgetConfig = {
  version: config,
  fileName: 'DPInstructions.json',
  callBack: start,
};

//Initialise the widget
initWidget( widget =>{
    widget.addEvent(
      'onLoad',
      () => {
        start();
        widget.setTitle('');
      });
  //Refresh the widget
    widget.addEvent(
      'onRefresh',
      () => {
        window.location.reload();
      });
  });

//Start the widget
function start() {
  app.use(vuetify)
  .use(i18n)
  .mount('app');
}
