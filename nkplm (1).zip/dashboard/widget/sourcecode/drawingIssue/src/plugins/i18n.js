import messages from "./../assets/nls/NKLanguageRefNum.json";
import { createI18n } from "vue-i18n";
//const browserLocale = navigator.language;
const lang = widget.getValue("enable-language");
export default createI18n({
  legacy: false,
  locale: lang,
  fallbackLocale: lang,
  messages,
});
