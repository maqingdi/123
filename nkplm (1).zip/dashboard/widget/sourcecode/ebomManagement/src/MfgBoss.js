// Import all components
import { createApp } from 'vue';
import App from './components/app.vue';
import i18n from './plugins/i18n.js';
import { initWidget } from './lib/widget.js';
import config from './assets/conf/Config.js';

import { createVuetify } from 'vuetify';
import { aliases, mdi } from 'vuetify/iconsets/mdi-svg';

import PrimeVue from "primevue/config";
import "/node_modules/primeflex/primeflex.css";
import "primevue/resources/themes/lara-light-blue/theme.css"; //theme
import "primevue/resources/primevue.min.css"; //core CSS
import "primeicons/primeicons.css"; //icons

import TreeTable from "primevue/treetable";
import Column from "primevue/column";
import Checkbox from "primevue/checkbox";
import ContextMenu from 'primevue/contextmenu';
import "@mdi/font/css/materialdesignicons.css";

const vuetify = createVuetify();

//Get and set browser language.
i18n.global.locale = navigator.language;
const app = createApp(App);

const widgetConfig = {
  version: config,
  fileName: 'MfgBoss.json',
  callBack: start,
};

//Initialise the widget
initWidget( widget =>{
    widget.addEvent(
      'onLoad',
      () => {
        start();
        widget.setTitle('');
      });
  //Refresh the widget
    widget.addEvent(
      'onRefresh',
      () => {
        window.location.reload();
      });
  });

//Start the widget
function start() {
  app.use(vuetify);
  app.use(i18n);
  app.use(PrimeVue);
  app.component("TreeTable", TreeTable);
  app.component("Column", Column);
  app.component("ContextMenu", ContextMenu);
  app.component("Checkbox", Checkbox);
  app.mount('app');
}
