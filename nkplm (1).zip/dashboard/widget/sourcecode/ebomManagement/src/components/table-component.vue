<template>
  <showAlert ref="alertMessage" />
  <v-app-bar app style="background-color: #368ec4">
    <v-toolbar-title
      style="font-weight: bold !important; font-size: 16px; color: white"
      >{{ getLabel("Engineering_Release_for_Half_Product") }}</v-toolbar-title
    >
  </v-app-bar>
  <v-row>
    <v-col cols="12">
      <ContextMenu
        v-if="isItemSelected"
        :model="items"
        ref="contextMenu"
        appendTo="body"
        class="context_menu"
        @hide="isItemSelected === false"
      />
      <div class="table-container">
        <TreeTable
          id="dataTable"
          v-model:selectionKeys="selectedKey"
          :reorderableColumns="true"
          class="pinned-tree-table"
          :loading="loading"
          v-model:expandedKeys="expandedKeys"
          :value="rowData"
          contextMenu
          @contextmenu.prevent="onRowContextMenu"
          editMode="cell"
          @cell-edit-complete="onCellEditComplete"
          selectionMode="single"
          :metaKeySelection="false"
          :filters="filters"
          scrollable
          scrollHeight="78vh"
          scrollDirection="both"
          removableSort
          filterMode="lenient"
          paginator
          :rows="rowsPerPage"
          :totalRecords="nodes.length"
          :resizableColumns="true"
          columnResizeMode="expand"
          currentPageReportTemplate="{first} to {last} of {totalRecords} entries"
          style="width: 100%"
          @drop="onCellDrop"
          @dragover.prevent
        >
          <Column
            headerClass="custom-header"
            style="width: 40px; min-width: 40px"
          >
            <template #body="slotProp">
              <Checkbox
                v-model="selectedKey[slotProp.node.key]"
                binary
                @change="onSelectionChange(slotProp.node)"
              />
            </template>
          </Column>

          <Column
            :expander="true"
            headerClass="custom-header"
            style="width: 40px; min-width: 40px"
          >
            <template #body="slotProp">
              <v-icon>{{ getIconname(slotProp.node) }}</v-icon>
            </template>
          </Column>

          <Column
            header=""
            headerClass="custom-header"
            style="width: 40px; text-align: center"
          >
            <template #body="slotProps">
              <div>
                <img
                  v-if="slotProps.node.data.type"
                  :src="getImage(slotProps.node.data.type)"
                  alt="Product Icon"
                  class="image-animated"
                  style="width: 28px; height: 22px"
                />
              </div>
            </template>
          </Column>

          <Column
            v-for="(col, index) in selectedColumns"
            :key="col.field"
            :field="col.field"
            :header="getLabel(col.header)"
            :style="{ width: col.width }"
            class="wrap-text"
            :pinned="col.pinned ? col.pinned : false"
            headerClass="custom-header"
            sortable
          >
          </Column>
          <Column header="" style="width: 0px"></Column>
        </TreeTable>
        <div class="dropLabel" v-if="showDropLabel">
          {{ getLabel("drop_here") }}
        </div>
      </div>
    </v-col>
  </v-row>
</template>

<script setup>
import { ref, computed, onMounted } from "vue";
import TreeTable from "primevue/treetable";
import Column from "primevue/column";
import ContextMenu from "primevue/contextmenu";
import i18n from "../plugins/i18n.js";
import Constants from "../assets/constants/constants.json";
import columnsData from "../assets/constants/headers.json";
import "primeicons/primeicons.css";
import { getSecurityContext, getCSRFToken } from "../js/common";
import WebServicesData from "../assets/constants/webServices.json";
import { makeWSCall } from "../js/api.js";
import showAlert from "./alert-component.vue";

const nodeItems = ref([
  {
    key: "1",
    data: {
      EIN: "Physical Product00000516",
      title: "prd-17970019-00000516",
      id: "5682BB1300000EC466B9B5A4000BD7E5",
      revisionId: "5682BB1300000EC466B9B5A4000BD7E5",
      revisionType: "VPMReference",
      revision: "A",
      maturityState: "IN_WORK",
      owner: "widget-tester",
    },
    children: [
      {
        key: "1-1",
        data: {
          title: "prd-17970019-00000517",
          EIN: "Physical Product00000517",
          id: "5682BB1300000EC466B9B5B30011B7FD",
          revisionId: "5682BB1300000EC466B9B5B30011B7FD",
          revisionType: "VPMReference",
          revision: "A",
          maturityState: "IN_WORK",
          owner: "widget-tester",
        },
        children: [],
      },
    ],
  },
]);

const selectedNode = ref(null);
const columns = ref(columnsData);
const selectedColumns = ref(columns.value);
const nodes = ref([]);
const selectedKey = ref({});
const filters = ref({});
const expandedKeys = ref({});
const loading = ref(false);
const rowsPerPageOptions = ref([
  { label: "5", value: 5 },
  { label: "10", value: 10 },
  { label: "15", value: 15 },
  { label: "All", value: nodes.value.length },
]);
const rowsPerPage = ref(rowsPerPageOptions.value[0].value);
const isItemSelected = ref(false);
const showDropLabel = ref(true);
const csrf = ref(null);
const securityCtx = ref(null);
const oIds = ref([]);
const oIdTypes = ref([]);
const space3DURL = ref(null);
const alertMessage = ref("");
const rowData = ref([]);
const selectedMap = ref({});

onMounted(() => {
  getUserSecurityContext();
  get3DSpaceServiceURL();
});

const get3DSpaceServiceURL = () => {
  let URL = "";
  return new Promise((resolve, _reject) => {
    requirejs(
      ["DS/i3DXCompassServices/i3DXCompassServices"],
      function (i3DXCompassServices) {
        i3DXCompassServices.getServiceUrl({
          serviceName: "3DSpace",
          onComplete: function (URLResult) {
            space3DURL.value = URLResult[0].url;
            resolve(space3DURL.value);
          },
          onFailure: function (error) {
            _reject(error);
          },
        });
      }
    );
  });
};

//Get Security context
const getUserSecurityContext = () => {
  const scPromise = getSecurityContext();
  scPromise.then((sc) => {
    securityCtx.value = sc;
  });
  //Get csrf token
  const csrfPromise = getCSRFToken();
  csrfPromise.then((res) => {
    csrf.value = res.csrf.value;
  });
};

const getImage = (type) => {
  if (type === "CreateAssembly") {
    return (
      space3DURL.value +
      "/snresources/images/icons/large/I_InsertLotCreateAssemblyProcess108x144.png"
    );
  } else if (type === "Provide") {
    return (
      space3DURL.value +
      "/snresources/images/icons/large/I_InsertLotProvideProcess108x144.png"
    );
  } else {
    return (
      space3DURL.value +
      "/snresources/images/icons/large/I_InsertLotCreateAssemblyProcess108x144.png"
    );
  }
};

const onCellDrop = async (event) => {
  loading.value = true;
  const dataText = JSON.parse(event.dataTransfer.getData("Text"));
  for (const val of dataText.data.items) {
    oIds.value.push(val.objectId);
    oIdTypes.value.push(val.objectType);
  }
  if (isValidObjectType(oIdTypes.value)) {
    const serviceURL =
      space3DURL.value + WebServicesData.NK_BOSS_ITEM_INFO + oIds.value;
    let errorMsg = "";
    let res = null;
    new Promise((resolve, reject) => {
      const userCallbackOnComplete = function (dataResp) {
        resolve(dataResp);
        res = dataResp;
        console.log("res:", res);
      };
      const userCallBackOnFailure = function (error, response) {
        if (response !== null && response.status === "error") {
          errorMsg = response.error;
          alertMessage.value.showAlert(i18n.global.t(errorMsg)).error();
          reject(JSON.stringify(error));
        }
      };
      makeWSCall(
        serviceURL,
        Constants.GET,
        securityCtx.value,
        csrf.value,
        "",
        userCallbackOnComplete,
        userCallBackOnFailure
      );
    })
      .then(async () => {
        const state = res.data.current;
        console.log("state******", state);
        if (state === Constants.STATE_IN_WORK) {
          showDropLabel.value = false;
          let droppedId = oIds.value;
          //let droppedId = "5682BB1300004D34671F5D210018C8C5";
          console.log("droppedId*********", droppedId);
          getMBOMDetails(droppedId);
        } else {
          alertMessage.value.showAlert(i18n.global.t("MESSAGE3")).error();
        }
      })
      .catch((e) => {
        alertMessage.value.showAlert(i18n.global.t("MESSAGE1")).error();
      })
      .finally(() => {
        oIds.value = [];
        oIdTypes.value = [];
      });
  } else {
    alertMessage.value.showAlert(i18n.global.t("MESSAGE1")).error();
    oIds.value = [];
    oIdTypes.value = [];
  }
  loading.value = false;
};

const getMBOMDetails = async (droppedId) => {
  let serviceURL =
    space3DURL.value + WebServicesData.NK_BOSS_MBOM_ITEMS + droppedId;
  console.log("serviceURL*********", serviceURL);
  const details = await fetch(serviceURL, {
    credentials: "include",
    headers: {
      SecurityContext: securityCtx.value,
      Accept: "application/json",
      "Content-Type": "application/json",
      "Accept-Language": widget.lang,
      ENO_CSRF_TOKEN: csrf.value,
    },
  });
  console.log("details*********", details);
  const jsonString = await details.json();
  console.log("jsonString*********", jsonString);
  //const response = JSON.parse(jsonString);
  //console.log('response*********',response);
  const input = jsonString.data;
  rowData.value = convertData(input);
  console.log("rowData.value***************", rowData.value);
};

const convertData = (data) => {
  const output = [];
  const map = {};
  let parentItemName = "";
  let parentLevel = "";
  data.forEach((item) => {
    const level = item.level;
    if (level === "0") {
      parentItemName = item.name;
      parentLevel = "1";
      const entry = {
        key: parentLevel,
        data: item,
        children: [],
      };
      const exclude = data.filter((item) => item.level !== "0");
      console.log("exclude***************", exclude);
      const Childrens = exclude.filter((item) => item.from === parentItemName);
      console.log("Childrens***************", Childrens);
      for (let i = 0; i < Childrens.length; i++) {
        console.log("Childrens[i]***************", Childrens[i]);
        let child = {
          key: parentLevel + "-" + (i + 1).toString(),
          data: Childrens[i],
          children: [],
        };

        const ifChildrens = exclude.filter(
          (item) => Childrens[i].name === item.from
        );
        for (let j = 0; j < ifChildrens.length; j++) {
          let child2 = {
            key:
              parentLevel + "-" + (i + 1).toString() + "-" + (j + 1).toString(),
            data: ifChildrens[j],
            children: [],
          };
          child.children.push(child2);
        }
        entry.children.push(child);
      }
      output.push(entry);
    }
  });

  return output;
};

const isValidObjectType = (typeList) => {
  let bCheck = false;
  const allowedTypes = Constants.Allowed_TYPE.split(",");
  for (let type of typeList) {
    if (allowedTypes.includes(type)) {
      bCheck = true;
    } else {
      bCheck = false;
      break;
    }
  }
  return bCheck;
};

const getLabel = (labelInput) => {
  const label = i18n.global.t(labelInput);
  return label || labelInput;
};

const items = ref([
  {
    label: getLabel("semi_finished_product_creation"),
    icon: "pi pi-angle-right",
    command: () => SemiFinishedProdCreation(),
  },

  {
    label: getLabel("remove_objects_from_view"),
    icon: "pi pi-angle-right",
    command: () => removeObject(selectedNode.value),
  },
]);

// const viewNode = (event) => {
//   console.log('viewNode**************', event);
//   contextMenu.value.hide(event);
// }

const getSelectedList = () => {
  const values = [];
  const selectedItems = selectedMap.value;
  for (let item in selectedItems) {
    let data = selectedItems[item];
    let value = {
      id: data.id,
      type: data.type,
      name: data.name,
      revision: data.revision,
    };
    values.push(value);
  }
  return values;
};

const SemiFinishedProdCreation = () => {
  const getValues = getSelectedList();
  console.log("get Values**** :", getValues);
};

// const autoBossLinkage = () => {
//   const getValues = getSelectedList();
//   console.log('getValues*********', getValues);

// }

// const changeBossLinkage = () => {
//   const getValues = getSelectedList();
//   console.log('getValues*********', getValues);
// }

// const outProcessItemNumber = () => {
//   const getValues = getSelectedList();
//   console.log('getValues*********', getValues);
// }

// const changeOutSourceProcess = () => {
//   const getValues = getSelectedList();
//   console.log('getValues*********', getValues);
// }

const removeObject = () => {
  const getValues = getSelectedList();
  console.log("getValues*********", getValues);
};


const onSelectionChange = (event) => {
  console.log("selection event************", event);
  console.log("selection event.data************", event.data);
  if (event) {
    const key = event.data.id;
    if (selectedMap.value[key]) {
      delete selectedMap.value[key];
    } else {
      selectedMap.value[key] = event.data;
    }
    console.log("selection selectedMap************", selectedMap.value);
  }

  if (Object.keys(selectedMap.value).length === 0) {
    isItemSelected.value = false;
  } else {
    isItemSelected.value = true;
  }
};

const contextMenu = ref(null);

const onRowContextMenu = (event) => {
  //selectedNode.value = event;
  event.preventDefault(); // Prevent default context menu
  contextMenu.value.show(event); // Show the context menu
};

const getIconname = (rowData) => {
  if (rowData.children && rowData.children.length > 0) {
    return "mdi-plus-box";
  } else {
    return "mdi-minus-box";
  }
};
</script>

<style>
@keyframes fadeInScaleRotate {
  0% {
    opacity: 0;
    transform: scale(0.5) rotate(-180deg);
  }

  50% {
    opacity: 0.5;
    transform: scale(1.1) rotate(-90deg);
  }

  100% {
    opacity: 1;
    transform: scale(1) rotate(0);
  }
}

.image-animated {
  opacity: 0;
  transform: scale(0.5) rotate(-180deg);
  animation: fadeInScaleRotate 1s ease-in-out forwards;
}

.image-fade-in.visible {
  opacity: 1;
}

.table-container {
  background-color: #f9f9f9;
  position: relative;
  /* Rounded corners */
  box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1); /* Subtle shadow for depth */
  overflow: hidden; /* Prevents overflow */
}

.p-button-sm {
  margin: 5px;
  border: 1px solid;
  background-color: blanchedalmond;
}

.p-dialog {
  max-height: 80vh;
  overflow-y: auto;
}

.custom-header {
  border: 0.5px solid #ddd;
  background-color: #005685;
  text-align: center;
  color: white;
  font-weight: bold;
  padding: 12px; /* Increased padding for better spacing */
  transition: background-color 0.3s; /* Smooth transition */
}

.table-container th {
  border-bottom: 2px solid #ddd;
}

.table-container th,
.table-container td {
  padding: 12px; /* Increased padding for better spacing */
  border-bottom: 2px solid #ddd;
  text-align: left; /* Left-align text for better readability */
  transition: background-color 0.2s; /* Smooth background transition */
}

/* start */
/* .table-container thead>tr>th {
  position: relative;
}

.table-container thead>tr>th:nth-child(1),
.table-container thead>tr>th:nth-child(2),
.table-container thead>tr>th:nth-child(3) {
  position: sticky !important;
  z-index: 10 !important;
  left: 0;
}

.table-container thead>tr>th:nth-child(2) {
  left: 60px;
}

.table-container thead>tr>th:nth-child(3) {
  left: 100px;
}

.table-container tbody>tr>td {
  position: relative;
}

.table-container tbody>tr>td:nth-child(1),
.table-container tbody>tr>td:nth-child(2),
.table-container tbody>tr>td:nth-child(3) {
  position: sticky;
  left: 0;
  background: white;
  z-index: 5 !important;
  ;
}

.table-container tbody>tr>td:nth-child(2) {
  left: 60px;
}

.table-container tbody>tr>td:nth-child(3) {
  left: 100px;
} */

/* end */

.table-container th:last-child,
.table-container td:last-child {
  border-right: none;
  border-bottom: none;
}

.table-container th:last-child,
.table-container td:last-child {
  border-right: none;
}

.p-checkbox-box {
  border: 2px solid #005685 !important;
  box-shadow: none !important;
  border-radius: 4px !important;
}

.p-checkbox-box.p-highlight {
  border-color: #005685 !important;
}

.p-checkbox {
  position: relative;
  user-select: none;
  vertical-align: bottom;
}

.p-dialog-header {
  font-weight: bold;
}

.toggle-label {
  margin-left: 10px;
  font-weight: bold;
}

.my-multiselect {
  width: 30px;
  height: 20px;
  border: 1px solid black;
}

.toolBar {
  max-width: fit-content;
}

.v-toolbar__content {
  height: 46px !important;
}

table {
  height: 80vh;
}

.p-checkbox-box {
  height: 17px;
  width: 18px;
}

.p-treetable-emptymessage {
  display: none;
}

.context_menu {
  height: auto;
  width: auto;
  padding: 18px 18px 18px 0;
  background-color: #f4f5f6;
}

.p-menuitem {
  font-size: 16px;
  padding: 6px;
  background-color: #f4f5f6;
}

.p-menuitem-text {
  padding-left: 8px;
}

.p-contextmenu .p-submenu-list {
  position: absolute;
  min-width: auto;
  z-index: 1;
  background-color: #f4f5f6;
  left: 100% !important;
}
.centered {
  display: flex;
  justify-content: center;
  align-items: center;
}
.dropLabel {
  position: absolute;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%); /* Center the watermark */
  font-size: 2rem; /* Adjust font size as needed */
  color: rgba(0, 0, 0, 0.1); /* Light color for watermark effect */
  pointer-events: none; /* Prevent interaction with the watermark */
  white-space: nowrap; /* Prevent text wrapping */
}

.wrap-text {
  white-space: normal; /* Allows text to wrap */
  word-wrap: break-word; /* Break long words if necessary */
  overflow-wrap: break-word; /* Similar to word-wrap */
  max-width: 200px; /* Set a max width to control wrapping */
}

th,
td {
  overflow: visible !important; /* Allow content to be visible */
  text-overflow: clip !important; /* Prevent clipping */
}

.dropped-data {
  border: 2px solid #ddd; /* Match the header border color */
}
.p-menuitem-icon {
  display: none; /* Hide default icon */
}

/* Styling for headers */

@import "primeicons/primeicons.css";
</style>

<!-- <style>
@keyframes fadeInScaleRotate {
  0% {
    opacity: 0;
    transform: scale(0.5) rotate(-180deg);
  }

  50% {
    opacity: 0.5;
    transform: scale(1.1) rotate(-90deg);
  }

  100% {
    opacity: 1;
    transform: scale(1) rotate(0);
  }
}

.image-animated {
  opacity: 0;
  transform: scale(0.5) rotate(-180deg);
  animation: fadeInScaleRotate 1s ease-in-out forwards;
}

.image-fade-in.visible {
  opacity: 1;
}

.table-container {
  background-color: #f9f9f9;
  position: relative;
}

.p-button-sm {
  margin: 5px;
  border: 1px solid;
  background-color: blanchedalmond;
}

.p-dialog {
  max-height: 80vh;
  overflow-y: auto;
}

.custom-header {
  background-color: #005685;
  color: white;
  font-weight: bold;
  text-align: center;
  padding: 10px;
}

.table-container th {
  border-bottom: 2px solid #ddd;
}

.table-container th,
.table-container td {
  padding: 10px;
  border-bottom: 2px solid #ddd;
}

.table-container th:last-child,
.table-container td:last-child {
  border-right: none;
  border-bottom: none;
}

.table-container th:last-child,
.table-container td:last-child {
  border-right: none;
}

.p-checkbox-box {
  border: 2px solid #005685 !important;
  box-shadow: none !important;
  border-radius: 4px !important;
}

.p-checkbox-box.p-highlight {
  border-color: #005685 !important;
}

.p-checkbox {
  position: relative;
  user-select: none;
  vertical-align: bottom;
}

.p-dialog-header {
  font-weight: bold;
}

.toggle-label {
  margin-left: 10px;
  font-weight: bold;
}

.my-multiselect {
  width: 30px;
  height: 20px;
  border: 1px solid black;
}

.toolBar {
  max-width: fit-content;
}

.v-toolbar__content {
  height: 46px !important;
}

table {
  height: 80vh;
}

.p-checkbox-box {
  height: 17px;
  width: 18px;
}

.p-treetable-emptymessage {
  display: none;
}

.context_menu {
  height: auto;
  width: auto;
  padding: 18px 18px 18px 0;
  background-color: #f4f5f6;
  box-shadow: 0px 1px 2px #B4B6BA;
}

.p-menuitem {
  font-size: 16px;
  padding: 6px;
  background-color: #f4f5f6;
  border-bottom: 1px solid lightgrey;
}

.p-menuitem-text {
  padding-left: 8px;
  color: #77797C;
}

.p-contextmenu .p-submenu-list {
  position: absolute;
  min-width: auto;
  z-index: 1;
  color: #4b5563;
  background-color: #f4f5f6;
  left: 100% !important;
}

.centered {
  display: flex;
  justify-content: center;
  align-items: center;
}

.dropLabel {
  position: absolute;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%);
  /* Center the watermark */
  font-size: 2rem;
  /* Adjust font size as needed */
  color: rgba(0, 0, 0, 0.1);
  /* Light color for watermark effect */
  pointer-events: none;
  /* Prevent interaction with the watermark */
  white-space: nowrap;
  /* Prevent text wrapping */
}

.wrap-text {
  white-space: normal;
  /* Allows text to wrap */
  word-wrap: break-word;
  /* Break long words if necessary */
  overflow-wrap: break-word;
  /* Similar to word-wrap */
  max-width: 200px;
  /* Set a max width to control wrapping */
}

th,
td {
  overflow: visible !important;
  /* Allow content to be visible */
  text-overflow: clip !important;
  /* Prevent clipping */
}

@import 'primeicons/primeicons.css';

.p-treetable .p-sortable-column .p-sortable-column-icon {
  color: white;
}
</style> -->
