<template>
  <v-app>
    <v-main>
      <v-container fluid>
        <TableComponent />
      </v-container>
    </v-main>
  </v-app>
</template>

<script>
//Import Components
import TableComponent from './table-component.vue';
import Constants from "../assets/constants/constants.json";


export default {
  components: {
    TableComponent
  },

  //Define data here
  data() {
    return {

    };
  },
  //Call the methods before the component mount
  beforeMount() {
    this.ConstantValues = Constants;
    this.setPreferences(this.ConstantValues.langPreferences);
  },
  //Call the methods after the component created
  created() {

  },
  //Define methods here
  methods: {
    //Set Langugage Preference for selections
    setPreferences(Options) {
      widget.addPreference({
        name: "enable-language",
        type: "list",
        label: "Select Language",
        defaultValue: "en",
        options: Options,
      });
    },
  },
};
</script>

<style></style>
