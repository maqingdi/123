<template>
  <div class="customAlert">
    <v-alert v-model="show" :elevation="elevationValue" :density="density" closable border="start" :type="type">
      <template #text>
        <div v-html="message"></div>
      </template>
    </v-alert>
  </div>
</template>

<script>
export default {
  props: {
    elevationValue: { default: 0, type: Number },
    dismissError: { default: false, type: Boolean },
  },
  data() {
    return {
      show: false,
      display: false,
      messageTimer: null,
      message: null,
      type: null,
    };
  },
  expose: ["showAlert"],
  methods: {
    showAlert(message) {
      this.message = message;
      return {
        success: () => {
          this.type = "success";
          this.handleAlert();
        },
        warning: () => {
          this.type = "warning";
          this.message = message;
          this.handleAlert();
        },
        info: () => {
          this.type = "info";
          this.message = message;
          this.handleAlert();
        },
        error: () => {
          this.type = "error";
          this.dismissError ? this.handleAlert(true, 10000) : this.handleAlert(false);
        },
      };
    },
    handleAlert(dismissAlert = true, time = 5000) {
      this.show = true;
      const instance = this;
      if (dismissAlert) {
        clearTimeout(this.messageTimer);
        this.messageTimer = setTimeout(() => {
          instance.show = false;
        }, time);
      }
    },
  },
};
</script>

<style>
.customAlert {
  position: fixed;
  top: 10px;
  right: 25px;
  z-index: 10000 !important;
}

.v-alert__content {
  white-space: break-spaces !important;
}
</style>
