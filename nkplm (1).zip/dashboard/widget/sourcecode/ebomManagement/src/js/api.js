
export const  WAFData= 'DS/WAFData/WAFData';

export const makeWSCall = (
  url,
  httpMethod,
  securityContext,
  enoCSRFToken,
  ReqBody,
  userCallbackOnComplete,
  userCallbackOnFailure
) =>{
  requirejs([WAFData], function (WAFData) {
    const queryobject = {};
    queryobject.method = httpMethod;
    queryobject.timeout = 700000;
    queryobject.type = 'json';
    queryobject.crossOrigin = true;
    queryobject.headers = {
      SecurityContext: securityContext,
      'Content-Type': 'application/json',
      ENO_CSRF_TOKEN: enoCSRFToken,
    };
    queryobject.data = ReqBody;
    queryobject.responseType = 'json';
    queryobject.onComplete = function (dataResp) {
      userCallbackOnComplete(dataResp);
    };
    queryobject.onFailure = function (error, response, headers) {
      userCallbackOnFailure(error, response, headers);
    };
    WAFData.authenticatedRequest(url, queryobject);
  });
};
