/**
 * ItemNumberModeler.java
 * 
 * This class is responsible for defining the RESTful services for the Nihon-Kohden Item Numbering Application.
 * It extends the ModelerBase class provided by the Dassault Systemes platform to define the application path.
 *
 * @Author: DSGS
 * @since: Version 1.0
 * 
 * Modification Details:
 * 
 * Date   | User | Version | Comment
 * -----------|------|---------|--------------------------
 * 01/10/2024 DSGS    1.0      Modeler class to host Item Numbering webservices.
 */
package com.nk.itemnumbering;
import javax.ws.rs.ApplicationPath;
import com.dassault_systemes.platform.restServices.ModelerBase;

/**
 * The ItemNumberModeler class defines the application path for the Nihon-Kohden
 * Item Numbering services.
 * 
 * It extends the ModelerBase class from the Dassault
 * Systemes platform to provide the necessary functionality.
 * 
 */
@ApplicationPath("/itemNumberModeler")
public class ItemNumberModeler extends ModelerBase{
	public Class<?>[] getServices() {
		return new Class[] {ItemNumberServices.class};
	}

}
