
/**
 * ItemNumberProcess.java
 *
 * This class provides methods to perform Item Numbering Process.
 *
 * @Author: DSGS
 * @since: Version 1.0
 *
 * Modification Details:
 *
 *     Date   | User | Version | Comment
 * -----------|------|---------|--------------------------
 *  01/10/2024 DSGS    1.0      Utility Class to support web services Operations
 *  */

package com.nk.itemnumbering;

import java.io.PrintWriter;
import java.io.StringWriter;
import java.util.Map;
import javax.ws.rs.core.Response;
import org.json.JSONObject;
import com.matrixone.apps.domain.DomainConstants;
import com.matrixone.apps.domain.DomainObject;
import com.matrixone.apps.domain.util.ContextUtil;
import com.matrixone.apps.domain.util.FrameworkException;
import com.matrixone.apps.domain.util.MapList;
import com.matrixone.apps.domain.util.MqlUtil;
import com.matrixone.apps.domain.util.StringUtil;
import com.matrixone.apps.framework.ui.UIUtil;

import matrix.db.BusinessInterface;
import matrix.db.Context;
import matrix.util.StringList;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.json.JSONArray;

public class ItemNumberProcess {

	private static final Logger logger = LoggerFactory.getLogger("ItemNumbering");

	/**
	 * This method is used to get the all attributes of MBOM Order
	 * 
	 * @param context
	 * @param sObjectId
	 * @return Response
	 * @throws FrameworkException
	 */
	public Response getObjectDetails(Context context, String sObjectId) throws FrameworkException {
		logger.debug("Started getObjectDetails method");
		JSONObject jsonReturnObj = new JSONObject();
		try {
			JSONObject mainObject = getObjectInfo(context, sObjectId);
			jsonReturnObj.put(ItemNumberConstants.STRING_STATUS, ItemNumberConstants.STATUS_SUCCESS);
			jsonReturnObj.put(ItemNumberConstants.STRING_DATA, mainObject);
		} catch (Exception ex) {
			logger.error("Error in getObjectDetails:", ex);
			logger.debug("Finished getObjectDetails method");
			jsonReturnObj.put(ItemNumberConstants.STRING_STATUS, ItemNumberConstants.STATUS_ERROR);
			jsonReturnObj.put(ItemNumberConstants.STATUS_ERROR, ex.getMessage());
			return Response.status(Response.Status.BAD_REQUEST).entity(jsonReturnObj.toString()).build();
		}
		logger.debug("Finished getObjectDetails method");
		return Response.status(Response.Status.OK).entity(jsonReturnObj.toString()).build();
	}

	/**
	 * Method to get all basic info and attributes of an object
	 * 
	 * @param context
	 * @param sObjectId
	 * @return JSONObject
	 * @throws FrameworkException
	 */
	public JSONObject getObjectInfo(Context context, String sObjectId) throws FrameworkException 
	{
		logger.debug("Started getObjectInfo method");
		JSONObject mainObject = new JSONObject();

		StringList objSelects = new StringList();
		objSelects.add(DomainConstants.SELECT_TYPE);
		objSelects.add(DomainConstants.SELECT_NAME);
		objSelects.add(DomainConstants.SELECT_ID);
		objSelects.add(DomainConstants.SELECT_CURRENT);
		objSelects.add("attribute[" + ItemNumberConstants.EIN + "]");
		objSelects.add("to[VPMInstance].from.attribute[" + ItemNumberConstants.EIN + "]");
		objSelects.add("to[VPMInstance].from.attribute[NK_EXT_EBOM_BASE.NK_PARTS_TYPE]");
		try {
			DomainObject domObject = DomainObject.newInstance(context, sObjectId);
			Map<String, Object> map = domObject.getInfo(context, objSelects);
			
			logger.info("map: {}", map);
			if (null != map && !map.isEmpty()) 
			{
				mainObject.put(DomainConstants.SELECT_TYPE, map.get(DomainConstants.SELECT_TYPE));
				mainObject.put(DomainConstants.SELECT_NAME, map.get(DomainConstants.SELECT_NAME));
				mainObject.put(DomainConstants.SELECT_ID, map.get(DomainConstants.SELECT_ID));
				mainObject.put(DomainConstants.SELECT_CURRENT, map.get(DomainConstants.SELECT_CURRENT));
				String strType = (String) map.get(DomainConstants.SELECT_TYPE);
				
				// Get item number attribute value
				String strItemNumber = (String) map.get("attribute[" + ItemNumberConstants.EIN + "]");
				String strParentItemNumber = (String) map.get("to[VPMInstance].from.attribute[" + ItemNumberConstants.EIN + "]");
				String strParentItemType = (String) map.get("to[VPMInstance].from.attribute[NK_EXT_EBOM_BASE.NK_PARTS_TYPE]");
				
				if (UIUtil.isNotNullAndNotEmpty(strItemNumber)) {
					mainObject.put(ItemNumberConstants.ITEM_NUMBER, strItemNumber);
				}
				if (UIUtil.isNotNullAndNotEmpty(strParentItemNumber)) {
					mainObject.put(ItemNumberConstants.PARENT_NUMBER, strParentItemNumber);
				}
				if (UIUtil.isNotNullAndNotEmpty(strParentItemNumber)) {
					mainObject.put(ItemNumberConstants.PARENT_TYPE, strParentItemType);
				}
				
				// Update EIN and Title for Document
				if (strType.equals(DomainConstants.TYPE_DOCUMENT)) {
					String strItemNumber1 = (String) map.get("attribute[" + ItemNumberConstants.DOC_ITEM_NUMBER + "]");
					if (UIUtil.isNotNullAndNotEmpty(strItemNumber1)) {
						mainObject.put(ItemNumberConstants.ITEM_NUMBER, strItemNumber1);
					}
				}

			}
		} catch (Exception ex) {
			logger.error("Error in getObjectInfo:", ex);
			logger.debug("Finished getObjectInfo method");
			throw new FrameworkException(ex);
		}
		logger.debug("Finished getObjectInfo method");
		return mainObject;
	}

	
	/**
	 * Method to register the sequence number
	 * 
	 * @param context
	 * @param jsonString
	 * @return Response
	 * @throws FrameworkException
	 */
	public Response registerSequenceNumber(Context context, String jsonString) throws FrameworkException {
		logger.debug("Started registerSequenceNumber method");
		JSONObject jsonReturnObj = new JSONObject();
		try {
			ContextUtil.startTransaction(context, true);
			// Convert input string to JSONObject
			JSONObject jsonObject = new JSONObject(jsonString);

			// Get the top four digit of part number
			String strPartprefix = jsonObject.getString(ItemNumberConstants.PART_PREFIX);

			StringList slSelects = new StringList();
			slSelects.add(DomainConstants.SELECT_ID);
			slSelects.add(ItemNumberConstants.ATTRIBUTE_ESERVICE_NUMBER);
			MapList mleService = DomainObject.findObjects(context, ItemNumberConstants.TYPE_ESERVICE_NUMBER,
					DomainConstants.QUERY_WILDCARD, strPartprefix, DomainConstants.QUERY_WILDCARD,
					"eService Administration", null, false, slSelects);

			if (mleService.isEmpty()) {
				logger.debug("create sequence number generator");

				ContextUtil.pushContext(context, ItemNumberConstants.USER, null, null);
				MqlUtil.mqlCommand(context, "add bus $1 $2 $3 vault $4 policy $5 owner $6 description $7 $8 $9",
						ItemNumberConstants.TYPE_ESERVICE_NUMBER, ItemNumberConstants.SEQ_NAME, strPartprefix,
						ItemNumberConstants.ESERVICE_VAULT, ItemNumberConstants.ESERVICE_POLICY,
						ItemNumberConstants.ESERVICE_OWNER, "Item Numbering",ItemNumberConstants.ESERVICE_NEXT_NUMBER, "000000");
				MqlUtil.mqlCommand(context, "add bus $1 $2 $3 vault $4 policy $5 owner $6 description $7",
						ItemNumberConstants.TYPE_ESERVICE_OBJECT, ItemNumberConstants.SEQ_NAME, strPartprefix,
						ItemNumberConstants.ESERVICE_VAULT, ItemNumberConstants.ESERVICE_POLICY,
						ItemNumberConstants.ESERVICE_OWNER, "Item Numbering");
				MqlUtil.mqlCommand(context, "connect bus $1 $2 $3 relation $4 to $5 $6 $7",
						ItemNumberConstants.TYPE_ESERVICE_OBJECT, ItemNumberConstants.SEQ_NAME, strPartprefix,
						ItemNumberConstants.RELATIONSH_NAME, ItemNumberConstants.TYPE_ESERVICE_NUMBER,
						ItemNumberConstants.SEQ_NAME, strPartprefix);
				String strResult = MqlUtil.mqlCommand(context, "temp query bus $1 $2 $3 select $4 $5 dump $6",
						ItemNumberConstants.TYPE_ESERVICE_NUMBER, ItemNumberConstants.SEQ_NAME, strPartprefix, "id",
						ItemNumberConstants.ATTRIBUTE_ESERVICE_NUMBER, "|");
				StringList slList = StringUtil.split(strResult, "|");
				String str1NxtNumber = slList.get(4);
				String str1eID = slList.get(3);

				String nextNumber = getSequenceNumber(context, str1NxtNumber, str1eID);
				jsonReturnObj.put(ItemNumberConstants.SEQ_NUMBER, strPartprefix + "-" + nextNumber);
				ContextUtil.popContext(context);

			} else {
				for (Object obj : mleService) {
					Map<?, ?> mapeService = (Map<?, ?>) obj;
					String strNxtNumber = (String) mapeService.get(ItemNumberConstants.ATTRIBUTE_ESERVICE_NUMBER);
					String streID = (String) mapeService.get(DomainConstants.SELECT_ID);

					String nextNumber = getSequenceNumber(context, strNxtNumber, streID);
					jsonReturnObj.put(ItemNumberConstants.SEQ_NUMBER, strPartprefix + "-" + nextNumber);

				}

			}

			jsonReturnObj.put(ItemNumberConstants.STRING_STATUS, ItemNumberConstants.STATUS_SUCCESS);
			ContextUtil.commitTransaction(context);
		} catch (Exception ex) {
			ContextUtil.abortTransaction(context);
			logger.error("Error in registerSequenceNumber method", ex);
			logger.debug("Finished registerSequenceNumber method");
			jsonReturnObj.put(ItemNumberConstants.STRING_STATUS, ItemNumberConstants.STATUS_ERROR);
			jsonReturnObj.put(ItemNumberConstants.STATUS_ERROR, ex.getMessage());
			return Response.status(Response.Status.BAD_REQUEST).entity(jsonReturnObj.toString()).build();
		}
		logger.debug("Finished registerSequenceNumber method");
		return Response.status(Response.Status.OK).entity(jsonReturnObj.toString()).build();
	}

	/**
	 * Method to update the get Next Sequence Number
	 * 
	 * @param context
	 * @param jsonString
	 * @return Response
	 * @throws FrameworkException
	 */
	public String getSequenceNumber(Context context, String nextNumber, String objectId) throws FrameworkException {
		logger.debug("Started getSequenceNumber method");
		try {

			if (!nextNumber.isEmpty()) {
				int iNumber = Integer.parseInt(nextNumber);
				iNumber++;		
				String strNewSeqNo = String.format("%06d", iNumber);
				ContextUtil.pushContext(context, ItemNumberConstants.USER, null, null);
				MqlUtil.mqlCommand(context, "mod bus $1 $2 $3 ", objectId, ItemNumberConstants.ESERVICE_NEXT_NUMBER,
						strNewSeqNo);
				ContextUtil.popContext(context);
			}

		} catch (Exception ex) {
			logger.error("Error in getSequenceNumber", ex);
			logger.debug("Finished getSequenceNumber method");
		}
		logger.debug("Finished getSequenceNumber method");
		return nextNumber;
	}
	

	/**
	 * Method to perform register Item Number
	 * 
	 * @param context
	 * @param jsonString
	 * @return Response
	 * @throws FrameworkException
	 */
	public Response registerItemNumber(Context context, String jsonString) throws FrameworkException {
		logger.debug("Started registerItemNumber method");
		JSONObject jsonReturnObj = new JSONObject();
		StringList slInterfaceToAdd = new StringList();
		boolean ctx = false;
		try {
			ContextUtil.startTransaction(context, true);
			// Convert input string to JSONObject
			JSONObject jsonObject = new JSONObject(jsonString);
			String strPhysicalid = jsonObject.getString(DomainConstants.SELECT_PHYSICAL_ID);

			DomainObject domObj = DomainObject.newInstance(context, strPhysicalid);
			String strPartItemNumber = domObj.getAttributeValue(context, ItemNumberConstants.EIN);
			String strFinalItemNumber = jsonObject.getString(ItemNumberConstants.ITEM_NUMBER);
			JSONArray attributesArray  = jsonObject.getJSONArray(ItemNumberConstants.EXT_ATTRIBUTES);
			JSONArray interfacesArray  = jsonObject.getJSONArray(ItemNumberConstants.EXT_INTERFACES);
			String strType = jsonObject.getString(ItemNumberConstants.ITEM_TYPE);
            logger.debug(strPartItemNumber);
            logger.debug(strFinalItemNumber);
			//to check if Part Number already registered
			if(strPartItemNumber.equalsIgnoreCase(strFinalItemNumber))
			{
				jsonReturnObj.put(ItemNumberConstants.STRING_STATUS, ItemNumberConstants.STATUS_ERROR);
				return Response.status(Response.Status.OK).entity(jsonReturnObj.toString()).build();
				
			}
	        //Update EIN and Title
			if (UIUtil.isNotNullAndNotEmpty(strFinalItemNumber)) {
				ContextUtil.pushContext(context, ItemNumberConstants.USER, null, null);
				MqlUtil.mqlCommand(context, "trigger off", true);
				domObj.setAttributeValue(context, ItemNumberConstants.EIN, strFinalItemNumber);
				String title = strFinalItemNumber.replace("-", "");
				domObj.setAttributeValue(context, ItemNumberConstants.TITLE, title);
				ctx=true;
			}
			//Update EIN and Title for Document
			if(strType.equals(DomainConstants.TYPE_DOCUMENT)){
				ContextUtil.pushContext(context, ItemNumberConstants.USER, null, null);
				MqlUtil.mqlCommand(context, "trigger off", true);
				String strDocPartItemNumber = domObj.getAttributeValue(context, ItemNumberConstants.DOC_ITEM_NUMBER);
				domObj.setAttributeValue(context, ItemNumberConstants.DOC_ITEM_NUMBER, strFinalItemNumber);
				String title = strFinalItemNumber.replace("-", "");
				domObj.setAttributeValue(context, "Title", title);
				ctx=true;
			}
			ContextUtil.commitTransaction(context);
			
			 // Update interfaces similarly if needed
	        if (interfacesArray != null) {
	            for (int i = 0; i < interfacesArray.length(); i++) {
	                JSONObject interfaceObject = interfacesArray.getJSONObject(i);
	                String interfaceName = interfaceObject.getString("exName");
	                //Adding Interface
	                
	        		slInterfaceToAdd.add(interfaceName);
	                
	            }
	        }

	        if(!slInterfaceToAdd.isEmpty()){
	        	addInterface(context, strPhysicalid, slInterfaceToAdd);
	        }
	        
			// Update extended attributes
	        if (attributesArray != null) {
	            for (int i = 0; i < attributesArray.length(); i++) {
	            	
	                JSONObject attributeObject = attributesArray.getJSONObject(i);
	                String attributeName = (String) attributeObject.get("attrName");
	                logger.debug(attributeName);
	                String attributeValue = (String) attributeObject.get("value");
	                logger.debug(attributeValue);
	                domObj.setAttributeValue(context, attributeName, attributeValue);
	            }
	        }
	        

			jsonReturnObj.put(ItemNumberConstants.STRING_STATUS, ItemNumberConstants.STATUS_SUCCESS);
			
		} catch (Exception ex) {
			ContextUtil.abortTransaction(context);
			logger.error("Error in registerItemNumber", ex);
			logger.debug("Finished registerItemNumber method");
			jsonReturnObj.put(ItemNumberConstants.STRING_STATUS, ItemNumberConstants.STATUS_ERROR);
			jsonReturnObj.put(ItemNumberConstants.STATUS_ERROR, ex.getMessage());
			return Response.status(Response.Status.BAD_REQUEST).entity(jsonReturnObj.toString()).build();
		} finally {
			if(ctx){
			ContextUtil.popContext(context);
			MqlUtil.mqlCommand(context, "trigger on", true);
			}
			
		}
		logger.debug("Finished registerItemNumber method");
		return Response.status(Response.Status.OK).entity(jsonReturnObj.toString()).build();
	}
	
	/**
	 * This method is used to Add interface for given object
	 *
	 * @param context
	 * @param strObjId
	 * @param slInterface
	 * @throws Exception if the operation fails
	 */
	private static void addInterface(Context context, String strObjId, StringList slInterface) throws Exception
	{
		logger.debug("Started addInterface method");
		String strExistingInterface = MqlUtil.mqlCommand(context,"print bus $1 select interface dump", strObjId);
		StringList slExisting = StringUtil.split(strExistingInterface, ",");
		DomainObject doObj = DomainObject.newInstance(context, strObjId);
		try	{
			for (int iIndex = 0; iIndex < slInterface.size(); iIndex++) {
				String strInterface = slInterface.get(iIndex);
				if(slExisting.isEmpty() || !slExisting.contains(strInterface)) {
					BusinessInterface busInter = new BusinessInterface(strInterface, context.getVault());
					doObj.addBusinessInterface(context, busInter);
				}
			}
		} catch(Exception e) {
			StringWriter sw = new StringWriter();
			PrintWriter pw = new PrintWriter(sw);
			e.printStackTrace(pw);
			pw.flush();
			logger.debug("addInterface ERROR");
			e.printStackTrace();
			throw e;
		}
		logger.debug("Finished addInterface method");
	}

	
	/**
	 * Method to perform register Item Number
	 * 
	 * @param context
	 * @param jsonString
	 * @return Response
	 * @throws FrameworkException
	 */
	public Response getParentItemNumber(Context context, String sObjectId) throws FrameworkException {
		logger.debug("Started getParentItemNumber method");
		JSONObject jsonReturnObj = new JSONObject();
		try {
			ContextUtil.startTransaction(context, true);
			logger.error("strPhysicalid----", sObjectId);
			DomainObject domObj = DomainObject.newInstance(context, sObjectId);
			ContextUtil.commitTransaction(context);
			
			//get 1 level MBOM and Attributes
			 //String relPattern = "VPMInstance";
			// String typePattern = "VPMReference";
	         StringList objSelects = new StringList(3);
	         objSelects.add(DomainConstants.SELECT_NAME);
	         objSelects.add(DomainConstants.SELECT_TYPE);
	         objSelects.add(DomainConstants.SELECT_ID);  
	         objSelects.add(DomainConstants.SELECT_CURRENT);
	         objSelects.add(DomainConstants.SELECT_OWNER);
	         objSelects.add(DomainConstants.SELECT_PHYSICAL_ID);
	         objSelects.add(ItemNumberConstants.PART_TYPE);
	         
	         StringList relSelects = new StringList();
	         relSelects.add(DomainConstants.SELECT_RELATIONSHIP_ID);

	         MapList mbomRelatedObject = domObj.getRelatedObjects(context, "VPMInstance", 						                          // relationship pattern
	        		 														   "VPMReference",                                                   // object pattern
	        		 														   objSelects,                                                    // object selects
	        		 														   relSelects, 		                                              // relationship selects
	                                                                           true,                                                          // to direction
	                                                                           false,                                                          // from direction
	                                                                           (short) 0,                                                     // recursion level
	                                                                           null,                           								  // object where clause
	                                                                           null,
	                                                                           (short) 0);


	     	logger.error("mbomRelatedObject----", mbomRelatedObject);
	     	if(mbomRelatedObject.size()>0)
	     	{
				for (Object mbomMap : mbomRelatedObject) 
				{
					Map<?, ?> mbomInfo = (Map<?, ?>) mbomMap;
					logger.error("mbomInfo----", mbomInfo);
		
				}
			//jsonReturnObj.put(ItemNumberConstants.STRING_STATUS, ItemNumberConstants.STATUS_SUCCESS);
	     	} else
	     	{
	     		//jsonReturnObj.put(ItemNumberConstants.STRING_STATUS, "No Parent");
	     	}
			
			
		} catch (Exception ex) {
			ContextUtil.abortTransaction(context);
			logger.error("Error in getParentItemNumber", ex);
			logger.debug("Finished getParentItemNumber method");
			jsonReturnObj.put(ItemNumberConstants.STRING_STATUS, ItemNumberConstants.STATUS_ERROR);
			jsonReturnObj.put(ItemNumberConstants.STATUS_ERROR, ex.getMessage());
			return Response.status(Response.Status.BAD_REQUEST).entity(jsonReturnObj.toString()).build();
		} 
		logger.debug("Finished getParentItemNumber method");
		return Response.status(Response.Status.OK).entity(jsonReturnObj.toString()).build();
	}
}
