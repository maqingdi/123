
/**
 * ItemNumberServices.java
 * 
 * This class defines the RESTful web services for the Item Numbering application.
 * 
 * @Author: DSGS
 * @since: Version 1.0
 * 
 * Modification Details:
 *
 *     Date   | User | Version | Comment
 * -----------|------|---------|--------------------------
 *  01/10/2024 DSGS    1.0      Services Class to host Item Numbering webservices.
 *  */
package com.nk.itemnumbering;

import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import com.dassault_systemes.platform.restServices.RestService;
import matrix.db.Context;


@Path("/itemNumbering")
@Produces(MediaType.APPLICATION_JSON)
public class ItemNumberServices extends RestService{
	private static final Logger logger = LoggerFactory.getLogger("ItemNumbering");
	private ItemNumberProcess itemNumberingProcess = new ItemNumberProcess();

	@GET
	@Path("/getObjectDetails/{id}")	
	@Produces(MediaType.APPLICATION_JSON)
	public Response getObjectDetails(@javax.ws.rs.core.Context HttpServletRequest request,@PathParam("id") String strOjectId) 
	{
		logger.debug("Started getObjectDetails method");
		Response res = null;
		try {
			Context context = this.getAuthenticatedContext(request, false);			
			return itemNumberingProcess.getObjectDetails(context, strOjectId);		
		} catch (Exception ex) {
			logger.error("Error in getObjectDetails: ", ex);
			logger.debug("Finished getObjectDetails method");
			res=Response.status(Response.Status.BAD_REQUEST).entity(ex.getMessage()).build();
		}
		logger.debug("Finished getObjectDetails method");
		return res;
	}

	@POST
	@Path("/registerSequenceNumber")	
	@Produces(MediaType.APPLICATION_JSON)
	@Consumes(MediaType.APPLICATION_JSON)
	public Response registerSequenceNumber(@javax.ws.rs.core.Context HttpServletRequest request,String sInput) {
		logger.debug("Started registerSequenceNumber method");
		Response res = null;
		try {
			Context context = this.getAuthenticatedContext(request, false);			
			return itemNumberingProcess.registerSequenceNumber(context, sInput);			
		} catch (Exception ex) {
			logger.error("Error in defaultAttributeValue", ex);
			logger.debug("Finished defaultAttributeValue method");
			res=Response.status(Response.Status.BAD_REQUEST).entity(ex.getMessage()).build();
		}
		logger.debug("Finished defaultAttributeValue method");
		return res;
	}
	
	@POST
	@Path("/registerItemNumber")	
	@Produces(MediaType.APPLICATION_JSON)
	@Consumes(MediaType.APPLICATION_JSON)
	public Response registerItemNumber(@javax.ws.rs.core.Context HttpServletRequest request,String sInput) 
	{
		logger.debug("Started registerItemNumber method");
		Response res = null;
		try {
			Context context = this.getAuthenticatedContext(request, false);			
			return itemNumberingProcess.registerItemNumber(context, sInput);			
		} catch (Exception ex) {
			logger.error("Error in registerItemNumber", ex);
			logger.debug("Finished registerItemNumber method");
			res=Response.status(Response.Status.BAD_REQUEST).entity(ex.getMessage()).build();
		}
		logger.debug("Finished registerItemNumber method");
		return res;
	}
	
	@GET
	@Path("/getParentItemNumber/{id}")	
	@Produces(MediaType.APPLICATION_JSON)
	public Response getParentItemNumber(@javax.ws.rs.core.Context HttpServletRequest request,@PathParam("id") String strOjectId) 
	{
		logger.debug("Started getParentItemNumber method");
		Response res = null;
		try {
			Context context = this.getAuthenticatedContext(request, false);		
			return itemNumberingProcess.getParentItemNumber(context, strOjectId);			
		} catch (Exception ex) {
			logger.error("Error in getParentItemNumber", ex);
			logger.debug("Finished getParentItemNumber method");
			res=Response.status(Response.Status.BAD_REQUEST).entity(ex.getMessage()).build();
		}
		logger.debug("Finished getParentItemNumber method");
		return res;
	}

}
