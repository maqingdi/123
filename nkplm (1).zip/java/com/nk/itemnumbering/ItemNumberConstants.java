package com.nk.itemnumbering;

public class ItemNumberConstants {
	
	  /**
	   * Common Constants
	   *
	   * This section defines common constant values used in the ItemNumberConstants module.
	   * These constants represent various attributes and properties used in the module.
	   *
	   */
	  public static final String EIN = "EnterpriseExtension.V_PartNumber";
	  public static final String STATUS_SUCCESS = "Success";
	  public static final String STATUS_ERROR = "error";
	  public static final String STRING_STATUS = "status";
	  public static final String STRING_DATA = "data";
	  public static final String ITEM_NUMBER = "ItemNumber";
	  public static final String PART_PREFIX = "PartPrefix";
	  public static final String TYPE_ESERVICE_OBJECT = "eService Object Generator";
	  public static final String TYPE_ESERVICE_NUMBER = "eService Number Generator";
	  public static final String SEQ_NAME = "type_nk_item";
	  public static final String ESERVICE_POLICY = "eService Object Generator";
	  public static final String ESERVICE_VAULT = "eService Administration";
	  public static final String ESERVICE_OWNER = "creator";
	  public static final String ATTRIBUTE_ESERVICE_NUMBER = "attribute[eService Next Number]";
	  public static final String ESERVICE_NEXT_NUMBER = "eService Next Number";
	  public static final String SEQ_NUMBER = "seqNumber";
	  public static final String TITLE = "PLMEntity.V_Name";
	  public static final String USER = "User Agent";
	  public static final String ITEMTYPE = "itemType";
	  public static final String RELATIONSH_NAME = "eService Number Generator";
	  public static final String EXT_ATTRIBUTES = "attributes";
	  public static final String EXT_INTERFACES = "extAttributes";
	  public static final String ITEM_TYPE = "objectType";
	  public static final String DOC_ITEM_NUMBER = "NK_DOC_PART_NUMBER";
	  public static final String PART_TYPE = "NK_EXT_MBOM_BASE.NK_PARTS_TYPE";
	  public static final String PARENT_NUMBER = "parentNumber";
	  public static final String PARENT_TYPE = "parentType";
	
private ItemNumberConstants() {
    throw new IllegalStateException("Constants class");
		  }

}
