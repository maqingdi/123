package com.nk.bossapplication;

public class BossApplicationConstants {
	  public static final String EIN = "EnterpriseExtension.V_PartNumber";
	  public static final String ITEM_NUMBER = "ItemNumber";
	  public static final String DOC_ITEM_NUMBER = "NK_DOC_PART_NUMBER";
	  public static final String SELECT_EIN = "attribute[EnterpriseExtension.V_PartNumber]";
	  public static final String SELECT_V_NAME = "attribute[PLMEntity.V_Name]";
	  public static final String STATUS_SUCCESS = "Success";
	  public static final String STATUS_ERROR = "error";
	  public static final String STRING_STATUS = "status";
	  public static final String STRING_DATA = "data";
	  public static final String ATTRIBUTE_NK_BOMLIFECYCLE = "NK_EXT_MBOM_BASE.NK_BOMLIFECYCLE";
	  public static final String SELECT_ATTRIBUTE_NK_PARTS_NAME = "attribute[NK_EXT_MBOM_REVISION_SYSTEM.NK_PARTS_NAME]";
	  public static final String SELECT_ATTRIBUTE_NK_REVISION = "attribute[NK_EXT_MBOM_BASE.NK_REVISION]";
	  public static final String SELECT_ATTRIBUTE_NK_FLAG_NO_BOSS = "attribute[NK_EXT_MBOM_REL_BASE.NK_FLAG_NO_BOSS]";
	  public static final String SELECT_ATTRIBUTE_NK_FLAG_OF_OUTSOURCING_BOSS = "attribute[NK_EXT_MBOM_EXT_OUTSOURCING_BOSS.NK_FLAG_OF_OUTSOURCING_BOSS]";
	  public static final String SELECT_ATTRIBUTE_NK_BOMLIFECYCLE = "attribute[NK_EXT_MBOM_BASE.NK_BOMLIFECYCLE]";
	  public static final String SELECT_ATTRIBUTE_NK_WORK_PROCEDURE_INSTRUCTION = "attribute[NK_EXT_MBOM_MANUFACTURE.NK_WORK_PROCEDURE_INSTRUCTION]";
	  public static final String SELECT_ATTRIBUTE_NK_PARTS_TYPE = "attribute[NK_EXT_MBOM_BASE.NK_PARTS_TYPE]";
	  public static final String SELECT_ATTRIBUTE_NK_NUMERATOR = "attribute[NK_EXT_MBOM_REL_BASE.NK_NUMERATOR]";
	  public static final String SELECT_ATTRIBUTE_NK_CLASS_MATERIAL = "attribute[NK_EXT_MBOM_REL_BASE.NK_CLASS_MATERIAL]";
	  public static final String SELECT_ATTRIBUTE_NK_AUXILIARY_MATERIAL_CLASS = "attribute[NK_EXT_MBOM_MANUFACTURE.NK_AUXILIARY_MATERIAL_CLASS]";
	  public static final String SELECT_ATTRIBUTE_NK_TYPE_BOSS_ITEM = "attribute[NK_EXT_MBOM_BASE.NK_TYPE_BOSS_ITEM]";
	  public static final String REL_DELFMI_FUNCTION_INSTANCE = "DELFmiFunctionIdentifiedInstance";
	  public static final String SELECT_ATTRIBUTE_NK_MATERIALS_FORM_CLASSIFICATION = "attribute[NK_EXT_EBOM_PARTS.NK_MATERIALS_FORM_CLASSIFICATION]";
	  public static final String SELECT_ATTRIBUTE_NK_PHARMACEUTICAL_PARTS_CORD = "attribute[NK_EXT_EBOM_PLANT_COMMON.NK_PHARMACEUTICAL_PARTS_CORD]";
	  public static final String SELECT_ATTRIBUTE_NK_KNOWLEDGE_CATEGORY = "attribute[NK_'EXT_EBOM_BASE.NK_KNOWLEDGE_CATEGORY]";
	  public static final String SELECT_ATTRIBUTE_NK_TYPE_PRODUCT = "attribute[NK_EXT_EBOM_PLANT_COMMON.NK_TYPE_PRODUCT]";
	  public static final String SELECT_ATTRIBUTE_NK_TRACE_TYPE = "attribute[NK_EXT_EBOM_PLANT_COMMON.NK_TRACE_TYPE]";
	  
	  public static final String TYPE_CREATE_ASSEMBLY = "CreateAssembly";
	  public static final String TYPE_PROVIDE = "Provide";
	  public static final String KEY_RELIDS = "relIds";
	  public static final String KEY_ATTRNAME = "attrName";
	  public static final String KEY_ATTRVALUE = "attrValue";
	  public static final String KEY_IDS = "ids";
	  public static final String NK_LIFECYCLE_PROPERTIES = "NK_Lifecycle.properties";
	  public static final String KEY_PROCUREMENT ="Procurement";
	  public static final String KEY_MANUFACTURING = "Manufacturing";
	  public static final String KEY_FALSE = "FALSE";
	  public static final String REL_VPMINSTANCE = "VPMInstance";
	  public static final String TYPE_VPMREFERENCE = "VPMReference";
	  public static final String ATTRIBUTE_NK_WORK_PROCEDURE_INSTRUCTION = "NK_EXT_MBOM_MANUFACTURE.NK_WORK_PROCEDURE_INSTRUCTION";
	  
	  private BossApplicationConstants() {
		    throw new IllegalStateException("Constants class");
				  }
}
