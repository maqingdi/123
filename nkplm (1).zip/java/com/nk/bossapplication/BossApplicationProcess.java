package com.nk.bossapplication;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Properties;

import javax.ws.rs.core.Response;

import org.json.JSONArray;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.dassault_systemes.i3dx.appsmodel.util.Util;
import com.dassault_systemes.platform.ven.jackson.databind.ObjectMapper;
import com.matrixone.apps.domain.DomainConstants;
import com.matrixone.apps.domain.DomainObject;
import com.matrixone.apps.domain.DomainRelationship;
import com.matrixone.apps.domain.util.ContextUtil;
import com.matrixone.apps.domain.util.FrameworkException;
import com.matrixone.apps.domain.util.FrameworkUtil;
import com.matrixone.apps.domain.util.MapList;
import com.matrixone.apps.domain.util.MqlUtil;
import com.matrixone.apps.domain.util.StringUtil;
import com.matrixone.apps.framework.ui.UIUtil;
import com.nk.bossapplication.BossApplicationConstants;
import com.nk.itemnumbering.ItemNumberConstants;

import matrix.db.Context;
import matrix.db.Page;
import matrix.util.MatrixException;
import matrix.util.Pattern;
import matrix.util.StringList;

import java.io.ByteArrayInputStream;
import java.io.InputStream;

public class BossApplicationProcess {

	private static final Logger logger = LoggerFactory.getLogger("BossApplication");

	/**
	 * This method is used to get the attributes of multiple objects
	 * 
	 * @param context
	 * @param sObjectId
	 * @return Response
	 * @throws FrameworkException
	 */
	public Response getObjectsDetails(Context context, String sObjectId) throws FrameworkException {
		logger.debug("Started getObjectsDetails method");
		JSONObject jsonReturnObj = new JSONObject();
		try {
			JSONArray jsonArrObjs = getObjectsInfo(context, sObjectId);
			jsonReturnObj.put(BossApplicationConstants.STRING_STATUS, BossApplicationConstants.STATUS_SUCCESS);
			jsonReturnObj.put(BossApplicationConstants.STRING_DATA, jsonArrObjs);
		} catch (Exception ex) {
			logger.error("Error in getObjectsDetails:", ex);
			logger.debug("Finished getObjectsDetails method");
			jsonReturnObj.put(BossApplicationConstants.STRING_STATUS, BossApplicationConstants.STATUS_ERROR);
			jsonReturnObj.put(BossApplicationConstants.STATUS_ERROR, ex.getMessage());
			return Response.status(Response.Status.BAD_REQUEST).entity(jsonReturnObj.toString()).build();
		}
		logger.debug("Finished getObjectsDetails method");
		return Response.status(Response.Status.OK).entity(jsonReturnObj.toString()).build();
	}

	/**
	 * Method to get all basic info and attributes of an multiple objects
	 * 
	 * @param context
	 * @param sObjectIdsPipe
	 * @return JSONObject
	 * @throws FrameworkException
	 */
	public JSONArray getObjectsInfo(Context context, String sObjectIdsPipe) throws FrameworkException {
		logger.debug("Started getObjectsInfo method");
		JSONArray jsArrItems = new JSONArray();

		StringList strlObjList = new StringList(5);
		strlObjList.add(DomainConstants.SELECT_TYPE);
		strlObjList.add(DomainConstants.SELECT_NAME);
		strlObjList.add(DomainConstants.SELECT_ID);
		strlObjList.add(DomainConstants.SELECT_CURRENT);
		strlObjList.add("attribute[" + BossApplicationConstants.EIN + "]");
		try {
			StringList strlObjIdList = StringUtil.split(sObjectIdsPipe, "|");
			int iSize = strlObjIdList.size();
			DomainObject domObject = null;
			Map<String, Object> mpMap = null;
			String strItemNumber = "";
			JSONObject mainObject = null;
			if (iSize > 0) {
				for (String strId : strlObjIdList) {
					mainObject = new JSONObject();
					domObject = DomainObject.newInstance(context, strId);
					if (null != domObject) {
						mpMap = domObject.getInfo(context, strlObjList);
						if (null != mpMap && !mpMap.isEmpty()) {
							mainObject.put(DomainConstants.SELECT_TYPE, mpMap.get(DomainConstants.SELECT_TYPE));
							mainObject.put(DomainConstants.SELECT_NAME, mpMap.get(DomainConstants.SELECT_NAME));
							mainObject.put(DomainConstants.SELECT_ID, mpMap.get(DomainConstants.SELECT_ID));
							mainObject.put(DomainConstants.SELECT_CURRENT, mpMap.get(DomainConstants.SELECT_CURRENT));
							strItemNumber = (String) mpMap.get("attribute[" + BossApplicationConstants.EIN + "]");
							if (UIUtil.isNotNullAndNotEmpty(strItemNumber)) {
								mainObject.put(BossApplicationConstants.ITEM_NUMBER, strItemNumber);
							}
							jsArrItems.put(mainObject);
						}
					}
				}
			}
		} catch (Exception ex) {
			logger.error("Error in getObjectsInfo:", ex);
			logger.debug("Finished getObjectsInfo method");
			throw new FrameworkException(ex);
		}
		logger.debug("Finished getObjectsInfo method");
		return jsArrItems;
	}

	/**
	 * This method is used to get the MBOM objects
	 * 
	 * @param context
	 * @param sObjectIdPipe
	 * @return Response
	 * @throws FrameworkException
	 */
	public Response getBOMObjectsDetails(Context context, String sObjectIdPipe) throws FrameworkException {
		logger.debug("Started getBOMObjectDetails method");
		JSONObject jsonReturnObj = new JSONObject();
		try {
			JSONObject mainObject = getMBOMObjectsInfo(context, sObjectIdPipe);
			jsonReturnObj.put(BossApplicationConstants.STRING_STATUS, BossApplicationConstants.STATUS_SUCCESS);
			jsonReturnObj.put(BossApplicationConstants.STRING_DATA, mainObject);
		} catch (Exception ex) {
			logger.error("Error in getBOMObjectDetails:", ex);
			logger.debug("Finished getBOMObjectDetails method");
			jsonReturnObj.put(BossApplicationConstants.STRING_STATUS, BossApplicationConstants.STATUS_ERROR);
			jsonReturnObj.put(BossApplicationConstants.STATUS_ERROR, ex.getMessage());
			return Response.status(Response.Status.BAD_REQUEST).entity(jsonReturnObj.toString()).build();
		}
		logger.debug("Finished getBOMObjectDetails method");
		return Response.status(Response.Status.OK).entity(jsonReturnObj.toString()).build();
	}

	/**
	 * Method to get the attributes of an multiple MBOM objects
	 * 
	 * @param context
	 * @param sObjectIdsPipe
	 * @return JSONObject
	 * @throws FrameworkException
	 */
	public JSONObject getMBOMObjectsInfo(Context context, String sObjectIdsPipe) throws FrameworkException {
		logger.debug("Started getMBOMObjectInfo method");
		JSONObject jsResponse = new JSONObject();
		try {
			StringList strlObjIdList = StringUtil.split(sObjectIdsPipe, "|");
			int iSize = strlObjIdList.size();
			DomainObject domObject = null;
			Map<String, Object> mpMap = null;
			String strItemNumber = "";
			JSONObject mainObject = null;
			JSONArray jsonItems = null;
			if (iSize > 0) {
				for (String strId : strlObjIdList) {
					jsonItems = getMBOMItems(context, strId);
					if (jsonItems != null) {
						jsResponse.put(strId, jsonItems);
					}
				}
			}
		} catch (Exception ex) {
			logger.error("Error in getMBOMObjectInfo:", ex);
			logger.debug("Finished getMBOMObjectInfo method");
			throw new FrameworkException(ex);
		}
		logger.debug("Finished getMBOMObjectInfo method");
		return jsResponse;
	}

	/**
	 * Method to get the MBOM objects
	 * 
	 * @param context
	 * @param strObjId
	 * @return JSONArray
	 * @throws FrameworkException
	 */
	public JSONArray getMBOMItems(Context context, String strObjId) throws FrameworkException {
		logger.debug("Started getMBOMItems method");
		JSONArray jsArrResponse = new JSONArray();
		try {
			StringList strlObjList = new StringList(15);
			strlObjList.add(DomainConstants.SELECT_TYPE);
			strlObjList.add(DomainConstants.SELECT_NAME);
			strlObjList.add(DomainConstants.SELECT_ID);
			strlObjList.add(DomainConstants.SELECT_LEVEL);
			strlObjList.add(DomainConstants.SELECT_CURRENT);
			strlObjList.add(BossApplicationConstants.SELECT_V_NAME);
			strlObjList.add(BossApplicationConstants.SELECT_EIN);
			strlObjList.add(BossApplicationConstants.SELECT_ATTRIBUTE_NK_PARTS_NAME);
			strlObjList.add(DomainConstants.SELECT_REVISION);
			strlObjList.add(BossApplicationConstants.SELECT_ATTRIBUTE_NK_REVISION);
			strlObjList.add(BossApplicationConstants.SELECT_ATTRIBUTE_NK_FLAG_OF_OUTSOURCING_BOSS);
			strlObjList.add(BossApplicationConstants.SELECT_ATTRIBUTE_NK_BOMLIFECYCLE);
			strlObjList.add(BossApplicationConstants.SELECT_ATTRIBUTE_NK_WORK_PROCEDURE_INSTRUCTION);
			strlObjList.add(BossApplicationConstants.SELECT_ATTRIBUTE_NK_PARTS_TYPE);
			strlObjList.add(BossApplicationConstants.SELECT_ATTRIBUTE_NK_AUXILIARY_MATERIAL_CLASS);

			StringList strlRelList = new StringList(5);
			strlRelList.add("from");
			strlRelList.add(DomainRelationship.SELECT_ID);
			strlRelList.add(BossApplicationConstants.SELECT_ATTRIBUTE_NK_FLAG_NO_BOSS);
			strlRelList.add(BossApplicationConstants.SELECT_ATTRIBUTE_NK_NUMERATOR);
			strlRelList.add(BossApplicationConstants.SELECT_ATTRIBUTE_NK_CLASS_MATERIAL);

			DomainObject domObject = DomainObject.newInstance(context, strObjId);
			Map<String,String> mpObjInfo = domObject.getInfo(context, strlObjList);
			mpObjInfo.put("level", "0");
			JSONObject jsonParent = new JSONObject(mpObjInfo);
			jsArrResponse.put(jsonParent);

			Pattern pTypePatten = new Pattern(BossApplicationConstants.TYPE_CREATE_ASSEMBLY);
			pTypePatten.addPattern(BossApplicationConstants.TYPE_PROVIDE);

			MapList mlObjList = domObject.getRelatedObjects(context,
					BossApplicationConstants.REL_DELFMI_FUNCTION_INSTANCE, pTypePatten.getPattern(), strlObjList,
					strlRelList, false, true, (short) 2, null, null, 0);

			int iLen = mlObjList.size();
			if (iLen > 0) {
				Map<?, ?> mpMap = null;
				JSONObject json = null;
				for (int i = 0; i < iLen; i++) {
					mpMap = (Map<?, ?>) mlObjList.get(i);
					if (mpMap != null) {
						json = new JSONObject(mpMap);
						jsArrResponse.put(json);
					}
				}
			}
		} catch (Exception ex) {
			logger.error("Error in getMBOMItems:", ex);
			logger.debug("Finished getMBOMItems method");
			throw ex;
		}
		logger.debug("Finished getMBOMItems method");
		return jsArrResponse;
	}

	/**
	 * This method is to update relationship attributes
	 * 
	 * @param context
	 * @param strJsonIn
	 * @return Response
	 * @throws FrameworkException
	 */
	public Response updateRelAttribute(Context context, String strJsonIn) throws FrameworkException {
		logger.debug("Started updateRelAttribute method");
		JSONObject jsonReturnObj = new JSONObject();
		try {
			JSONObject jsonObject = new JSONObject(strJsonIn);
			JSONArray jsArrRelIds = jsonObject.getJSONArray(BossApplicationConstants.KEY_RELIDS);
			String strAttrName = jsonObject.getString(BossApplicationConstants.KEY_ATTRNAME);
			String strAttrValue = jsonObject.getString(BossApplicationConstants.KEY_ATTRVALUE);
			int iLen = jsArrRelIds.length();
			String strRelId = DomainConstants.EMPTY_STRING;
			DomainRelationship domRel = null;
			for (int i = 0; i < iLen; i++) {
				strRelId = jsArrRelIds.getString(i);
				domRel = DomainRelationship.newInstance(context, strRelId);
				if (domRel != null) {
					domRel.setAttributeValue(context, strAttrName, strAttrValue);
				}
			}
			jsonReturnObj.put(BossApplicationConstants.STRING_STATUS, BossApplicationConstants.STATUS_SUCCESS);
		} catch (Exception ex) {
			logger.error("Error in updateRelAttribute:", ex);
			logger.debug("Finished updateRelAttribute method");
			jsonReturnObj.put(BossApplicationConstants.STRING_STATUS, BossApplicationConstants.STATUS_ERROR);
			jsonReturnObj.put(BossApplicationConstants.STATUS_ERROR, ex.getMessage());
			return Response.status(Response.Status.BAD_REQUEST).entity(jsonReturnObj.toString()).build();
		}
		logger.debug("Finished updateRelAttribute method");
		return Response.status(Response.Status.OK).entity(jsonReturnObj.toString()).build();
	}

	/**
	 * This method is to update object attributes
	 * 
	 * @param context
	 * @param strJsonIn
	 * @return Response
	 * @throws FrameworkException
	 */
	public Response updateObjAttribute(Context context, String strJsonIn) throws FrameworkException {
		logger.debug("Started updateObjAttribute method");
		JSONObject jsonReturnObj = new JSONObject();
		try {
			JSONObject jsonObject = new JSONObject(strJsonIn);
			JSONArray jsArrObjIds = jsonObject.getJSONArray(BossApplicationConstants.KEY_IDS);
			String strAttrName = jsonObject.getString(BossApplicationConstants.KEY_ATTRNAME);
			String strAttrValue = jsonObject.getString(BossApplicationConstants.KEY_ATTRVALUE);
			int iLen = jsArrObjIds.length();
			String strObjId = DomainConstants.EMPTY_STRING;
			DomainObject domObj = null;
			for (int i = 0; i < iLen; i++) {
				strObjId = jsArrObjIds.getString(i);
				domObj = DomainObject.newInstance(context, strObjId);
				if (domObj != null) {
					domObj.setAttributeValue(context, strAttrName, strAttrValue);
				}
			}
			jsonReturnObj.put(BossApplicationConstants.STRING_STATUS, BossApplicationConstants.STATUS_SUCCESS);
		} catch (Exception ex) {
			logger.error("Error in updateObjAttribute:", ex);
			logger.debug("Finished updateObjAttribute method");
			jsonReturnObj.put(BossApplicationConstants.STRING_STATUS, BossApplicationConstants.STATUS_ERROR);
			jsonReturnObj.put(BossApplicationConstants.STATUS_ERROR, ex.getMessage());
			return Response.status(Response.Status.BAD_REQUEST).entity(jsonReturnObj.toString()).build();
		}
		logger.debug("Finished updateObjAttribute method");
		return Response.status(Response.Status.OK).entity(jsonReturnObj.toString()).build();
	}

	/**
	 * This method is for Lifecycle Phase process for MBOM object
	 * 
	 * @param context
	 * @param sObjectId
	 * @return Response
	 * @throws FrameworkException
	 */
	public Response setLifeCyclePhaseProcess(Context context, String sObjectId, String strValue)
			throws FrameworkException {
		logger.debug("Started setLifeCyclePhaseProcess method");
		JSONObject jsonReturnObj = new JSONObject();
		try {
			JSONArray jsonArr = setLifeCyclePhase(context, sObjectId, strValue);
			jsonReturnObj.put(BossApplicationConstants.STRING_STATUS, BossApplicationConstants.STATUS_SUCCESS);
			jsonReturnObj.put(BossApplicationConstants.STRING_DATA, jsonArr);
		} catch (Exception ex) {
			logger.error("Error in setLifeCyclePhaseProcess:", ex);
			logger.debug("Finished setLifeCyclePhaseProcess method");
			jsonReturnObj.put(BossApplicationConstants.STRING_STATUS, BossApplicationConstants.STATUS_ERROR);
			jsonReturnObj.put(BossApplicationConstants.STATUS_ERROR, ex.getMessage());
			return Response.status(Response.Status.BAD_REQUEST).entity(jsonReturnObj.toString()).build();
		}
		logger.debug("Finished setLifeCyclePhaseProcess method");
		return Response.status(Response.Status.OK).entity(jsonReturnObj.toString()).build();
	}

	/**
	 * This method is for Lifecycle Phase process for MBOM object
	 * 
	 * @param context
	 * @param sObjectId
	 * @return JSONObject
	 * @throws FrameworkException
	 */
	public JSONArray setLifeCyclePhase(Context context, String sObjectId, String strLifeCycle)
			throws FrameworkException {
		JSONArray jsArrData = new JSONArray();
		logger.debug("Started setLifeCyclePhase method");
		try {
			DomainObject domObj = DomainObject.newInstance(context, sObjectId);

			StringList strlObjList = new StringList(15);
			strlObjList.add(DomainConstants.SELECT_TYPE);
			strlObjList.add(DomainConstants.SELECT_NAME);
			strlObjList.add(DomainConstants.SELECT_ID);
			strlObjList.add(DomainConstants.SELECT_LEVEL);
			strlObjList.add(DomainConstants.SELECT_CURRENT);
			strlObjList.add(BossApplicationConstants.SELECT_V_NAME);
			strlObjList.add(BossApplicationConstants.SELECT_EIN);
			strlObjList.add(BossApplicationConstants.SELECT_ATTRIBUTE_NK_PARTS_NAME);
			strlObjList.add(DomainConstants.SELECT_REVISION);
			strlObjList.add(BossApplicationConstants.SELECT_ATTRIBUTE_NK_TYPE_BOSS_ITEM);
			strlObjList.add(BossApplicationConstants.SELECT_ATTRIBUTE_NK_BOMLIFECYCLE);
			strlObjList.add(BossApplicationConstants.SELECT_ATTRIBUTE_NK_WORK_PROCEDURE_INSTRUCTION);
			strlObjList.add(DomainConstants.SELECT_LOCKED);
			strlObjList.add(DomainConstants.SELECT_LOCKER);

			StringList strlRelList = new StringList(5);
			strlRelList.add("from");
			strlRelList.add(DomainRelationship.SELECT_ID);
			strlRelList.add(BossApplicationConstants.SELECT_ATTRIBUTE_NK_FLAG_NO_BOSS);
			strlRelList.add(BossApplicationConstants.SELECT_ATTRIBUTE_NK_CLASS_MATERIAL);

			Pattern pTypePatten = new Pattern(BossApplicationConstants.TYPE_CREATE_ASSEMBLY);
			pTypePatten.addPattern(BossApplicationConstants.TYPE_PROVIDE);

			Map<?, ?> mpParentInfo = domObj.getInfo(context, strlObjList);
			String strParentLocked = (String) mpParentInfo.get(DomainConstants.SELECT_LOCKED);
			String strParentTitle = (String) mpParentInfo.get(BossApplicationConstants.SELECT_V_NAME);
			String strParentTypeBossItem = (String) mpParentInfo
					.get(BossApplicationConstants.SELECT_ATTRIBUTE_NK_TYPE_BOSS_ITEM);
			JSONObject jsonItem = new JSONObject();
			JSONObject jsonErr = new JSONObject();

			if ("FALSE".equals(strParentLocked)) {
				HashMap<String, String> hParentMap = checkObjectAttributes(mpParentInfo);
				if ("true".equals(hParentMap.get("attr_check"))) {
					domObj.lock(context);
					Boolean bUpdated = updateLifeCyclePhaseSet(context, strLifeCycle, strParentTypeBossItem, domObj);
					jsonItem.put("updated", bUpdated);
				} else {
					jsonErr.put("attr_miss", hParentMap.get("attr_miss"));
				}

				MapList mlObjList = domObj.getRelatedObjects(context,
						BossApplicationConstants.REL_DELFMI_FUNCTION_INSTANCE, pTypePatten.getPattern(), strlObjList,
						strlRelList, true, false, (short) 1, null, null, 0);
				if (mlObjList.isEmpty() || mlObjList == null) {
					MapList mlObjChildList = domObj.getRelatedObjects(context,
							BossApplicationConstants.REL_DELFMI_FUNCTION_INSTANCE, pTypePatten.getPattern(),
							strlObjList, strlRelList, false, true, (short) 2, null, null, 0);
					int iLen = mlObjChildList.size();
					if (iLen > 0) {
						Map<?, ?> mpMap = null;
						for (int i = 0; i < iLen; i++) {
							mpMap = (Map<?, ?>) mlObjChildList.get(i);
							if (mpMap != null) {
								allAttributesCheck(context, mpMap, jsArrData, strLifeCycle);
							}
						}
					}
				} else {
					int iSize = mlObjList.size();
					if (iSize > 0) {
						Map<?, ?> mpMap = (Map<?, ?>) mlObjList.get(0);
						allAttributesCheck(context, mpMap, jsArrData, strLifeCycle);
					}
				}
			} else {
				jsonErr.put("lock", "true");
			}
			if (jsonErr.length() > 0) {
				jsonItem.put("all_checks", false);
				jsonItem.put("itemName", strParentTitle);
				jsonItem.put("errors", jsonErr);
			} else {
				jsonItem.put("all_checks", true);
				jsonItem.put("itemName", strParentTitle);
			}
			jsArrData.put(jsonItem);
		} catch (Exception ex) {
			logger.error("Error in setLifeCyclePhase:", ex);
			logger.debug("Finished setLifeCyclePhase method");
		}
		logger.debug("Finished setLifeCyclePhase method");
		return jsArrData;
	}

	public Boolean updateLifeCyclePhaseSet(Context context, String strLifeCycle, String strTypeBossItem,
			DomainObject domChildObj) throws FrameworkException {
		logger.debug("Started updateLifeCyclePhaseSet method");
		Boolean bUpdated = false;
		try {
			if (BossApplicationConstants.KEY_PROCUREMENT.equals(strLifeCycle)) {
				String strPropValue = readPageObject(context, BossApplicationConstants.NK_LIFECYCLE_PROPERTIES,
						"LifeCycle.BOSSItemType.BOSSTerget.Pattern");

				if (strPropValue.contains(strTypeBossItem)) {
					String strBOMLCValue = readPageObject(context, BossApplicationConstants.NK_LIFECYCLE_PROPERTIES,
							"LifeCycle.BomLifecycle.Option.Supply");
					domChildObj.setAttributeValue(context, BossApplicationConstants.ATTRIBUTE_NK_BOMLIFECYCLE,
							strBOMLCValue);
					bUpdated = true;
				}
			} else if (BossApplicationConstants.KEY_MANUFACTURING.equals(strLifeCycle)) {
				String strPropValue = readPageObject(context, BossApplicationConstants.NK_LIFECYCLE_PROPERTIES,
						"LifeCycle.BOSSItemType.WorkInstruction.Pattern");
				if (strPropValue.contains(strTypeBossItem)) {
					String strWorkIncValue = readPageObject(context, BossApplicationConstants.NK_LIFECYCLE_PROPERTIES,
							"LifeCycle.WorkInstruction.Pattern");
					String strBOMLCValue = readPageObject(context, BossApplicationConstants.NK_LIFECYCLE_PROPERTIES,
							"LifeCycle.BomLifecycle.Option.Manufacture");

					HashMap<String, String> mpMfgMap = new HashMap<String, String>();
					mpMfgMap.put(BossApplicationConstants.ATTRIBUTE_NK_BOMLIFECYCLE, strBOMLCValue);
					mpMfgMap.put(BossApplicationConstants.ATTRIBUTE_NK_WORK_PROCEDURE_INSTRUCTION, strWorkIncValue);

					domChildObj.setAttributeValues(context, mpMfgMap);
					bUpdated = true;
				}
			}
		} catch (Exception ex) {
			logger.error("Error in updateLifeCyclePhaseSet:", ex);
			logger.debug("Finished updateLifeCyclePhaseSet method");
			ex.printStackTrace();
			throw ex;
		}
		logger.debug("Completed updateLifeCyclePhaseSet method");
		return bUpdated;
	}

	/**
	 * This method is to prepare validation list for each object
	 * 
	 * @param context
	 * @param mpMap
	 * @return Boolean
	 * @throws Exception 
	 */
	public void allAttributesCheck(Context context, Map<?, ?> mpMap, JSONArray jsArrData, String strLifeCycle)
			throws MatrixException {
		logger.debug("Started allAttributesCheck method");
		try {
			JSONObject jsElement = new JSONObject();
			JSONObject jsError = new JSONObject();
			String strLocked = (String) mpMap.get(DomainConstants.SELECT_LOCKED);
			String strTitle = (String) mpMap.get(BossApplicationConstants.SELECT_V_NAME);
			String strChildId = (String) mpMap.get(DomainConstants.SELECT_ID);
			String strTypeBossItem = (String) mpMap.get(BossApplicationConstants.SELECT_ATTRIBUTE_NK_TYPE_BOSS_ITEM);
			Boolean bValid = false;
			if (BossApplicationConstants.KEY_FALSE.equals(strLocked)) {
				HashMap<String, String> hChildMap = checkObjectAttributes(mpMap);
				if ("true".equals(hChildMap.get("attr_check"))) {
					bValid = true;
				} else {
					jsError.put("attr_miss", hChildMap.get("attr_miss"));
				}

				HashMap<String, String> hChildRelMap = checkRelAttributes(mpMap);
				if ("true".equals(hChildRelMap.get("attr_check"))) {
					bValid = true;
				} else {
					jsError.put("rel_attr_miss", hChildRelMap.get("attr_miss"));
				}
			} else {
				jsError.put("lock", "true");
			}
			jsElement.put("itemName", strTitle);
			if (jsError.length() > 0) {
				jsElement.put("all_checks", false);
				jsElement.put("errors", jsError);
			} else {
				jsElement.put("all_checks", true);
			}

			if (bValid) {
				DomainObject domChildObj = DomainObject.newInstance(context, strChildId);
				domChildObj.lock(context);
				Boolean bUpdate = updateLifeCyclePhaseSet(context, strLifeCycle, strTypeBossItem, domChildObj);
				jsElement.put("updated", bUpdate);
			}
			jsArrData.put(jsElement);
		} catch (Exception ex) {
			logger.error("Error in allAttributesCheck:", ex);
			logger.debug("Finished allAttributesCheck method");
			throw ex;
		}
		logger.debug("Started allAttributesCheck method");
	}

	/**
	 * This method is check attributes of an object
	 * 
	 * @param context
	 * @param mpMap
	 * @return Boolean
	 * @throws FrameworkException
	 */
	public HashMap<String, String> checkObjectAttributes(Map<?, ?> mpMap) throws FrameworkException {
		HashMap<String, String> hmMap = new HashMap<String, String>();
		logger.debug("Started checkObjectAttributes method");
		try {
			String strTypeBossItem = (String) mpMap.get(BossApplicationConstants.SELECT_ATTRIBUTE_NK_TYPE_BOSS_ITEM);
			String strBOMLifeCycle = (String) mpMap.get(BossApplicationConstants.SELECT_ATTRIBUTE_NK_BOMLIFECYCLE);
			StringBuilder sbError = new StringBuilder();
			if (UIUtil.isNullOrEmpty(strTypeBossItem)) {
				sbError.append("NK_TYPE_BOSS_ITEM");
			}
			if (UIUtil.isNullOrEmpty(strBOMLifeCycle)) {
				sbError.append("NK_BOMLIFECYCLE");
			}

			if (sbError.length() > 0) {
				hmMap.put("attr_check", "false");
				hmMap.put("attr_miss", sbError.toString());
			} else {
				hmMap.put("attr_check", "true");
				hmMap.put("attr_miss", sbError.toString());
			}
		} catch (Exception ex) {
			logger.error("Error in checkObjectAttributes:", ex);
			logger.debug("Finished checkObjectAttributes method");
			throw ex;
		}
		logger.debug("Started checkObjectAttributes method");
		return hmMap;
	}

	/**
	 * This method is check rel attributes of an object
	 * 
	 * @param context
	 * @param mpMap
	 * @return Boolean
	 * @throws FrameworkException
	 */
	public HashMap<String, String> checkRelAttributes(Map<?, ?> mpMap) throws FrameworkException {
		HashMap<String,String> hmMap = new HashMap<String, String>();
		logger.debug("Started checkObjectAttributes method");
		try {
			String strNKFlagNoBoss = (String) mpMap.get(BossApplicationConstants.SELECT_ATTRIBUTE_NK_FLAG_NO_BOSS);
			String strNKClassMaterial = (String) mpMap.get(BossApplicationConstants.SELECT_ATTRIBUTE_NK_CLASS_MATERIAL);
			StringBuilder sbError = new StringBuilder();
			if (UIUtil.isNullOrEmpty(strNKFlagNoBoss)) {
				sbError.append("NK_FLAG_NO_BOSS");
			}
			if (UIUtil.isNullOrEmpty(strNKClassMaterial)) {
				sbError.append("NK_CLASS_MATERIAL");
			}

			if (sbError.length() > 0) {
				hmMap.put("attr_check", "false");
				hmMap.put("attr_miss", sbError.toString());
			} else {
				hmMap.put("attr_check", "true");
				hmMap.put("attr_miss", sbError.toString());
			}
		} catch (Exception ex) {
			logger.error("Error in checkObjectAttributes:", ex);
			logger.debug("Finished checkObjectAttributes method");
			throw ex;
		}
		logger.debug("Started checkObjectAttributes method");
		return hmMap;
	}

	/**
	 * Read Property File Values.
	 *
	 * @param context
	 * @param strPageName
	 * @param strKeyName
	 * @throws Exception
	 */
	public static String readPageObject(Context context, String strPageName, String strKeyName) throws FrameworkException {
		logger.debug("Started readPageObject method");
		Properties propNotification = new Properties();
		String strProperty = DomainConstants.EMPTY_STRING;
		try {
			ContextUtil.pushContext(context, "User Agent", null, null);
			Page pageAttributePopulation = new Page(strPageName);
			pageAttributePopulation.open(context);
			String strProperties = pageAttributePopulation.getContents(context);
			pageAttributePopulation.close(context);
			InputStream input = new ByteArrayInputStream(strProperties.getBytes("UTF8"));
			propNotification.load(input);
			strProperty = propNotification.getProperty(strKeyName);
			ContextUtil.popContext(context);
		} catch (Exception e) {
			logger.error("Error in readPageObject:", e);
					}
		logger.debug("Finished readPageObject method");
		return strProperty;
	}

	/**
	 * This method is used to get the EBOM objects
	 * 
	 * @param context
	 * @param sObjectId
	 * @return Response
	 * @throws FrameworkException
	 */
	public Response getEBOMObjectsDetails(Context context, String sObjectIdPipe) throws FrameworkException {
		logger.debug("Started getBOMObjectDetails method");
		JSONObject jsonReturnObj = new JSONObject();
		try {
			JSONObject mainObject = getEBOMObjectsInfo(context, sObjectIdPipe);
			jsonReturnObj.put(BossApplicationConstants.STRING_STATUS, BossApplicationConstants.STATUS_SUCCESS);
			jsonReturnObj.put(BossApplicationConstants.STRING_DATA, mainObject);
		} catch (Exception ex) {
			logger.error("Error in getBOMObjectDetails:", ex);
			logger.debug("Finished getBOMObjectDetails method");
			jsonReturnObj.put(BossApplicationConstants.STRING_STATUS, BossApplicationConstants.STATUS_ERROR);
			jsonReturnObj.put(BossApplicationConstants.STATUS_ERROR, ex.getMessage());
			return Response.status(Response.Status.BAD_REQUEST).entity(jsonReturnObj.toString()).build();
		}
		logger.debug("Finished getBOMObjectDetails method");
		return Response.status(Response.Status.OK).entity(jsonReturnObj.toString()).build();
	}

	/**
	 * Method to get the attributes of an multiple EBOM objects
	 * 
	 * @param context
	 * @param sObjectIdsPipe
	 * @return JSONObject
	 * @throws FrameworkException
	 */
	public JSONObject getEBOMObjectsInfo(Context context, String sObjectIdsPipe) throws FrameworkException {
		logger.debug("Started getMBOMObjectInfo method");
		JSONObject jsResponse = new JSONObject();
		try {
			StringList strlObjIdList = StringUtil.split(sObjectIdsPipe, "|");
			int iSize = strlObjIdList.size();
			DomainObject domObject = null;
			Map<String, Object> mpMap = null;
			String strItemNumber = "";
			JSONObject mainObject = null;
			JSONArray jsonItems = null;
			if (iSize > 0) {
				for (String strId : strlObjIdList) {
					jsonItems = getEBOMObjectInfo(context, strId);
					if (jsonItems != null) {
						jsResponse.put(strId, jsonItems);
					}
				}
			}
		} catch (Exception ex) {
			logger.error("Error in getMBOMObjectInfo:", ex);
			logger.debug("Finished getMBOMObjectInfo method");
			throw new FrameworkException(ex);
		}
		logger.debug("Finished getMBOMObjectInfo method");
		return jsResponse;
	}

	/**
	 * Method to get the attributes of an EBOM objects
	 * 
	 * @param context
	 * @param sObjectId
	 * @return JSONObject
	 * @throws FrameworkException
	 */

	public JSONArray getEBOMObjectInfo(Context context, String sObjectId) throws FrameworkException {
		logger.debug("Started getEBOMObjectInfo method");
		JSONArray jsArrResponse = new JSONArray();

		StringList strlObjList = new StringList(15);
		strlObjList.add(DomainConstants.SELECT_TYPE);
		strlObjList.add(DomainConstants.SELECT_NAME);
		strlObjList.add(DomainConstants.SELECT_ID);
		strlObjList.add(DomainConstants.SELECT_LEVEL);
		strlObjList.add(DomainConstants.SELECT_CURRENT);
		strlObjList.add(BossApplicationConstants.SELECT_V_NAME);
		strlObjList.add(BossApplicationConstants.SELECT_EIN);
		strlObjList.add(BossApplicationConstants.SELECT_ATTRIBUTE_NK_PARTS_NAME);
		strlObjList.add(DomainConstants.SELECT_REVISION);
		strlObjList.add(BossApplicationConstants.SELECT_ATTRIBUTE_NK_REVISION);
		strlObjList.add(BossApplicationConstants.SELECT_ATTRIBUTE_NK_PARTS_TYPE);
		strlObjList.add(BossApplicationConstants.SELECT_ATTRIBUTE_NK_MATERIALS_FORM_CLASSIFICATION);
		strlObjList.add(BossApplicationConstants.SELECT_ATTRIBUTE_NK_PHARMACEUTICAL_PARTS_CORD);
		strlObjList.add(BossApplicationConstants.SELECT_ATTRIBUTE_NK_KNOWLEDGE_CATEGORY);
		strlObjList.add(BossApplicationConstants.SELECT_ATTRIBUTE_NK_TYPE_PRODUCT);
		strlObjList.add(BossApplicationConstants.SELECT_ATTRIBUTE_NK_TRACE_TYPE);

		StringList strlRelList = new StringList(4);
		strlRelList.add("from");
		strlRelList.add(BossApplicationConstants.SELECT_ATTRIBUTE_NK_FLAG_NO_BOSS);
		strlRelList.add(BossApplicationConstants.SELECT_ATTRIBUTE_NK_NUMERATOR);
		strlRelList.add(BossApplicationConstants.SELECT_ATTRIBUTE_NK_CLASS_MATERIAL);

		try {
			DomainObject domObject = DomainObject.newInstance(context, sObjectId);
			Map<String, String> mpObjInfo = domObject.getInfo(context, strlObjList);
			mpObjInfo.put("level", "0");
			JSONObject jsonParent = new JSONObject(mpObjInfo);
			jsArrResponse.put(jsonParent);

			Pattern pTypePatten = new Pattern(BossApplicationConstants.TYPE_VPMREFERENCE);

			MapList mlObjList = domObject.getRelatedObjects(context, BossApplicationConstants.REL_VPMINSTANCE,
					pTypePatten.getPattern(), strlObjList, strlRelList, false, true, (short) 2, null, null, 0);

			int iLen = mlObjList.size();
			if (iLen > 0) {
				Map<?, ?> mpMap = null;
				JSONObject json = null;
				for (int i = 0; i < iLen; i++) {
					mpMap = (Map<?, ?>) mlObjList.get(i);
					if (mpMap != null) {
						json = new JSONObject(mpMap);
						jsArrResponse.put(json);
					}
				}
			}
		} catch (Exception ex) {
			logger.error("Error in getEBOMObjectInfo:", ex);
			logger.debug("Finished getEBOMObjectInfo method");
			throw new FrameworkException(ex);
		}
		logger.debug("Finished getEBOMObjectInfo method");
		return jsArrResponse;
	}
}
