package com.nk.bossapplication;

import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.dassault_systemes.platform.restServices.RestService;
import com.nk.bossapplication.BossApplicationProcess;

import matrix.db.Context;

@Path("/bossMfg")
public class BossApplicationServices extends RestService {
	private static final Logger logger = LoggerFactory.getLogger("BossApplication");
	private BossApplicationProcess bossAppProcess = new BossApplicationProcess();

	@GET
	@Path("/getObjectsDetails/{id}")
	@Produces(MediaType.APPLICATION_JSON)
	public Response getObjectsDetails(@javax.ws.rs.core.Context HttpServletRequest request,
			@PathParam("id") String strOjectIdsPipe) {
		logger.debug("Started getObjectDetails method");
		Response res = null;
		try {
			Context context = this.getAuthenticatedContext(request, false);
			return bossAppProcess.getObjectsDetails(context, strOjectIdsPipe);
		} catch (Exception ex) {
			logger.error("Error in getObjectDetails: ", ex);
			logger.debug("Finished getObjectDetails method");
			res = Response.status(Response.Status.BAD_REQUEST).entity(ex.getMessage()).build();
		}
		logger.debug("Finished getObjectDetails method");
		return res;
	}

	@GET
	@Path("/getMBOMObjChilds/{id}")
	@Produces(MediaType.APPLICATION_JSON)
	public Response getMBOMObjChildDetails(@javax.ws.rs.core.Context HttpServletRequest request,
			@PathParam("id") String strOjectIdPipe) {
		logger.debug("Started getMBOMObjChildDetails method");
		Response res = null;
		try {
			Context context = this.getAuthenticatedContext(request, false);
			return bossAppProcess.getBOMObjectsDetails(context, strOjectIdPipe);
		} catch (Exception ex) {
			logger.error("Error in getMBOMObjChildDetails: ", ex);
			logger.debug("Finished getMBOMObjChildDetails method");
			res = Response.status(Response.Status.BAD_REQUEST).entity(ex.getMessage()).build();
		}
		logger.debug("Finished getMBOMObjChildDetails method");
		return res;
	}

	@POST
	@Path("/updateRelAttribute")
	@Produces(MediaType.APPLICATION_JSON)
	@Consumes(MediaType.APPLICATION_JSON)
	public Response updateRelAttribute(@javax.ws.rs.core.Context HttpServletRequest request, String sInput) {
		logger.debug("Started updateRelAttribute method");
		Response res = null;
		try {
			Context context = this.getAuthenticatedContext(request, false);
			return bossAppProcess.updateRelAttribute(context, sInput);
		} catch (Exception ex) {
			logger.error("Error in updateRelAttribute", ex);
			logger.debug("Finished updateRelAttribute method");
			res = Response.status(Response.Status.BAD_REQUEST).entity(ex.getMessage()).build();
		}
		logger.debug("Finished updateRelAttribute method");
		return res;
	}

	@POST
	@Path("/updateObjAttribute")
	@Produces(MediaType.APPLICATION_JSON)
	@Consumes(MediaType.APPLICATION_JSON)
	public Response updateObjAttribute(@javax.ws.rs.core.Context HttpServletRequest request, String sInput) {
		logger.debug("Started updateObjAttribute method");
		Response res = null;
		try {
			Context context = this.getAuthenticatedContext(request, false);
			return bossAppProcess.updateObjAttribute(context, sInput);
		} catch (Exception ex) {
			logger.error("Error in updateObjAttribute", ex);
			logger.debug("Finished updateObjAttribute method");
			res = Response.status(Response.Status.BAD_REQUEST).entity(ex.getMessage()).build();
		}
		logger.debug("Finished updateObjAttribute method");
		return res;
	}

	@GET
	@Path("/setLifeCyclePhase/{id}/{value}")
	@Produces(MediaType.APPLICATION_JSON)
	public Response setLifeCyclePhase(@javax.ws.rs.core.Context HttpServletRequest request,
			@PathParam("id") String strOjectId, @PathParam("value") String strValue) {
		logger.debug("Started getObjectDetails method");
		Response res = null;
		try {
			Context context = this.getAuthenticatedContext(request, false);
			return bossAppProcess.setLifeCyclePhaseProcess(context, strOjectId, strValue);
		} catch (Exception ex) {
			logger.error("Error in getObjectDetails: ", ex);
			logger.debug("Finished getObjectDetails method");
			res = Response.status(Response.Status.BAD_REQUEST).entity(ex.getMessage()).build();
		}
		logger.debug("Finished getObjectDetails method");
		return res;
	}

	@GET
	@Path("/getEBOMObjChilds/{id}")
	@Produces(MediaType.APPLICATION_JSON)
	public Response getEBOMObjChildDetails(@javax.ws.rs.core.Context HttpServletRequest request,
			@PathParam("id") String strOjectIdPipe) {
		logger.debug("Started getEBOMObjChildDetails method");
		Response res = null;
		try {
			Context context = this.getAuthenticatedContext(request, false);
			return bossAppProcess.getEBOMObjectsDetails(context, strOjectIdPipe);
		} catch (Exception ex) {
			logger.error("Error in getEBOMObjChildDetails: ", ex);
			logger.debug("Finished getEBOMObjChildDetails method");
			res = Response.status(Response.Status.BAD_REQUEST).entity(ex.getMessage()).build();
		}
		logger.debug("Finished getEBOMObjChildDetails method");
		return res;
	}
}
