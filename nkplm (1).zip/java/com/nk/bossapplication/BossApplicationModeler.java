package com.nk.bossapplication;
import javax.ws.rs.ApplicationPath;
import com.dassault_systemes.platform.restServices.ModelerBase;

@ApplicationPath("/bossModeler")
public class BossApplicationModeler extends ModelerBase{
	public Class<?>[] getServices() {
		return new Class[] {BossApplicationServices.class};
	}
}