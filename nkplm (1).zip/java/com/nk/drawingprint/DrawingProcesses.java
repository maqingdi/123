
/**
 * DrawingProcesses.java
 *
 * This class provides methods to perform DrawingProcesses.
 *
 * @Author: DSGS
 * @since: Version 1.0
 *
 * Modification Details:
 *
 *     Date   | User | Version | Comment
 * -----------|------|---------|--------------------------
 *  31/12/2024 DSGS    1.0      Utility Class to support web services Operations
 *  */

package com.nk.drawingprint;

import java.util.Iterator;
import java.util.Map;
import javax.ws.rs.core.Response;
import org.json.JSONObject;
import com.matrixone.apps.domain.DomainConstants;
import com.matrixone.apps.domain.DomainObject;
import com.matrixone.apps.domain.DomainSymbolicConstants;
import com.matrixone.apps.domain.util.FrameworkException;
import com.matrixone.apps.domain.util.MapList;
import com.matrixone.apps.domain.util.PropertyUtil;

import matrix.db.Context;
import matrix.util.StringList;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class DrawingProcesses {

	private static final Logger logger = LoggerFactory.getLogger("ItemNumbering");

	public DrawingProcesses(Context context) {
		// TODO Auto-generated constructor stub
	}

	/**
	 * This method is used to get the all attributes of MBOM Order
	 * 
	 * @param context
	 * @param sObjectId
	 * @return Response
	 * @throws FrameworkException
	 */
	public Response validateInstructions(Context context, String sObjectId) throws FrameworkException {
		logger.debug("Started validateInstructions method");
		JSONObject jsonReturnObj = new JSONObject();
		JSONObject data = new JSONObject();
		try {
			String EMAIL_ADDRESS = PropertyUtil.getSchemaProperty(context,
					DomainSymbolicConstants.SYMBOLIC_attribute_EmailAddress);
			DomainConstants.MULTI_VALUE_LIST.add("format.file.name");
			System.out.println("sObjectId : " + sObjectId);
			StringList objSelects = new StringList();
			objSelects.add(DomainConstants.SELECT_TYPE);
			objSelects.add(DomainConstants.SELECT_NAME);
			objSelects.add(DomainConstants.SELECT_REVISION);
			objSelects.add("attribute[" + DrawingConstants.ATTRIBUTE_TITLE + "]");
			objSelects.add("attribute[" + DrawingConstants.ATTRIBUTE_NK_DOCUMENT_NUMBER + "]");
			objSelects.add("attribute[" + DrawingConstants.ATTRIBUTE_NK_USER_REVISION + "]");
			objSelects.add("attribute[" + DrawingConstants.EIN + "]");
			objSelects.add(DomainConstants.SELECT_ID);
			objSelects.add(DomainConstants.SELECT_CURRENT);
			objSelects.add("format.file.name");

			Map<String, Object> map = getObjectInfo(context, sObjectId, objSelects);

			if (null != map && !map.isEmpty()) {
				String strUserName = context.getUser();
				System.out.println("strUserName : " + strUserName);
				System.out.println("EMAIL_ADDRESS : " + EMAIL_ADDRESS );
				StringList busPersonSelects = new StringList();
				busPersonSelects.add(DomainConstants.SELECT_ID);
				busPersonSelects.add("attribute["+EMAIL_ADDRESS+"]");
				
				System.out.println("busPersonSelects : " + busPersonSelects);
				
				MapList mpPersonList = DomainObject.findObjects(context, "Person", strUserName, "*", null,
						"eService Production", null, false, busPersonSelects);
				
				System.out.println("mpPersonList : " + mpPersonList);
				
				Map mpPerson = (Map) mpPersonList.get(0);
				data.put("User_Name", strUserName);
				data.put("Email_Address", (String)mpPerson.get("attribute["+EMAIL_ADDRESS+"]"));
				String strType = (String) map.get(DomainConstants.SELECT_TYPE);
				data.put(DomainConstants.SELECT_TYPE, strType);
				data.put(DomainConstants.SELECT_NAME, map.get(DomainConstants.SELECT_NAME));
				data.put(DomainConstants.SELECT_ID, map.get(DomainConstants.SELECT_ID));
				data.put(DomainConstants.SELECT_CURRENT, map.get(DomainConstants.SELECT_CURRENT));
				data.put(DomainConstants.SELECT_REVISION, map.get(DomainConstants.SELECT_REVISION));
				data.put(DrawingConstants.ATTRIBUTE_TITLE, map.get("attribute[" + DrawingConstants.ATTRIBUTE_TITLE + "]"));
				data.put(DrawingConstants.DOC_ITEM_NUMBER,
						map.get("attribute[" + DrawingConstants.ATTRIBUTE_NK_DOCUMENT_NUMBER + "]"));
				data.put(DrawingConstants.KEY_NK_USER_REVISION,
						map.get("attribute[" + DrawingConstants.ATTRIBUTE_NK_USER_REVISION + "]"));
				data.put(DrawingConstants.ITEM_NUMBER,
						map.get("attribute[" + DrawingConstants.EIN + "]"));	
				data.put("format.file.name", map.get("format.file.name"));

				if (strType != null && strType.equals(DrawingConstants.TYPE_VPMREFERENCE)) {

					// String objectWhere = "format.file.name != ''";
					DomainObject domObject = DomainObject.newInstance(context, sObjectId);
					MapList mlObjects = domObject.getRelatedObjects(context,
							DrawingConstants.RELATIONSHIP_SpecificationDocument + ","
									+ DrawingConstants.RELATIONSHIP_CAD_Dependency_Of,
							DrawingConstants.TYPE_DOCUMENT + "," + DrawingConstants.TYPE_DRAWING, objSelects, null,
							false, true, (short) 0, null, null, 0);
					System.out.println("mlObjects : " + mlObjects);
					if (mlObjects != null && mlObjects.size() > 0) {
						Iterator itr = mlObjects.iterator();
						while (itr.hasNext()) {
							data.put(DrawingConstants.DRAWING_AVAILABLE, DrawingConstants.YES);
							Map mpDPObj = (Map) itr.next();
							mpDPObj.put(DrawingConstants.ATTRIBUTE_TITLE, mpDPObj.get("attribute[" + DrawingConstants.ATTRIBUTE_TITLE + "]"));
							mpDPObj.remove("attribute[" + DrawingConstants.ATTRIBUTE_TITLE + "]");
							mpDPObj.put(DrawingConstants.DOC_ITEM_NUMBER, mpDPObj.get("attribute[" + DrawingConstants.ATTRIBUTE_NK_DOCUMENT_NUMBER + "]"));
							mpDPObj.remove("attribute[" + DrawingConstants.ATTRIBUTE_NK_DOCUMENT_NUMBER + "]");
							mpDPObj.put(DrawingConstants.KEY_NK_USER_REVISION, mpDPObj.get("attribute[" + DrawingConstants.ATTRIBUTE_NK_USER_REVISION + "]"));
							mpDPObj.remove("attribute[" + DrawingConstants.ATTRIBUTE_NK_USER_REVISION + "]");
							System.out.println("mpDPObj : " + mpDPObj);
							data.put("Drawing", mpDPObj);
							Object strFile = (Object) mpDPObj.get("format.file.name");
							System.out.println("strFile : " + strFile.getClass());
							if (strFile != null && !strFile.equals("")) {
								data.put(DrawingConstants.PDF_AVAILABLE, DrawingConstants.YES);
								break;
							} else {
								data.put(DrawingConstants.PDF_AVAILABLE, DrawingConstants.NO);
							}
						}
					} else {
						data.put(DrawingConstants.DRAWING_AVAILABLE, DrawingConstants.NO);
					}
				}

				jsonReturnObj.put(DrawingConstants.STRING_STATUS, DrawingConstants.STATUS_SUCCESS);
				jsonReturnObj.put(DrawingConstants.STRING_DATA, data);
			}
			logger.info("jsonReturnObj {} :", jsonReturnObj);
			System.out.println("jsonReturnObj : " + jsonReturnObj);
		} catch (Exception ex) {
			System.out.println("ex in validateInstructions : " + ex);
			logger.error("Error in validateInstructions:", ex);
			logger.debug("Finished validateInstructions method");
			jsonReturnObj.put(DrawingConstants.STRING_STATUS, DrawingConstants.STATUS_ERROR);
			jsonReturnObj.put(DrawingConstants.STATUS_ERROR, ex.getMessage());
			return Response.status(Response.Status.BAD_REQUEST).entity(jsonReturnObj.toString()).build();
		}
		logger.debug("Finished validateInstructions method");
		return Response.status(Response.Status.OK).entity(jsonReturnObj.toString()).build();
	}

	/**
	 * Method to get all basic info and attributes of an object
	 * 
	 * @param context
	 * @param sObjectId
	 * @return JSONObject
	 * @throws FrameworkException
	 */
	public Map getObjectInfo(Context context, String sObjectId, StringList objSelects) throws FrameworkException {
		logger.debug("Started getObjectInfo method");
		Map<String, Object> mainObject = null;

		try {
			DomainObject domObject = DomainObject.newInstance(context, sObjectId);
			mainObject = domObject.getInfo(context, objSelects);
			System.out.println("map : " + mainObject);
			logger.info("map {} :", mainObject);

		} catch (Exception ex) {
			logger.error("Error in getObjectInfo:", ex);
			logger.debug("Finished getObjectInfo method");
			throw new FrameworkException(ex);
		}
		logger.debug("Finished getObjectInfo method");
		return mainObject;
	}

}
