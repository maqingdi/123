/**
 * DrawingServices.java
 * 
 * This class defines the RESTful web services to generate the output External format of icad data.
 * 
 * @Author: VKE3
 * @since: Version 1.0
 * 
 * Modification Details:
 *
 *     Date   | User | Version | Comment
 * -----------|------|---------|--------------------------
 *  02/05/2023 VKE3    1.0      Services Class to host generate output external format.
 */
package com.nk.drawingprint;

import javax.json.JsonObject;
import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.PathParam;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.dassault_systemes.platform.restServices.RestService;
import com.matrixone.apps.framework.ui.UIUtil;

import matrix.db.Context;

@Path("/DrawingServices")
public class DrawingServices extends RestService{

	private static final Logger logger = LoggerFactory.getLogger("DrawingServices");
	//private DrawingProcesses itemNumberingProcess = new DrawingProcesses();

	/**
	 * This Method load the DrawingServices when Physical Product is dropped
	 * @param  jsonObj
	 **/

	@POST
	@Path("/read")
	@Produces({MediaType.APPLICATION_JSON})
	public Response read(@javax.ws.rs.core.Context HttpServletRequest httpReq, JsonObject jsonObj) throws Exception {
		logger.info("START:: DrawingServices: read()");
		Context context = null;
		Response response = null;
		try {
			context = this.getAuthenticatedContext(httpReq, false);
			DrawingProcesses dpProcess = new DrawingProcesses(context);
			
		} catch (Exception ex) {
			logger.error("Error::", ex);
			logger.info("END:: DrawingServices: read()");
			response = Response.status(Response.Status.BAD_REQUEST).entity(ex.getMessage()).build();
		}finally {
			if (context != null) {
				logger.info("Closing session");
				context.shutdown();
			}
		}
		logger.info("END:: DrawingServices: read()");
		return response;
	}	
	
	@GET
	@Path("/dpInstructions/{id}")	
	@Produces(MediaType.APPLICATION_JSON)
	public Response dpInstructions(@javax.ws.rs.core.Context HttpServletRequest request,@PathParam("id") String strOjectId) 
	{
		logger.debug("Started dpInstructions method");
		System.out.println("strOjectId : "+strOjectId);
		Response res = null;
		try {
			Context context = this.getAuthenticatedContext(request, false);
			System.out.println("context : "+context);
			DrawingProcesses dpProcess = new DrawingProcesses(context);			
			return dpProcess.validateInstructions(context, strOjectId);		
		} catch (Exception ex) {
			logger.error("Error in dpInstructions: ", ex);
			logger.debug("Finished dpInstructions method");
			res=Response.status(Response.Status.BAD_REQUEST).entity(ex.getMessage()).build();
		}
		logger.debug("Finished dpInstructions method");
		return res;
	}	
	
	/**
	 * Method to check if product is valid
	 * Checks: Type and attributes V_CADOrigin & KSL_EX_Physical_Product_Ref_Design_3D_Flag
	 * 
	 * @param  jsonObj
	 **/
	@POST
	@Path("/validateCADObjInfo")
	@Produces({MediaType.APPLICATION_JSON})
	public Response validateCADObjInfo(@javax.ws.rs.core.Context HttpServletRequest httpReq, JsonObject jsonObj)
			throws Exception {
		logger.info("START:: DrawingServices: validateCADObjInfo()");
		Context context = null;
		Response response = null;
		try {
			context = this.getAuthenticatedContext(httpReq, false);
			DrawingProcesses dpProcess = new DrawingProcesses(context);
			//response = icadExternalFormatProcess.validateCADObjInfo(jsonObj);
		} catch (Exception ex) {
			logger.error("Error::", ex);
			logger.info("END:: DrawingServices: validateCADObjInfo()");
			response = Response.status(Response.Status.BAD_REQUEST).entity(ex.getMessage()).build();
		}finally {
			if (context != null) {
				logger.info("Closing session");
				context.shutdown();
			}
		}
		logger.info("END:: DrawingServices: validateCADObjInfo()");
		return response;
	}
	
}
