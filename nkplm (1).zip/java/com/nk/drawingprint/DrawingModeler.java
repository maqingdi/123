/**
 * DrawingModeler.java
 * 
 * This class defines the RESTful web services to generate the output External format of icad data.
 * 
 * @Author: VKE3
 * @since: Version 1.0
 * 
 * Modification Details:
 *
 *     Date   | User | Version | Comment
 * -----------|------|---------|--------------------------
 *  02/05/2023 VKE3    1.0      Modeler Class to call the services
 */
package com.nk.drawingprint;

import javax.ws.rs.ApplicationPath;

import com.dassault_systemes.platform.restServices.ModelerBase;


/**
 * The DrawingModeler class defines the application path for the KSL
 * to generate the external format of icad data.
 * 
 * It extends the ModelerBase class from the Dassault
 * Systemes platform to provide the necessary functionality.
 * 
 */

@ApplicationPath("/DrawingModeler")
public class DrawingModeler extends ModelerBase{
	@Override
	public Class<?>[] getServices() {
		return new Class [] {DrawingServices.class};
	}
}
