package com.nk.drawingprint;

public class DrawingConstants {
	public static final int STATUS_SUCCESS = 200;
	public static final String STRING_STATUS = "status";
	public static final String STRING_DATA = "data";
	public static final String STATUS_ERROR = "error";
	public static final String EIN = "EnterpriseExtension.V_PartNumber";
	public static final String ATTRIBUTE_NK_EXT_EBOM_BASE_NK_USER_REVISION = "NK_EXT_EBOM_BASE.NK_USER_REVISION";
	public static final String ATTRIBUTE_NK_USER_REVISION = "NK_USER_REVISION";
	public static final String KEY_NK_USER_REVISION = "NK_USER_REVISION";
	public static final String ATTRIBUTE_NK_DOCUMENT_NUMBER = "NK_DOCUMENT_NUMBER";
	public static final String KEY_NK_DOCUMENT_NUMBER = "NK_DOCUMENT_NUMBER";
	public static final String ITEM_NUMBER = "ItemNumber";
	public static final String DOC_ITEM_NUMBER = "DocItemNumber";
	public static final String TYPE_VPMREFERENCE = "VPMReference";
	public static final String TYPE_DOCUMENT = "Document";
	public static final String TYPE_DRAWING = "Drawing";
	public static final String RELATIONSHIP_CAD_Dependency_Of = "CAD Dependency of";
	public static final String RELATIONSHIP_SpecificationDocument = "SpecificationDocument";
	public static final String DRAWING_AVAILABLE = "Drawing_Print_Available";
	public static final String PDF_AVAILABLE = "PDF_Available"; 
	public static final String ATTRIBUTE_TITLE = "Title"; 
	public static final String YES = "Yes";
	public static final String NO = "No";
}
